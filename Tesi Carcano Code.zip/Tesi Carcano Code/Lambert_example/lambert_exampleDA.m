clearvars; close all; clc;

%%
muE = 398600; 
Re = 6378.1; 

% set initial generic orbit by setting orbital elements (theta0 = 0 starts the propagation from the perigee)
a = 33923; e = 0.2991; i = deg2rad(23.2497); OM = deg2rad(0); om = deg2rad(0); theta0 = deg2rad(0);

% convert into cartesian coordinates
[r0,v0] = kp2rv(a, e, i, OM, om, theta0, muE);

% set initial state: position and velocity at initial time
x0 = [r0; v0];

% set times for propagation
T = 2*pi*sqrt(a^3/muE);
t0 = 0; tf = T/4;

% propagation with ode113 for one period and validation (one entire orbit is expected)
options = odeset('reltol', 1e-12, 'abstol', 1e-12);
[tt, xx] = ode113(@(t,x) TBP_propagator(t,x,muE), [t0 tf], x0, options);      % Integration



dr0 = [1000; -1000; 1000]; 
r1 = r0 + dr0; 

r2 = xx(end, 1:3);         % take a point of the orbit at task #1 as final point
t1 = 0; t2 = tt(end);

[~,~,~,~,V1_LAM,~,~,~] = lambertMR(r1', r2, t2-t1, muE, 0, 0, 0, 1);

deltaV1 = V1_LAM' - v0

%Lambet trajectory 
xl0 = [r1, V1_LAM']; 
[~, xL] = ode113(@(t,x) TBP_propagator(t,x,muE), [t1 t2], xl0, options);      % Integration

%Lambert computed with DACE
Dv1_6th = importdata('Dv1-6th_ord.txt');   % solution from python DACE
Dv1_3rd = importdata('Dv1-3rd_ord.txt');   % solution from python DACE
Dv1_1st = importdata('Dv1-1st_ord.txt');   % solution from python DACE

v0_DA6 = v0 + Dv1_6th; 
v0_DA3 = v0 + Dv1_3rd;
v0_DA1 = v0 + Dv1_1st;

x0_DA6 = [r1; v0_DA6]; 
x0_DA3 = [r1; v0_DA3];
x0_DA1 = [r1; v0_DA1];

[~, xDA6] = ode113(@(t,x) TBP_propagator(t,x,muE), [t1 t2], x0_DA6, options);      % Integration
[~, xDA3] = ode113(@(t,x) TBP_propagator(t,x,muE), [t1 t2], x0_DA3, options);      % Integration
[~, xDA1] = ode113(@(t,x) TBP_propagator(t,x,muE), [t1 t2], x0_DA1, options);      % Integration


figure() 
title('Original orbit and Lambert')
plot_earth(Re)
hold on 
plot3(xx(:,1), xx(:,2), xx(:,3), '--r')
plot3(xx(1,1), xx(1,2), xx(1,3), '.m', 'MarkerSize', 10)
plot3(xx(end,1), xx(end,2), xx(end,3), '.g', 'MarkerSize', 10)
plot3(xL(:,1), xL(:,2), xL(:,3), '-b')
plot3(xL(1,1), xL(1,2), xL(1,3), 'sk')
plot3(xL(end,1), xL(end,2), xL(end,3), 'db')
quiver3(xx(1,1), xx(1,2), xx(1,3), xL(1,1)-xx(1,1), xL(1,2)-xx(1,2), xL(1,3)-xx(1,2), 'k', 'LineWidth', 2)
axis equal
grid on 
legend('Original orbit', 'start', 'end', 'Lambert', 'deviated start', 'Lambert end', 'Initial perturbation')


figure()

plot3(xx(:,1), xx(:,2), xx(:,3), '-b')
% plot3(xx(1,1), xx(1,2), xx(1,3), '.m', 'MarkerSize', 10)
% plot3(xx(end,1), xx(end,2), xx(end,3), '.g', 'MarkerSize', 10)
hold on
plot3(xL(:,1), xL(:,2), xL(:,3), '-r', 'LineWidth', 2)
plot3(xL(1,1), xL(1,2), xL(1,3), 'sg', 'LineWidth', 3)
plot3(xL(end,1), xL(end,2), xL(end,3), 'dr', 'LineWidth', 3)

plot3(xDA6(:,1), xDA6(:,2), xDA6(:,3), '-k', 'LineWidth', 1)
% plot3(xDA6(1,1), xDA6(1,2), xDA6(1,3), 'sm')
% plot3(xDA6(end,1), xDA6(end,2), xDA6(end,3), 'dg')
plot3(xDA3(:,1), xDA3(:,2), xDA3(:,3), '-.k', 'LineWidth', 1)
plot3(xDA1(:,1), xDA1(:,2), xDA1(:,3), '--k', 'LineWidth', 1)
legend('Original orbit','Reference Lambert', 'start', 'end', 'DA 6-th Order', 'DA 3-rd order', 'DA linear')
title('DA expansions')
grid on 

%% FUNCTIONS

function [r,v]=kp2rv(a,e,i,OMEGA,omega,theta,mu)
%%
%      kp2rv.m -- from keplerian elements to cartesian coordinates
%     
%     
%     DESCRIPTION:
%       This function computes the cartesian coordinates of a point on a
%       orbit, starting from the keplerian elements
%     
%     INPUT: 
%          a = semi major axis; e = eccentricity;  i = inclination;  OMEGA
%          = right asciension of the ascending node; omega = argument of
%          the perigee; theta = true anomaly; mu = 2BP costant. 
%       
%     
%     OUTPUT:
%          r = position vector in cartesian coordinates  [rx; ry; rz];
%          v = velocity vector in cartesian coordinates [vx; vy; vz].
%     

%       

% Matrici di rotazione

R_OMEGA=[cos(OMEGA) sin(OMEGA) 0
    -sin(OMEGA) cos(OMEGA) 0
    0 0 1];

R_i=[1 0 0
    0 cos(i) sin(i)
    0 -sin(i) cos(i)];

R_omega=[cos(omega) sin(omega) 0
    -sin(omega) cos(omega) 0
    0 0 1];

T_ge2pf=R_omega*R_i*R_OMEGA;

T_pf2ge=(T_ge2pf)';

% Calcolo p, h

p=a*(1-e^2);
h=sqrt(mu*p);

% r,v in coordinate PF

r_pf=[p/(1+e*cos(theta))*cos(theta); p/(1+e*cos(theta))*sin(theta); 0];
v_pf=[(mu/h)*(-sin(theta)); (mu/h)*(e+cos(theta)); 0];

% r,v in coordinate GE

r_ge=T_pf2ge*r_pf;
v_ge=T_pf2ge*v_pf;

% Output funzione

r=r_ge;
v=v_ge;

end 


function [dx] = TBP_propagator(~,x,mu)
    rx = x(1); ry = x(2);  rz = x(3);
    vx = x(4); vy = x(5); vz = x(6);

    r  = sqrt(rx.^2+ry.^2+rz.^2);

    dx(1,1) = vx; dx(2,1) = vy; dx(3,1) = vz;
    % compute accelerations
    dx(4,1) = -mu*rx/r.^3;  
    dx(5,1) = -mu*ry/r.^3;
    dx(6,1) = -mu*rz/r.^3;
end


function [A,P,E,ERROR,VI,VF,TPAR,THETA] = lambertMR(RI,RF,TOF,MU,orbitType,Nrev,Ncase,optionsLMR)
    % Check inputs
    if nargin < 8
        optionsLMR = 0;
        if nargin < 6
            Nrev = 0;
            if nargin < 5
                orbitType = 0;
                if nargin < 4
                    error('Not enough input arguments. See lambertMR.');
                end
            end
        end
    end
    
    nitermax = 2000; % Maximum number of iterations for loops
    TOL = 1e-14;
    
    TWOPI=2*pi;
    
    % Reset
    A=0;P=0;E=0;VI=[0,0,0];VF=[0,0,0];
    
    % ----------------------------------
    % Compute the vector magnitudes and various cross and dot products
    
    RIM2   = dot(RI,RI);
    RIM    = sqrt(RIM2);
    RFM2   = dot(RF,RF);
    RFM    = sqrt(RFM2);
    CTH    = dot(RI,RF)/(RIM*RFM);  %cosine of theta
    CR     = cross(RI,RF);          %cross product
    STH    = norm(CR)/(RIM*RFM);    %sine of theta
    
    % Choose angle for up angular momentum
    switch orbitType
        case 0 % direct transfer
            if CR(3) < 0 
                STH = -STH;
            end
        case 1 % retrograde transfer
            if CR(3) > 0 
                STH = -STH;
            end
        otherwise
		    error('%d is not an allowed orbitType',orbitType);
    end
            
    THETA  = qck(atan2(STH,CTH));
    % if abs(THETA - pi) >= 0.01
    if THETA == TWOPI || THETA==0
        ERROR = 2;        %error 180/360 degrees
        A=0; P=0; E=0; VI=[0,0,0]; VF=[0,0,0]; TPAR=0; THETA=0;
        return
    end
    
    B1     = sign(STH); 
    if STH == 0 
        B1 = 1;
    end
    
    % ----------------------------------
    % Compute the chord and the semi-perimeter
    
    C= sqrt(RIM2 + RFM2 - 2*RIM*RFM*CTH);
    S= (RIM + RFM + C)/2;
    BETA   = 2*asin(sqrt((S-C)/S));
    PMIN   = TWOPI*sqrt(S^3/(8*MU));    
    TMIN   = PMIN*(pi-BETA+sin(BETA))/(TWOPI);   %minimum transfer time
    LAMBDA = B1*sqrt((S-C)/S);     %sin(beta min/2)
    
    if 4*TOF*LAMBDA == 0 || abs((S-C)/S) < TOL
        ERROR = -1;
        A=0; P=0; E=0; VI=[0,0,0]; VF=[0,0,0]; TPAR=0; THETA=0;
        return
    end
    
    % ----------------------------------
    % Compute L carefully for transfer angles less than 5 degrees
    
    if THETA*180/pi <= 5
       W   = atan((RFM/RIM)^.25) - pi/4;
       R1  = (sin(THETA/4))^2;
       S1  = (tan(2*W))^2;
       L   = (R1+S1)/(R1+S1+cos(THETA/2));
    else
       L   = ((1-LAMBDA)/(1+LAMBDA))^2;
    end
    
    M= 8*MU*TOF^2/(S^3*(1+LAMBDA)^6);
    TPAR   = (sqrt(2/MU)/3)*(S^1.5-B1*(S-C)^1.5);
    L1     = (1 - L)/2;
    
    CHECKFEAS = 0;
    N1 = 0;
    N = 0;
    
    if Nrev == 0
        % ----------------------------------
        % Initialize values of y, n, and x
    
        Y= 1;
        N= 0;
        N1=0;
        ERROR  = 0;
        % CHECKFEAS=0;
    
        if (TOF-TPAR) <= 1e-3
            X0  = 0;
        else
            X0  = L;
        end
    
        X= -1.e8;
    
        % ----------------------------------
        % Begin iteration
        
        % ---> CL: 26/01/2009, Matteo Ceriotti: 
        %       Changed absolute tolerance into relative tolerance here below.
        while (abs(X0-X) >= abs(X)*TOL+TOL) && (N <= nitermax)
            N   = N+1;
            X   = X0;
            ETA = X/(sqrt(1+X) + 1)^2;
            CHECKFEAS=1;
    
            % ----------------------------------
            % Compute x by means of an algorithm devised by
            % Gauticci for evaluating continued fractions by the
            % 'Top Down' method
            
            DELTA = 1;
            U     = 1;
            SIGMA = 1;
            M1    = 0;
    
            while abs(U) > TOL && M1 <= nitermax
                M1    = M1+1;
                GAMMA = (M1 + 3)^2/(4*(M1+3)^2 - 1);
                DELTA = 1/(1 + GAMMA*ETA*DELTA);
                U     = U*(DELTA - 1);
                SIGMA = SIGMA + U;
            end
    
            C1 = 8*(sqrt(1+X)+1)/(3+1/(5 + ETA + (9*ETA/7)*SIGMA));
    
            % ----------------------------------
            % Compute H1 and H2
            
            if N == 1
                DENOM = (1 + 2*X + L)*(3*C1 + X*C1 +4*X);
                H1 = (L+X)^2*(C1 + 1 + 3*X)/DENOM;
                H2 = M*(C1+X-L)/DENOM;
            else
                QR = sqrt(L1^2 + M/Y^2);
                XPLL = QR - L1;
                LP2XP1 = 2*QR;
                DENOM = LP2XP1*(3*C1 + X*C1+4*X);
                H1 = ((XPLL^2)*(C1 + 1 + 3*X))/DENOM;
                H2 = M*(C1+X-L)/DENOM;
            end
            
            B = 27*H2/(4*(1+H1)^3);
            U = -B/(2*(sqrt(B+1)+1));
    
            % ----------------------------------
            % Compute the continued fraction expansion K(u)
            % by means of the 'Top Down' method
            
            % Y can be computed finding the roots of the formula and selecting
            % the real one:
            % y^3 - (1+h1)*y^2 - h2 = 0     (7.113) Battin
            %
            % Ycami_ = roots([1 -1-H1 0 -H2])
            % kcami = find( abs(imag(Ycami_)) < eps );
            % Ycami = Ycami_(kcami)
    
            DELTA = 1;
            U0 = 1;
            SIGMA = 1;
            N1 = 0;
    
            while N1 < nitermax && abs(U0) >= TOL
                if N1 == 0
                    GAMMA = 4/27;
                    DELTA = 1/(1-GAMMA*U*DELTA);
                    U0 = U0*(DELTA - 1);
                    SIGMA = SIGMA + U0;
                else
                    for I8 = 1:2
                        if I8 == 1
                            GAMMA = 2*(3*N1+1)*(6*N1-1)/(9*(4*N1 - 1)*(4*N1+1));
                        else
                            GAMMA = 2*(3*N1+2)*(6*N1+1)/(9*(4*N1 + 1)*(4*N1+3));
                        end
                        DELTA = 1/(1-GAMMA*U*DELTA);
                        U0 = U0*(DELTA-1);
                        SIGMA = SIGMA + U0;
                    end
                end
    
                N1 = N1 + 1;
            end
    
            KU = (SIGMA/3)^2;
            Y = ((1+H1)/3)*(2+sqrt(B+1)/(1-2*U*KU));    % Y = Ycami
            
            X0 = sqrt(((1-L)/2)^2+M/Y^2)-(1+L)/2;
            % fprintf('n= %d, x0=%.14f\n',N,X0);
        end
        
    % MULTIREVOLUTION
    elseif (Nrev > 0) && (4*TOF*LAMBDA~=0) %(abs(THETA)-pi > 0.5*pi/180)
    
        checkNconvRSS = 1;
        checkNconvOSS = 1;
        N3 = 1;
        
        while N3 < 3
            
            if Ncase == 0 || checkNconvRSS == 0
    
                % - Original Successive Substitution -
                % always converges to xL - small a
    
                % ----------------------------------
                % Initialize values of y, n, and x
                
                Y= 1;
                N= 0;
                N1=0;
                ERROR = 0;
                % CHECKFEAS = 0;
    %             if (TOF-TPAR) <= 1e-3
    %                 X0 = 0;
    %             else
                if checkNconvOSS == 0
                    X0 = 2*X0;
                    checkNconvOSS = 1;
                    % see p. 11 USING BATTIN METHOD TO OBTAIN 
                    % MULTIPLE-REVOLUTION LAMBERT'S SOLUTIONS - Shen, Tsiotras
                elseif checkNconvRSS == 0;
                    % X0 is taken from the RSS
                else
                    X0 = L;
                end
    
                X = -1.e8;
    
                % ----------------------------------
                % Begin iteration
            			    
                % ---> CL: 26/01/2009,Matteo Ceriotti 
                %   Changed absolute tolerance into relative tolerance here
                %   below.
                while (abs(X0-X) >= abs(X)*TOL+TOL) && (N <= nitermax)
                    N   = N+1;
                    X   = X0;
                    ETA = X/(sqrt(1+X) + 1)^2;
                    CHECKFEAS = 1;
    
                    % ----------------------------------
                    % Compute x by means of an algorithm devised by
                    % Gauticci for evaluating continued fractions by the
                    % 'Top Down' method
                    
    
                    DELTA = 1;
                    U     = 1;
                    SIGMA = 1;
                    M1    = 0;
    
                    while abs(U) > TOL && M1 <= nitermax
                        M1    = M1+1;
                        GAMMA = (M1 + 3)^2/(4*(M1+3)^2 - 1);
                        DELTA = 1/(1 + GAMMA*ETA*DELTA);
                        U     = U*(DELTA - 1);
                        SIGMA = SIGMA + U;
                    end
    
                    C1 = 8*(sqrt(1+X)+1)/(3+1/(5 + ETA + (9*ETA/7)*SIGMA));
    
                    % ----------------------------------
                    % Compute H1 and H2
                    
                    if N == 1
                        DENOM = (1 + 2*X + L)*(3*C1 + X*C1 +4*X);
                        H1 = (L+X)^2*(C1 + 1 + 3*X)/DENOM;
                        H2 = M*(C1+X-L)/DENOM;
                    else
                        QR = sqrt(L1^2 + M/Y^2);
                        XPLL = QR - L1;
                        LP2XP1 = 2*QR;
                        DENOM = LP2XP1*(3*C1 + X*C1+4*X);
                        H1 = ((XPLL^2)*(C1 + 1 + 3*X))/DENOM;
                        H2 = M*(C1+X-L)/DENOM;
                    end
    
                    H3 = M*Nrev*pi/(4*X*sqrt(X));
                    H2 = H3+H2;
    
                    B = 27*H2/(4*(1+H1)^3);
                    U = -B/(2*(sqrt(B+1)+1));
    
                    % ----------------------------------
                    % Compute the continued fraction expansion K(u)
                    % by means of the 'Top Down' method
                    
                    % Y can be computed finding the roots of the formula and selecting
                    % the real one:
                    % y^3 - (1+h1)*y^2 - h2 = 0     (7.113) Battin
                    %
                    % Ycami_ = roots([1 -1-H1 0 -H2])
                    % kcami = find( abs(imag(Ycami_)) < eps );
                    % Ycami = Ycami_(kcami)
    
                    DELTA = 1;
                    U0 = 1;
                    SIGMA = 1;
                    N1 = 0;
    
                    while N1 < nitermax && abs(U0) >= TOL
                        if N1 == 0
                            GAMMA = 4/27;
                            DELTA = 1/(1-GAMMA*U*DELTA);
                            U0 = U0*(DELTA - 1);
                            SIGMA = SIGMA + U0;
                        else
                            for I8 = 1:2
                                if I8 == 1
                                    GAMMA = 2*(3*N1+1)*(6*N1-1)/(9*(4*N1 - 1)*(4*N1+1));
                                else
                                    GAMMA = 2*(3*N1+2)*(6*N1+1)/(9*(4*N1 + 1)*(4*N1+3));
                                end
                                DELTA = 1/(1-GAMMA*U*DELTA);
                                U0 = U0*(DELTA-1);
                                SIGMA = SIGMA + U0;
                            end
                        end
    
                        N1 = N1 + 1;
                    end
    
                    KU = (SIGMA/3)^2;
                    Y = ((1+H1)/3)*(2+sqrt(B+1)/(1-2*U*KU));	% Y = Ycami
                    if Y > sqrt(M/L)
                        if optionsLMR(1) == 2
                            warning('lambertMR:SuccessiveSubstitutionDiverged',...
                                    ['Original Successive Substitution is diverging\n'...
                                    '-> Reverse Successive Substitution used to find the proper XO.\n']);
                        end
                        checkNconvOSS = 0;
                        break
                    end
                    
                    X0 = sqrt(((1-L)/2)^2+M/Y^2)-(1+L)/2;
                    % fprintf('N: %d X0: %.14f\n',N,X0);
                end
                
                % When 2 solutions exist (small and big a), the previous loop
                % must either converge or diverge because Y > sqrt(M/L) at some
                % point. Thus, the upper bound on the number of iterations
                % should not be necessary. Though, nothing can be said in the
                % case tof<tofmin and so no solution exist. In this case, an
                % upper bound on number of iterations could be needed.
                
                if N >= nitermax % Checks if previous loop ended due to maximum number of iterations
                    if optionsLMR(1) == 2
                        warning('lambertMR:SuccessiveSubstitutionExceedMaxIter',...
                                ['Original Successive Substitution exceeded max number of iteration\n'...
                                '-> Reverse Successive Substitution used to find the proper XO.\n']);
                    end
                    checkNconvOSS = 0;
                end
            end
            if (Ncase == 1 || checkNconvOSS == 0) && ~(checkNconvRSS == 0 && checkNconvOSS == 0)
    
                % - Reverse Successive Substitution -
                % always converges to xR - large a
    
                % ----------------------------------
                % Initialize values of y, n, and x
                
                N = 0;
                N1 = 0;
                ERROR  = 0;
                % CHECKFEAS=0;
                if checkNconvRSS == 0;
                    X0 = X0/2; % XL/2
                    checkNconvRSS = 1;
                    % see p. 11 USING BATTIN METHOD TO OBTAIN 
                    % MULTIPLE-REVOLUTION LAMBERT'S SOLUTIONS - Shen, Tsiotras
                elseif checkNconvOSS == 0
                    % X0 is taken from the OSS
                else
                    X0 = L;
                end
    
                X = -1.e8;
    
                % ----------------------------------
                % Begin iteration
                
                % ---> CL: 26/01/2009, Matteo Ceriotti
                %   Changed absolute tolerance into relative tolerance here
                %   below.
                while (abs(X0-X) >= abs(X)*TOL+TOL) && (N <= nitermax)
                    N = N+1;
                    X = X0;
                    CHECKFEAS=1;
    
                    Y = sqrt(M/((L+X)*(1+X))); % y1 in eq. (8a) in Shen, Tsiotras
    
                    if Y < 1
                        if optionsLMR(1) == 2
                            warning('lambertMR:SuccessiveSubstitutionDiverged',...
                                    ['Reverse Successive Substitution is diverging\n' ...
                                    '-> Original Successive Substitution used to find the proper XO.\n']);
                        end
                        checkNconvRSS = 0;
                        break
                    end
                    
                    % ---> CL: 27/01/2009, Matteo Ceriotti
                    %   This is the Newton-Raphson method suggested by USING
                    %   BATTIN METHOD TO OBTAIN MULTIPLE-REVOLUTION LAMBERT'S
                    %   SOLUTIONS - Shen, Tsiotras
                    
                    % To assure the Newton-Raphson method to be convergent
                    Erss = 2*atan(sqrt(X));
                    while h_E(Erss,Y,M,Nrev) < 0
                        Erss = Erss/2;
                    end
                    
                    Nnew = 1;
                    Erss_old = -1.e8;
                    
                    % The following Newton-Raphson method should always
                    % converge, given the previous first guess choice,
                    % according to the paper. Therefore, the condition on
                    % number of iterations should not be neccesary. It could be
                    % necessary for the case tof < tofmin.
                    while (abs(Erss-Erss_old) >= abs(Erss)*TOL+TOL) && Nnew < nitermax
                        Nnew = Nnew+1;
                        [h, dh] = h_E(Erss,Y,M,Nrev);
                        Erss_old = Erss;
                        Erss = Erss - h/dh;
                        % fprintf('Nnew: %d Erss: %.16f h_E: %.16f\n',Nnew,Erss,h);
                    end
                    if Nnew >= nitermax
                        if optionsLMR(1) ~= 0
                            warning('lambertMR:NewtonRaphsonIterExceeded', 'Newton-Raphson exceeded max iterations.\n');
                        end
                    end
                    X0 = tan(Erss/2)^2;
                end
            end
            if checkNconvOSS == 1 && checkNconvRSS == 1
                break
            end
            
            if checkNconvRSS == 0 && checkNconvOSS == 0
                if optionsLMR ~=0
                    warning('lambertMR:SuccessiveSubstitutionDiverged',...
                            ['Both Original Successive Substitution and Reverse ' ...
                            'Successive Substitution diverge because Nrev > NrevMAX.\n' ...
                            'Work in progress to calculate NrevMAX.\n']);
                end
                ERROR = 3;
                A=0; P=0; E=0; VI=[0,0,0]; VF=[0,0,0]; TPAR=0; THETA=0;
                return
            end
            
            N3 = N3+1;
        end
        
        if N3 == 3
            if optionsLMR ~=0
                warning('lambertMR:SuccessiveSubstitutionDiverged',...
                        ['Either Original Successive Substitution or Reverse ' ...
                        'Successive Substitution is always diverging\n' ...
                        'because Nrev > NrevMAX or because large-a solution = small-a solution (limit case).\n' ...
                        'Work in progress to calculate NrevMAX.\n']);
            end
            ERROR = 3;
            A=0; P=0; E=0; VI=[0,0,0]; VF=[0,0,0]; TPAR=0; THETA=0;
            return
        end
    end
    
    % ----------------------------------
    % Compute the velocity vectors
    
    if CHECKFEAS == 0
        ERROR = 1;
        A=0; P=0; E=0; VI=[0,0,0]; VF=[0,0,0]; TPAR=0; THETA=0;
        return
    end
    
    if N1 >= nitermax || N >= nitermax
        ERROR = 4;
        if optionsLMR ~=0
            disp('Lambert algorithm has not converged, maximum number of iterations exceeded.');
        end
        A=0; P=0; E=0; VI=[0,0,0]; VF=[0,0,0]; TPAR=0; THETA=0;
        return
    end
    
    CONST = M*S*(1+LAMBDA)^2;
    A = CONST/(8*X0*Y^2);
    
    R11 = (1 + LAMBDA)^2/(4*TOF*LAMBDA);
    S11 = Y*(1 + X0);
    T11 = (M*S*(1+LAMBDA)^2)/S11;
    
    VI(1:3) = -R11*(S11*(RI(1:3)-RF(1:3))-T11*RI(1:3)/RIM);
    VF(1:3) = -R11*(S11*(RI(1:3)-RF(1:3))+T11*RF(1:3)/RFM);
    
    P = (2*RIM*RFM*Y^2*(1+X0)^2*sin(THETA/2)^2)/CONST;
    E = sqrt(1 - P/A);
    
   end
    
  
function [angle] = qck(angle)

% qck.m - Reduce an angle between 0 and 2*pi
%
% PROTOTYPE:
%   [angle]=qck(angle)
%
% DESCRIPTION:
%   This function takes any angle and reduces it, if necessary,
% 	so that it lies in the range from 0 to 2 PI radians.
% 
% INPUTS:
%   ANGLE[1]    Angle to be reduced (in radians)
% 
% OUTPUTS:
%   QCK[1]      The angle reduced, if necessary, to the range
%               from 0 to 2 PI radians (in radians)
% 
% CALLED FUNCTIONS:
%   pi (from MATLAB)
%
% AUTHOR:
%   W.T. Fowler, July, 1978
%
% CHANGELOG:
%   8/20/90, REVISION: Darrel Monroe
%
% -------------------------------------------------------------------------

twopi = 2*pi;
 
diff = twopi * (fix(angle/twopi) + min([0,sign(angle)]));

angle = angle -diff;

end


function [h, dh] = h_E(E, y, m, Nrev)

% h_E.m - Equation of multirevolution Lambert's problem h = h(E).
%
% PROTOTYPE:
%   [h, dh] = h_E(E, y, m, Nrev)
%
% DESCRIPTION:
%   Equation of multirevolution Lambert's problem:
%   h(E) = (Nrev*pi + E - sin(E)) / tan(E/2)^3 - 4/m * (y^3 - y^2)
%   See: "USING BATTIN METHOD TO OBTAIN MULTIPLE-REVOLUTION LAMBERT'S 
%      SOLUTIONS", Shen, Tsiotras, pag. 12
%
% INPUT
%   E, y, m, Nrev   See paper for detailed description.
%
% OUTPUT
%   h               Value of h(E).
%   dh              Value of dh(E)/dE.
%
% ORIGINAL VERSION:
%   Camilla Colombo, 20/02/2006, MATLAB, cubicN.m
%
% AUTHOR:
%   Matteo Ceriotti, 27/01/2009
%   - changed name of cubicN.m and added at the bottom of lambertMR.m file
%
% -------------------------------------------------------------------------

tanE2 = tan(E/2);
h = (Nrev*pi + E - sin(E)) / tanE2^3 - 4/m * (y^3 - y^2);

if nargout > 1  % two output arguments
    % h'(E)
    dh = (1-cos(E))/tanE2^3 - 3/2*(Nrev*pi+E-sin(E))*sec(E/2)^2 / tanE2^4;
end

end


function plot_earth(Re)

    TERRA=imread('planisphere.jpg','jpg');
    props.FaceColor='texture';
    props.EdgeColor='none';
    props.FaceLighting='phong';
    props.Cdata=TERRA;
    C=[0;0;0];
    [XX,YY,ZZ]=ellipsoid(C(1),C(2),C(3),Re,Re,Re,1000);
    surface(-XX,-YY,-ZZ,props,'HandleVisibility','off');

end


   