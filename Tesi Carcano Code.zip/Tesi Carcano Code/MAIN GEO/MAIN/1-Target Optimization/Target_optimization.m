clearvars; close all; clc;

% Procedure for numerical optimization of the targets 
% THIS CODE FINDS OUT THE OPTIMIZED TARGETS FOR THE STATION KEEPING CYCLES.
% SET PARAMETERS AND CONTROL DURATION. SAVE TARGETS IN .TXT file
% FUNCTIONS AT THE END OF THE SCRIPT. 
% !!!!SET STATION KEEPING BOX IN THE nonlcon FUNCTION!!!!

% SETUP
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize

pert_selector = 3;                             % Takes all perturbations (Geopotential, SRP, SUN and MOON)

hours = 3600;                                    %Hours to seconds
days = 24*hours;                                 %Days to seconds

dat.Re = 6378.137/ll;                          % Earth radius 
dat.mue = 398600*tt^2/ll^3;                    % Earrh grav param
dat.muS = astroConstants(4)*tt^2/ll^3;         % Sun grav param
dat.muM = astroConstants(20)*tt^2/ll^3;        % Moon grav param
dat.Rgeo = 42165.8/ll;                             
dat.w = sqrt(dat.mue/(dat.Rgeo)^3);
dat.G0 = 0;

% GEOPOTENTIAL up to 3,3 -- values taken from 'vallado' 
grav.c20 = -1.083e-3;  
grav.c21 = -2.414e-10;  
grav.c22 = 1.574e-6;  
grav.c30 = 2.532e-6;  
grav.c31 = 2.191e-6; 
grav.c32 = 3.089e-7;  
grav.c33 = 1.006e-7;  
grav.s21 = 1.543e-9;  
grav.s22 = -9.038e-7;  
grav.s31 = 2.687e-7; 
grav.s32 = -2.115e-7;
grav.s33 = 1.972e-7;

% SRP parameters
SRP.mass = 3000; % kg 
SRP.Surf = 100; % m^2
SRP.Cr = 1.5; 
SRP.S = 1353; % W/m^2
SRP.c = 2.998*1e8; % speed of light

% Performance parameters
Mi = 3000; %initial mass kg
Isp = 3800; % spec. impulse s
g0 = 9.81;  % m/s^2

% TIME
hours = 3600;                               
days = 24*hours;

% t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                             %initial time MJD2000 (seconds)
t0 = date2mjd2000([2023, 01, 01, 0, 0, 0])*days;                             %initial time MJD2000 (seconds)

% writematrix(t0, 't02010.txt');
% writematrix(t0, 't02023.txt');


r0 = 42165.8/ll;                 % GEO RADIUS
l0 = deg2rad(60 - 0.04);         % NOMINAL LONGITUDE
phi0 = 0;                        % NOMINAL LATITUDE
v0 = 0;                          % NOMINAL radial vel
csi0 = 0;                        % NOMINAL transv vel
n0 = 0;                          % NOMINAL out of plane vel


tc = 0.5*days;                   % SET FIXED CONTROL DURATION
tlim = t0 + 365*days;            % SET DURATION OF THE ANALYSIS

nominal_sk = [r0; l0; phi0; v0; csi0; n0; 0; 0; 0; 0; 0; 0];   % no control (=0)

x0_sk = nominal_sk;                            %initial guess for target optimization

%% OPTIMIZATION

% Options and Bounds
Options = optimoptions('fmincon','Algorithm','interior-point',...
          'StepTolerance',1e-6,'OptimalityTolerance',1e-8,...
          'ConstraintTolerance',1e-8, 'MaxIterations',100,'Display', 'iter');
 
lb = [42160/ll  deg2rad(60 - 0.05)  deg2rad(0 - 0.05) -1e-4  -1e-4  -1e-4 0 0 0 0 0 0]; 
ub = [42170/ll  deg2rad(60 + 0.05)  deg2rad(0 + 0.05)  1e-4   1e-4   1e-4 0 0 0 0 0 0];

% Fmincon call
k = 1;              % N° of SK CYCLE
time = t0; 

while time <= tlim 

    tfd0_a = 16*days;      % FIX A 'SURE free-drift DURATION' -- FMINCON WILL SURELY CONVERGE (Trial and error)
    tfd0_b = 27*days;      % FIX A 'IMPOSSIBLE free-driftb DURATION' -- FMINCON WILL NOT CONVERGE (Trial and error)

    [x_opt(:,k), tmin(k), EXITFLAG_A] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_a, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_a, time, pert_selector, tt, ll), Options);
    [x_opt(:,k), tmin(k), EXITFLAG_B] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_b, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_b, time, pert_selector, tt, ll), Options); 
       
    while (tfd0_b - tfd0_a) > 1/6 * hours    %BISECTION -- stopping criteria

        if EXITFLAG_B ~= 1 && EXITFLAG_A == 1  
            tfd0_c = (tfd0_a + tfd0_b)/2; 
            [x_opt(:,k), tmin(k), EXITFLAG_C(k)] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), Options);        
        end 

        if EXITFLAG_C(k) == 1
           tfd0_a = tfd0_c;
           EXITFLAG_A = EXITFLAG_C(k); 
        else 
           tfd0_b = tfd0_c; 
           EXITFLAG_B = EXITFLAG_C(k); 
        end 

        if EXITFLAG_C(k) ~= 1 && (tfd0_b - tfd0_a) < 1/6*hours
           tfd0_c = tfd0_a; 
           [x_opt(:,k), tmin(k), EXITFLAG_C(k)] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), Options);
           tfd0_a = 0; 
           tfd0_b = 0; 
        end 

    end 

    % Update state and time
    r = x_opt(1,k); l = x_opt(2,k); phi = x_opt(3,k);
    v = x_opt(4,k); csi = x_opt(5,k); n = x_opt(6,k);
    
    tfd = 1/tmin(k); 
    
    % Propagate free-drift arc
    x0 = [r; l; phi; v; csi; n; 0; 0; 0; 0; 0; 0]; 
    t_propag = linspace(time, time + tfd, 1000)./tt; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [~, sph_FD] = ode113(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, pert_selector, tt, ll), t_propag, x0, options);
    
%     figure(1)  % Groundtrack -- UNCOMMENT FOR real time PLOT
%     plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--','LineWidth',0.1)
%     hold on
%     grid on
%     title('Groundtrack');
%     xlabel('Longitude [deg]');
%     ylabel('Latitude [deg]');
%     plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ob','LineWidth',1.5); 
%     plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
%     legend('Track', 'Start Free drift', 'End Free drift', Location='best')

    time = time + tfd + tc;
    k = k + 1;
 
end 

%% SAVE DATA
% tfd = 1./tmin./days;
% writematrix(x_opt(1:6,:), 'target2023_tC.txt', 'Delimiter', 'tab'); % SAVE TARGETS
% writematrix(tfd, 'tfd2023_tC1.txt', 'Delimiter', 'tab');            % SAVE FREE DRIFT MAX PERMANENCE INSIDE BOX





%% TARGET OPTIMIZATION ON TIME GRID
% 
% r0 = 42165.8/ll; 
% l0 = deg2rad(60 - 0.04); 
% phi0 = 0; 
% v0 = 0; 
% csi0 = 0; 
% n0 = 0;
%  
% 
% % tfd0 = linspace(18, 22.5, 20).*days;
% tc = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.25].*days;
% 
% nominal_sk = [r0; l0; phi0; v0; csi0; n0;  0; 0; 0; 0; 0; 0];   % no control (=0)
% 
% 
% % optimizer options
% Options = optimoptions('fmincon','Algorithm','interior-point',...
%           'StepTolerance',1e-6,'OptimalityTolerance',1e-8,...
%           'ConstraintTolerance',1e-8, 'MaxIterations',100,'Display', 'iter');
% 
% % optimizer constraints and boundaries  (both linear and non-linear constraints have been used)
% % A = [1, -1, 0, 0, 0, 0, 0, 0]; b = 0; 
% lb = [42160/ll  deg2rad(60 - 0.05)  deg2rad(0 - 0.05) -1e-4  -1e-4  -1e-4 0 0 0 0 0 0]; 
% ub = [42170/ll  deg2rad(60 + 0.05)  deg2rad(0 + 0.05)  1e-4   1e-4   1e-4 0 0 0 0 0 0];
% 
% % Fmincon call and optimization -- find minimum Dv using simple shooting  
% time = t0; 
% k = 1; 
% x_opt = zeros(12,16,8);
% tmin = zeros(8, 16); 
% EXITFLAG_C = zeros(8, 16);
% DV = zeros(8,16);
% % cycles = zeros(20,20);
% % comp_time = zeros(20,20);
% 
% for j = 1 : length(tc)
% %         cycles(i,j) = ceil(365/5*days/(tfd0(i) + tc(j))); 
% %         k_max = cycles(i,j);
% 
%     tic
%     while time <= tlim 
% 
%         tfd0_a = 16*days;
%         tfd0_b = 27*days; 
% 
%         x0_sk = nominal_sk;
% 
% 
%    
%         if  j ~= 1 && k == 1
%             x_opt(:,k,j) = x_opt(:,k,j-1); 
%             tmin(j,k) = tmin(j-1,k); 
% 
%         else
%             [x_opt(:,k,j), tmin(j,k), EXITFLAG_A] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_a, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_a, time, pert_selector, tt, ll), Options);
%             [x_opt(:,k,j), tmin(j,k), EXITFLAG_B] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_b, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_b, time, pert_selector, tt, ll), Options); 
%                
%             while (tfd0_b - tfd0_a) > 1/6 * hours  
% 
%                 if EXITFLAG_B ~= 1 && EXITFLAG_A == 1  
%                     tfd0_c = (tfd0_a + tfd0_b)/2; 
%                     [x_opt(:,k,j), tmin(j,k), EXITFLAG_C(j,k)] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), Options);        
%                 end 
%     
%                 if EXITFLAG_C(j,k) == 1
%                    tfd0_a = tfd0_c;
%                    EXITFLAG_A = EXITFLAG_C(j,k); 
%                 else 
%                    tfd0_b = tfd0_c; 
%                    EXITFLAG_B = EXITFLAG_C(j,k); 
%                 end 
% 
%                 if EXITFLAG_C(j,k) ~= 1 && (tfd0_b - tfd0_a) < 1/4*hours
%                    tfd0_c = tfd0_a; 
%                    [x_opt(:,k,j), tmin(j,k), EXITFLAG_C(j,k)] = fmincon(@(x) optim_target(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), x0_sk, [], [], [], [], lb, ub, @(x) nonlcon(x, dat, grav, SRP, t0, tfd0_c, time, pert_selector, tt, ll), Options);
%                    tfd0_a = 0; 
%                    tfd0_b = 0; 
%                 end 
% 
%             end 
%         end
%                       
%         if k > 1
%             tfd = 1/tmin(j,k-1);
%             timeDV = time - tfd - tc(j); 
%             r = x_opt(1,k-1,j); l = x_opt(2,k-1,j); phi = x_opt(3,k-1,j);
%             v = x_opt(4,k-1,j); csi = x_opt(5,k-1,j); n = x_opt(6,k-1,j);
%            
%             x0_FD = [r; l; phi; v; csi; n;  0; 0; 0; 0; 0; 0];
% 
%             t_FD = linspace(timeDV, timeDV + tfd, 1000)./tt;
%             t_C = linspace(timeDV + tfd, timeDV + tfd + tc(j), 1000)./tt;
% 
%             options = odeset('reltol', 1e-12, 'abstol', 1e-12);
%             [~, sph_FD] = ode113(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, pert_selector, tt, ll), t_FD, x0_FD, options);
%             final_FD = sph_FD(end,:)';     
%                     
%             state.initial = final_FD(1:6);            %end of free drift
%             state.final = x_opt(1:6,k,j)';                %Back to initial free drift state for SK
%             
%             Dlamda0_Shoot = [0; 0; 0; 0; 0; 0]; 
%             lamda0_shooting = Dlamda0_Shoot;
%             
%             % fsolve options
%             options_fsolve = optimoptions(@fsolve,'Display', 'off', 'Maxiter', 1000,'FunctionTolerance', 1e-12, 'StepTolerance',1e-6);
%             O = fsolve(@opt_solv, lamda0_shooting, options_fsolve, state, t_C, dat, grav, SRP, t0, pert_selector, ll, tt);
%             dyn0_shoot = [state.initial; O]; 
% 
%             % Propagation to compute state and costate evolution
%             [~, sph_S] = ode113(@(t,dyn) SPHmotion(t, dyn, dat, grav, SRP, t0, pert_selector, tt, ll), t_C, dyn0_shoot, options);
%             
% %                 figure(1)  % Groundtrack
% %                 plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--','LineWidth',0.1)
% %                 hold on
% %                 grid on
% %                 title('Groundtrack');
% %                 xlabel('Longitude [deg]');
% %                 ylabel('Latitude [deg]');
% %                 plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ob','LineWidth',1.5); 
% %                 plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
% %                 plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-k','LineWidth',1)
% %                 plot(rad2deg(x_opt(2,k,j)), rad2deg(x_opt(3,k,j)),'*r','MarkerSize',5);
% %                 legend('Track', 'Start Free drift', 'End Free drift', 'control', Location='best')
% 
% 
%             u_rS = - sph_S(:, 10) * ll/tt^2 ;
%             
%             for q = 1 : 1000
%                 u_lS(q) = - sph_S(q, 11) /tt^2 * (sph_S(q, 1)*ll * cos(sph_S(q, 3))) ;
%                 u_phiS(q) = - sph_S(q, 12) /tt^2 * (sph_S(q, 1)*ll);
%             end
%             
%             % compute performance index 
%             u = [u_rS, u_lS', u_phiS']*1e3;    % control acceleration m/s^2 
%             U = vecnorm(u,2,2);
% 
%             t_int = linspace(0, tc(j), 1000);
%             acc = mean(U); 
%             [~, mass] = ode113(@(t,m) mass_int(t, m, acc, Isp, g0), t_int, Mi, options);
%             Mf = mass(end);
%             M_consumed(j,k) = Mi - Mf; 
%             DV(j,k) = -log(Mf/Mi)*Isp*g0;  
%             Mi = Mf; 
%         end
% 
%         time = time + 1/tmin(j, k) + tc(j); 
%         fprintf('k = %d', k)
%         k = k+1; 
%         
% 
%     end 
% 
%     time = t0; 
%     k = 1; 
%     elapsed_time = toc
%     comp_time(j) = elapsed_time; 
%     fprintf('j = %d', j)
% end 
% 
% 
% %%
% % tfd = 1./tmin./days;
% % writematrix(x_opt(1:6,:,9), 'target2023_tC225.txt', 'Delimiter', 'tab');
% % writematrix(tfd, 'tfd2023_tCvar.txt', 'Delimiter', 'tab');
% % writematrix(DV, 'DV.txt');
% % writematrix(comp_time, 'comp_time.txt');
% % writematrix(cycles, 'control_cycles.txt');
% 
% %% plot dv
% 
% 
% % figure()
% % contourf(tfd0/days, tc/days, DV) 
% 
% tfd0 = linspace(18, 22.5, 20).*days;
% tc = linspace(0.5, 5, 20).*days;
% 
% DV(1,17) = 5.4578; 
% DV(17,1) = 5.9896; 
% % [X, Y] = meshgrid(tfd0/days, tc/days); 
% 
% figure()
% s = surf(tc/days,(tfd0/days), DV); 
% s.EdgeColor = 'none';
% % s.FaceColor = 'interp';
% xlabel('Control duration [days]')
% ylabel('Free-Drift duration [days]')
% title('Consumption on 2.5 months SK vs Free-Drift and Control duration')
% colormap((parula))
% colorb = colorbar;
% colorb.Label.String = '\DeltaV [m/s]';
% gca.YDir = 'reverse'; 
% 
% figure()
% s = surf(tc/days,(tfd0/days), cycles); 
% s.EdgeColor = 'none';
% % s.FaceColor = 'interp';
% xlabel('Control duration [days]')
% ylabel('Free-Drift duration [days]')
% colormap cool
% colorb = colorbar;
% gca.YDir = 'reverse'; 


% dv_m = min(min(DV))
% [a, b] = find(DV == dv_m)
% tFDmin = tfd0(b)/days
% tCmin = tc(a)/days


% plot computational time
% [A, B] = meshgrid(tfd0(1:end-2)/days, tc(1:end-2)/days);
% figure()
% s = surf(A,B,comp_time(1:end-2, 1:end-2)); 
% s.EdgeColor = 'none';
% % s.FaceColor = 'interp';
% xlabel('Free Drift duration [days]')
% ylabel('Control duration [days]')
% colormap parula
% colorb = colorbar;
% colorb.Label.String = 'Computation Time [s]'; 



% Propagation
% r = x_opt(1); l = x_opt(2); phi = x_opt(3);
% v = x_opt(4); csi = x_opt(5); n = x_opt(6);
% 
% tfd = 1/min; 
% 
% x0 = [r; l; phi; v; csi; n]; 
% time = linspace(t0, t0 + tfd, 1000); 
% options = odeset('reltol', 1e-12, 'abstol', 1e-12);
% [~, sph_FD] = ode113(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, pert_selector), time, x0, options);
% 
% figure()  % Groundtrack
% plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k','LineWidth',1)
% hold on
% grid on
% title('Groundtrack');
% xlabel('Longitude [deg]');
% ylabel('Latitude [deg]');
% plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
% plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
% legend('Track', 'Start Free drift', 'End Free drift', Location='best')
% 

%% FUNCTIONS

function [time_inv] = optim_target(x, dat, grav, SRP, t0, tfd0, time, pert_selector, tt, ll)

    % Propagates the FD arc for the assigned guessed time. Gives its
    % inverse as output 

    r = x(1); l = x(2); phi = x(3);
    v = x(4); csi = x(5); n = x(6);

    % integration
%     x0 = [r; l; phi; v; csi; n];
    x0 = [r; l; phi; v; csi; n; 0; 0; 0; 0; 0; 0];
    tprop = linspace(time, time + tfd0, 1000)./tt; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [t_fin, ~] = ode113(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, pert_selector, tt, ll), tprop, x0, options);

    % define objective to be minimized
    time_inv = 1/(t_fin(end)*tt-time); 
    
end


function dsph = SPHmotion(t, dyn, dat, grav, SRP, t0, pert_selector, tt, ll)  
    
    % GEO MOTION PROPAGATION IN SPHERICAL COORDINATES
    % TAKES 12-vector OF STATE+COSTATE. INTEGRATES over time

    mue = dat.mue; muS = dat.muS; muM = dat.muM;  omega = dat.w;  R = dat.Re;

    m = SRP.mass; A = SRP.Surf; Cr = SRP.Cr; S = SRP.S; c = SRP.c;  G0 = dat.G0;

    c20 = grav.c20;  c21 = grav.c21;  c22 = grav.c22;  c30 = grav.c30;  c31 = grav.c31; 
    c32 = grav.c32;  c33 = grav.c33;  
    s21 = grav.s21;  s22 = grav.s22;  s31 = grav.s31;  s32 = grav.s32;  s33 = grav.s33;

    r = dyn(1);             v = dyn(4); 
    l = dyn(2);             csi = dyn(5);
    phi = dyn(3);           n = dyn(6);
    l_r = dyn(7);           l_v = dyn(10);
    l_l = dyn(8);           l_csi = dyn(11);
    l_phi = dyn(9);         l_n = dyn(12);
%     l_r = 0;           l_v = 0;
%     l_l = 0;           l_csi = 0;
%     l_phi = 0;         l_n = 0;
     

    % GRAVITY PERTURBING ACCELERATIONS (zonal + tesseral) --- derivatives taken with symbolic 
    aPg_r = -mue*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*r^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5);
 

    aPg_l =  -mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4))/(r*cos(phi));
 
 
    aPg_phi = mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/r^3)/r;


    % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600*tt;             % time in days (Dimensional for ephemeris)
    MJD2000 = tdays;

    ep = deg2rad(23.44);
    ecl = [1 0 0; 0 cos(ep) -sin(ep); 0 sin(ep) cos(ep)];   %rotation ecliptic/equatorial
    [kep, ~] = uplanet(MJD2000, 3);
    [r_E, ~] = kp2rv(kep(1), kep(2), kep(3), kep(4), kep(5), kep(6), muS);
    r_S = - r_E./ll;
   
    r_S = ecl * r_S;                % SUN position inertial geocentric equatorial frame
    [r_M, ~] = ephMoon(MJD2000);            % MOOn ....
    r_M = r_M./ll; 
    
    [RAs, Ds] = RaDec(r_S);
    [RAm, Dm] = RaDec(r_M);
    
    omega_dim = omega/tt; 
    RA = l + G0 + omega_dim * (t*tt - t0);

    cosPSIS = sin(phi) * sin(Ds) + cos(phi) * cos(Ds) * cos(RA - RAs);
    cosPSIM = sin(phi) * sin(Dm) + cos(phi) * cos(Dm) * cos(RA - RAm);
    
    rM = norm(r_M);
    rS = norm(r_S);

    a3r   = muS/rS^3 * r *(3*cosPSIS^2 - 1) + ...
            muM/rM^3 * r *(3*cosPSIM^2 - 1);
    a3l   = -3*muS/rS^3 * r * cosPSIS * cos(Ds) * sin(RA - RAs) - ...
            3*muM/rM^3 * r * cosPSIM * cos(Dm) * sin(RA - RAm); 
    a3phi = 3*muS/rS^3 * r * cosPSIS * (cos(phi) * sin(Ds) - sin(phi) * cos(Ds) * cos(RA - RAs)) + ...
            3*muM/rM^3 * r * cosPSIM * (cos(phi) * sin(Dm) - sin(phi) * cos(Dm) * cos(RA - RAm)); 


    % SRP PERTURBATIONS
%     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/m;         % perturbing acceleration F/m  [m/s^2]

    Psr = Psr * 1e-3; % [km/s^2]
    Psr = Psr * tt^2/ll; %adim

    aSRPr   = - Psr * cosPSIS; 
    aSRPl   =   Psr * cos(Ds) * sin(RA - RAs); 
    aSRPphi = - Psr * (sin(Ds) * cos(phi) - cos(Ds) * sin(phi) * cos(RA - RAs));
 
    
    % OVERALL PERTURBING ACCELERATIONS

    switch pert_selector
        case 1                         % GEOPOTENTIAL ONLY
                aP_r   = aPg_r;
                aP_l   = aPg_l;
                aP_phi = aPg_phi;
        case 2                         % THIRD BODIES ONLY
                aP_r   =  a3r;
                aP_l   =  a3l;
                aP_phi = a3phi;
        case 3                         % ALL
                aP_r   = aPg_r + a3r + aSRPr;
                aP_l   = aPg_l + a3l + aSRPl;
                aP_phi = aPg_phi + a3phi + aSRPphi;
    end


    % FINAL DYNAMICS
    dr = v; 
    dl = csi; 
    dphi = n; 
    dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
            aP_r - ...
            l_v; 

    dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
            aP_l/(r * cos(phi)) - ...
            l_csi/(r * cos(phi))^2; 

    dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
            aP_phi/r - ...
            l_n/r^2; 

    dl_r = l_n*(((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r - Psr*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r^2 - (2*l_n)/r^3 + ((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r^2 + (mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4))/r - (3*cosPSIM*muM*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 - (3*cosPSIS*muS*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r - (2*n*v)/r^2) - l_csi*((2*l_csi)/(r^3*cos(phi)^2) + (2*v*(csi + omega))/r^2 + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3)/(r^2*cos(phi)) + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r^2*cos(phi)) + (mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5))/(r*cos(phi)) - (3*cosPSIM*muM*cos(Dm)*sin(RA - RAm))/rM^3 - (3*cosPSIS*muS*cos(Ds)*sin(RA - RAs))/rS^3)/(r*cos(phi))) - l_v*(cos(phi)^2*(csi + omega)^2 + mue*((6*R^2*c20*(3*sin(phi)^2 - 1))/r^5 + (36*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^5 + (300*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^6 + (10*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^6 + (36*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^5 + (300*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^6 + (10*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^6) + (2*mue)/r^3 + n^2 + (muM*(3*cosPSIM^2 - 1))/rM^3 + (muS*(3*cosPSIS^2 - 1))/rS^3);
 
    dl_l = (l_csi*mue*((3*R^2*cos(phi)^2*(4*s22*sin(2*l) + 4*c22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(9*s33*sin(3*l) + 9*c33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(4*s32*sin(2*l) + 4*c32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4)))/(r^2*cos(phi)^2) - (l_n*mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/r^2 - l_v*mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5);
 
    dl_phi = l_n*(cos(phi)^2*(csi + omega)^2 - sin(phi)^2*(csi + omega)^2 + ((mue*((6*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (45*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^4 - (3*R^2*c20*cos(phi)^2)/r^3 - (6*R^2*sin(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 - (30*R^3*sin(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*c20*sin(phi)^2)/r^3 + (5*R^3*c30*sin(phi)^3)/r^4 - (15*R^3*cos(phi)^3*(c31*cos(l) + s31*sin(l)))/r^4 + (R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/(2*r^4) + (12*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (105*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (90*R^3*cos(phi)*sin(phi)^2*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) - (15*R^3*c30*cos(phi)^2*sin(phi))/r^4 + (45*R^3*cos(phi)*sin(phi)^2*(c31*cos(l) + s31*sin(l)))/r^4))/r - Psr*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*sin(phi) + cos(Dm)*cos(RA - RAm)*cos(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)))/rS^3)/r) + l_v*(mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4) + 2*r*cos(phi)*sin(phi)*(csi + omega)^2) - l_csi*(((mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/(r*cos(phi)) - (mue*sin(phi)*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)^2))/(r*cos(phi)) + 2*n*(csi + omega)*(tan(phi)^2 + 1) - (2*l_csi*sin(phi))/(r^2*cos(phi)^3) - (sin(phi)*((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3))/(r*cos(phi)^2));
 
    dl_v = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r;
 
    dl_csi = l_csi*((2*v)/r - 2*n*tan(phi)) - l_l - l_v*r*cos(phi)^2*(2*csi + 2*omega) + l_n*cos(phi)*sin(phi)*(2*csi + 2*omega);

    dl_n = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*tan(phi)*(csi + omega);
 

    % output
    dsph = [dr; dl; dphi; dv; dcsi; dn; dl_r; dl_l; dl_phi; dl_v; dl_csi; dl_n]; 
%     dsph = [dr; dl; dphi; dv; dcsi; dn];

end


function [RA, dec] = RaDec(cart_pos)
    r = sqrt(cart_pos(1)^2 + cart_pos(2)^2 + cart_pos(3)^2);
    l = cart_pos(1)/r;  m = cart_pos(2)/r; n = cart_pos(3)/r; 
    dec = asin(n); 
    
    if m > 0 
        RA = acos(l/cos(dec)); 
    else 
        RA = 2*pi - acos(l/cos(dec)); 
    end 

end 


function [c, ceq] = nonlcon(x, dat, grav, SRP, t0, tfd0, time, pert_selector, tt, ll)

    % NONLINEAR CONSTRAINTS FOR FMINCON
   
    r = x(1); l = x(2); phi = x(3);
    v = x(4); csi = x(5); n = x(6);

%     x0 = [r; l; phi; v; csi; n]; 
    x0 = [r; l; phi; v; csi; n; 0; 0; 0; 0; 0; 0];
    tprop = linspace(time, time + tfd0, 1000)./tt; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [~, xx] = ode113(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, pert_selector, tt, ll), tprop, x0, options);
    
    % define non linear constraints ------ SET SK BOX DIMENSION HERE!!!!!!
    final = xx; 
    c = [final(:,2) - deg2rad(60 + 0.05); final(:,3) - deg2rad(0 + 0.05); -final(:,2) + deg2rad(60 - 0.05); -final(:,3) + deg2rad(0 - 0.05)];
    ceq = [];  
end


function f = opt_solv(l, state, t_CONTROL, dat, grav, SRP, t0, pert_selector, ll, tt)

    xf = state.final; x0 = state.initial; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    initial = [x0; l]; 
    [~, xx] = ode113(@(t,dyn) SPHmotion(t, dyn, dat, grav, SRP, t0, pert_selector, tt, ll), t_CONTROL, initial, options);
    f = [xx(end,1)-xf(1); xx(end,2)-xf(2); xx(end,3)-xf(3);  xx(end,4)-xf(4); xx(end,5)-xf(5); xx(end,6)-xf(6)];

end 


function [m_dot] =  mass_int(~, m, acc, Isp, g0)
    
    m_dot = - (m*acc)/(Isp * g0); 

end

