#% GEO dynamics With GG --- FINDS FOURTH ORDER SOLUTION (TIME INDEPENDENT) of GEO controlled dynamics with GG perturbations only

#% EOP dynamics With 4th order GG + linear complete EOP -- SAVED FILE CONTAINS 4th ORDER COSTATE of GG PERTURBED DYNAMICS ONLY

import daceypy_import_helper  # noqa: F401

from time import perf_counter
from typing import Callable

import numpy as np
from numpy.linalg import norm
from scipy.integrate import odeint
from scipy.optimize import fsolve
from daceypy import DA, array
# import matplotlib.pyplot as plt


#SETUP
#Adimensionalization 
ll = 42165.8
tt = np.sqrt(ll**3/398600)


# EPOCH AND TARGETS -- TIME -- OPTIMAL TARGETS FROM MATLAB
hours = 3600                               
days = 24*hours
        
  
# t0 = np.loadtxt('t02010.txt', dtype = float)                                 # import initial datetime and GHA0 from matlab 
t0 = np.loadtxt('t02023.txt', dtype = float)
target = np.loadtxt('target_2023_BEST.txt', dtype = float)
tfd = np.loadtxt('tfd_BEST.txt', dtype = float)
tc = 1

tf1 = t0 + tfd[0]*days                                                         # final free drift time (in seconds) 
tf2 = tf1 + tc*days                                                            # final control time (in seconds)

                                                            


nit = 1000 
t_FREEDRIFT = np.linspace(t0, tf1, nit)/tt
t_CONTROL = np.linspace(tf1, tf2, nit)/tt

# GHA at t0 from matlab
G0 = np.loadtxt('G0.txt', dtype = float)


# Dynamics data
R = 6378.137/ll 
mue = 398600*tt**2/ll**3
muS = 1.327124400179870e+11*tt**2/ll**3
muM = 4.902801e+03*tt**2/ll**3
Rgeo = 42165.8/ll                              
omega = np.sqrt(mue/Rgeo**3)
om = omega
ln = 60  # nominal longitude

# GG perturbation potential data (values taken from 'vallado') 
c20 = -1.083e-3  
c21 = -2.414e-10  
c22 = 1.574e-6  
c30 = 2.532e-6  
c31 = 2.191e-6 
c32 = 3.089e-7  
c33 = 1.006e-7  
s21 = 1.543e-9  
s22 = -9.038e-7  
s31 = 2.687e-7 
s32 = -2.115e-7
s33 = 1.972e-7

# SRP parameters
m = 3000 # kg 
A = 100 # m^2
Cr = 1.5 
S = 1353 # W/m^2
c = 2.998*1e8 # speed of ligh



def ephMoon(MJD2000):
       
#ephMoon.m - Ephemerides (cartesian position and velocity) of the Moon.
    T_TDB = MJD2000/36525
    
    angles = np.array([(134.9 + 477198.85*T_TDB)* np.pi/180,
              (259.2 - 413335.38*T_TDB)* np.pi/180,
              (235.7 + 890534.23*T_TDB)* np.pi/180,
              (269.9 +  954397.7*T_TDB)* np.pi/180, 
              (357.5 +  35999.05*T_TDB)* np.pi/180, 
              (186.6 + 966404.05*T_TDB)* np.pi/180, 
              ( 93.3 + 483202.03*T_TDB)* np.pi/180, 
              (228.2 + 960400.87*T_TDB)* np.pi/180, 
              (318.3 +   6003.18*T_TDB)* np.pi/180,
              (217.6 -  407332.2*T_TDB)* np.pi/180,
              ])

    
    # Sinus of the first 10 angles
    s = np.sin(angles[0:10])
    
    # Cosinus of the first 4 angles
    c = np.cos(angles[0:4])
    
    
    # Compute L_ecl, phi_ecl, P and eps
    b = np.array([+6.29, -1.27, +0.66, +0.21, -0.19, -0.11])
    L_ecl =  (218.32 + 481267.883*T_TDB) + np.dot(b, s[0:6])
        
    phi_ecl = np.dot(np.array([+5.13, +0.28, -0.28, -0.17]), s[6:10])
    
    P =   0.9508 + np.dot(np.array([+0.0518, +0.0095, +0.0078, +0.0028]), c)
    
    eps = 23.439291 - 0.0130042*T_TDB - 1.64e-7*T_TDB**2 + 5.04e-7*T_TDB**3
    
    # Transform L_ecl, phi_ecl, P and eps in radians
    L_ecl   = L_ecl   * np.pi/180
    phi_ecl = phi_ecl * np.pi/180
    P       = P       * np.pi/180
    eps     = eps     * np.pi/180
    
    r = 1/np.sin(P) * 6378.16
    xP = r * np.array([np.cos(L_ecl)*np.cos(phi_ecl), np.cos(eps)*np.cos(phi_ecl)*np.sin(L_ecl) - np.sin(eps)*np.sin(phi_ecl), np.sin(eps)*np.cos(phi_ecl)*np.sin(L_ecl) + np.cos(eps)*np.sin(phi_ecl)])
    
    return xP


def uplanet(MJD2000):
    
    kep = np.array([0.0,0.0,0.0,0.0,0.0,0.0])
    DEG2RAD = np.pi/180
    KM  = 149597870.66
    
    #  T = JULIAN CENTURIES SINCE 31/12/1899 at 12:00
    T   = (MJD2000 + 36525)/36525.00
    kep[0] = 1.000000230
    kep[1] = 0.016751040 - 0.000041800*T - 0.0000001260*T**2
    kep[2] = 0.0
    kep[3] = 0.00
    kep[4] = 1.01220833333333333e+2 + 1.7191750*T + 4.52777777777777778e-4*T**2 + 3.33333333333333333e-6*T**3
    XM   = 3.599904975e+4 - 1.50277777777777778e-4*T - 3.33333333333333333e-6*T**2
    kep[5] = 3.58475844444444444e2 + XM*T
       
     
    kep[0]   = kep[0]*KM
    kep[2:6] = kep[2:6]*DEG2RAD
    kep[5]   = np.mod(kep[5], 2*np.pi)
    phi    = kep[5]
         
    for i in range(6):

        g = kep[5] - (phi-kep[1]*np.sin(phi)) 
        g_primo = (-1 + kep[1]*np.cos(phi))
        phi     = phi-g/g_primo
     
    
    theta = 2*np.arctan(np.sqrt((1 + kep[1])/(1 - kep[1]))*np.tan(phi/2));
    
    kep[5] = theta
    
    return kep


def kp2rv(a,e,i,OMEGA,omega,theta,mu):
    
    # From Keplerian to Cartesian
    
    R_OMEGA = np.array([[np.cos(OMEGA), np.sin(OMEGA), 0], [-np.sin(OMEGA), np.cos(OMEGA), 0], [0, 0, 1]])
    
    R_i = np.array([[1, 0, 0], [0, np.cos(i), np.sin(i)], [0, -np.sin(i), np.cos(i)]])
    
    R_omega = np.array([[np.cos(omega), np.sin(omega), 0], [-np.sin(omega), np.cos(omega), 0], [0, 0, 1]])
    
    T_ge2pf = np.dot(R_omega,R_i)
    T_ge2pf = np.dot(T_ge2pf, R_OMEGA)
    
    T_pf2ge = np.transpose(T_ge2pf)
    
      
    p = a*(1 - e**2)
    h = np.sqrt(mu*p)
    
    r_pf = np.array([p/(1 + e*np.cos(theta))*np.cos(theta), p/(1 + e*np.cos(theta))*np.sin(theta), 0])
    
    v_pf = np.array([(mu/h)*(- np.sin(theta)), (mu/h)*(e + np.cos(theta)), 0])
    
    r_ge = np.dot(T_pf2ge, r_pf)
    v_ge = np.dot(T_pf2ge, v_pf)
    
    r = r_ge
    v = v_ge
    
    return r


def RaDec(cart_pos):
    r = np.sqrt(cart_pos[0]**2 + cart_pos[1]**2 + cart_pos[2]**2);
    l = cart_pos[0]/r;  m = cart_pos[1]/r; n = cart_pos[2]/r; 
    dec = np.arcsin(n); 
    
    if m > 0: 
        RA = np.arccos(l/np.cos(dec)) 
    else: 
        RA = 2*np.pi - np.arccos(l/np.cos(dec)) 
        
    return RA, dec


def SPHmotion_propag(dyn, t):
    
    # GEO MOTION PROPAGATION IN SPHERICAL COORDINATES
   
    r     = dyn[0]
    eps   = dyn[1]
    phi   = dyn[2]
    v     = dyn[3]
    csi   = dyn[4]
    n     = dyn[5]
    
    l_r   = dyn[6]
    l_l   = dyn[7]  
    l_phi = dyn[8]
    l_v   = dyn[9]
    l_csi = dyn[10]
    l_n   = dyn[11]
               
    l = ln*np.pi/180 + eps
         
    # GG PERTURBATIONS
    aPg_r = -mue*((3*R**2 * c20*(3*(np.sin(phi))**2 - 1))/(2*r**4) + (9*R**2 * (np.cos(phi))**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (60*R**3 * (np.cos(phi))**3 * (s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (2*R**3 * c30*np.sin(phi)*(5*(np.sin(phi))**2 - 3))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (60*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (2*R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5)
    aPg_l =  -mue*((3*R**2 * (np.cos(phi))**2 * (2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3 * (np.cos(phi))**3 * (3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2 * np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4))/(r*np.cos(phi))
    aPg_phi = mue*((15*R**3 * (np.cos(phi))**3 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2 * (np.cos(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2 * (np.sin(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3 * c30*np.cos(phi)*(5*(np.sin(phi))**2 - 3))/(2*r**4) - (30*R**3 * np.cos(phi)*(np.sin(phi))**2 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3 * c30*np.cos(phi)*(np.sin(phi))**2)/r**4 - (R**3 * np.sin(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2 * np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2 * c20*np.cos(phi)*np.sin(phi))/r**3)/r
    
    # % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt             #% time in days (Dimensional for ephemeris)
    MJD2000 = tdays

    eps = np.pi * 23.44 /180
    ecl = np.array([[1, 0, 0], [0, np.cos(eps), -np.sin(eps)], [0, np.sin(eps), np.cos(eps)]])   #rotation ecliptic/equatorial
    kep = uplanet(MJD2000)
    r_E = kp2rv(kep[0], kep[1], kep[2], kep[3], kep[4], kep[5], muS)
    r_S = - r_E /ll
       
    r_S = np.dot(ecl, r_S)                  #SUN position inertial geocentric equatorial frame
    r_M = ephMoon(MJD2000)           # MOOn ....
    r_M = r_M /ll
      
    Ds =   np.arcsin(r_S[2]/norm(r_S))
    RAs =  np.arctan2( r_S[1]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ), r_S[0]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ) ) 
    Dm =   np.arcsin(r_M[2]/norm(r_M))
    RAm =  np.arctan2( r_M[1]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ), r_M[0]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ) ) 

    omega_dim = omega/tt
    RA = l + omega_dim * (t *tt - t0)
    
    cosPSIS = np.sin(phi) * np.sin(Ds) + np.cos(phi) * np.cos(Ds) * np.cos(RA - RAs)
    cosPSIM = np.sin(phi) * np.sin(Dm) + np.cos(phi) * np.cos(Dm) * np.cos(RA - RAm)

    rM = norm(r_M)
    rS = norm(r_S)

    a3r   = muS/rS**3 * r *(3*cosPSIS**2 - 1) + muM/rM**3 * r *(3*cosPSIM**2 - 1)
    a3l   = -3*muS/rS**3 * r * cosPSIS * np.cos(Ds) * np.sin(RA - RAs) - 3*muM/rM**3 * r * cosPSIM * np.cos(Dm) * np.sin(RA - RAm) 
    a3phi = 3*muS/rS**3 * r * cosPSIS * (np.cos(phi) * np.sin(Ds) - np.sin(phi) * np.cos(Ds) * np.cos(RA - RAs)) + 3*muM/rM**3 * r * cosPSIM * (np.cos(phi) * np.sin(Dm) - np.sin(phi) * np.cos(Dm) * np.cos(RA - RAm)) 


    # SRP PERTURBATIONS
    #     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/m        

    Psr = Psr * 1e-3 
    Psr = Psr * tt**2/ll 

    aSRPr   = - Psr * cosPSIS 
    aSRPl   =   Psr * np.cos(Ds) * np.sin(RA - RAs) 
    aSRPphi = - Psr * (np.sin(Ds) * np.cos(phi) - np.cos(Ds) * np.sin(phi) * np.cos(RA - RAs))
     
    
    aP_r   = aPg_r + a3r + aSRPr;
    aP_l   = aPg_l + a3l + aSRPl;
    aP_phi = aPg_phi + a3phi + aSRPphi;

    #DYNAMICS (CONTROLLED)
    Ddyn0 = v
    Ddyn1 = csi
    Ddyn2 = n
    Ddyn3 = -mue/r**2 + r*n**2 + r*(csi + omega)**2 *(np.cos(phi))**2 + aP_r - l_v 
    Ddyn4 = 2*n*(csi + omega)*np.tan(phi) - 2*v/r *(csi + omega) + aP_l/(r * np.cos(phi)) - l_csi/(r * np.cos(phi))**2 
    Ddyn5 = -2*v/r *n - (csi + omega)**2 *np.sin(phi)*np.cos(phi) + aP_phi/r - l_n/r**2 
    
    Ddyn6 = l_n*(((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r - Psr*(np.sin(Ds)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAs)*np.sin(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r**2 - (2*l_n)/r**3 + ((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r**2 + (mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4))/r - (3*cosPSIM*muM*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 - (3*cosPSIS*muS*(np.sin(Ds)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r - (2*n*v)/r**2) - l_csi*((2*l_csi)/(r**3*np.cos(phi)**2) + (2*v*(csi + omega))/r**2 + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Dm)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Dm)*np.sin(RA - RAs))/rS**3)/(r**2*np.cos(phi)) + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r**2*np.cos(phi)) + (mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5))/(r*np.cos(phi)) - (3*cosPSIM*muM*np.cos(Dm)*np.sin(RA - RAm))/rM**3 - (3*cosPSIS*muS*np.cos(Dm)*np.sin(RA - RAs))/rS**3)/(r*np.cos(phi))) - l_v*(np.cos(phi)**2*(csi + omega)**2 + mue*((6*R**2*c20*(3*np.sin(phi)**2 - 1))/r**5 + (36*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**5 + (300*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**6 + (10*R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/r**6 + (36*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**5 + (300*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**6 + (10*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**6) + (2*mue)/r**3 + n**2 + (muM*(3*cosPSIM**2 - 1))/rM**3 + (muS*(3*cosPSIS**2 - 1))/rS**3)
    Ddyn7 = (l_csi*mue*((3*R**2*np.cos(phi)**2*(4*s22*np.sin(2*l) + 4*c22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(9*s33*np.sin(3*l) + 9*c33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(4*s32*np.sin(2*l) + 4*c32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4)))/(r**2*np.cos(phi)**2) - (l_n*mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/r**2 - l_v*mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5)
    Ddyn8 = l_n*(np.cos(phi)**2*(csi + omega)**2 - np.sin(phi)**2*(csi + omega)**2 + ((mue*((6*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (45*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 - (3*R**2*c20*np.cos(phi)**2)/r**3 - (6*R**2*np.sin(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 - (30*R**3*np.sin(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*c20*np.sin(phi)**2)/r**3 + (5*R**3*c30*np.sin(phi)**3)/r**4 - (15*R**3*np.cos(phi)**3*(c31*np.cos(l) + s31*np.sin(l)))/r**4 + (R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) + (12*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (105*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (90*R**3*np.cos(phi)*np.sin(phi)**2*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) - (15*R**3*c30*np.cos(phi)**2*np.sin(phi))/r**4 + (45*R**3*np.cos(phi)*np.sin(phi)**2*(c31*np.cos(l) + s31*np.sin(l)))/r**4))/r - Psr*(np.sin(Ds)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAs)*np.cos(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAm)*np.cos(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAs)*np.cos(phi)))/rS**3)/r) + l_v*(mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4) + 2*r*np.cos(phi)*np.sin(phi)*(csi + omega)**2) - l_csi*(((mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/(r*np.cos(phi)) - (mue*np.sin(phi)*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)**2))/(r*np.cos(phi)) + 2*n*(csi + omega)*(np.tan(phi)**2 + 1) - (2*l_csi*np.sin(phi))/(r**2*np.cos(phi)**3) - (np.sin(phi)*((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Dm)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Dm)*np.sin(RA - RAs))/rS**3))/(r*np.cos(phi)**2))
    Ddyn9 = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r
    Ddyn10 = l_csi*((2*v)/r - 2*n*np.tan(phi)) - l_l - l_v*r*np.cos(phi)**2*(2*csi + 2*omega) + l_n*np.cos(phi)*np.sin(phi)*(2*csi + 2*omega)
    Ddyn11 = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*np.tan(phi)*(csi + omega)
         

    Ddyn = [Ddyn0, Ddyn1, Ddyn2, Ddyn3, Ddyn4, Ddyn5, Ddyn6, Ddyn7, Ddyn8, Ddyn9, Ddyn10, Ddyn11]
    
    return Ddyn


def SPHmotionGG_CONTROL(dyn: array, t: float) -> array:   # defines x vector of states as a DA array by calling function array
    
    r     = dyn[0]
    eps   = dyn[1]
    phi   = dyn[2]
    v     = dyn[3]
    csi   = dyn[4]
    n     = dyn[5]
    
    l_r   = dyn[6]
    l_l   = dyn[7]  
    l_phi = dyn[8]
    l_v   = dyn[9]
    l_csi = dyn[10]
    l_n   = dyn[11]
               
    l = ln*np.pi/180 + eps
         
    #PERTURBATIONS
    aPg_r = -mue*((3*R**2 * c20*(3*(phi.sin())**2 - 1))/(2*r**4) + (9*R**2 * (phi.cos())**2*(s22*(2*l).sin() + c22*(2*l).cos()))/r**4 + (60*R**3 * (phi.cos())**3 * (s33*(3*l).sin() + c33*(3*l).cos()))/r**5 + (2*R**3 * c30*phi.sin()*(5*(phi.sin())**2 - 3))/r**5 + (9*R**2*phi.cos()*phi.sin()*(c21*l.cos() + s21*l.sin()))/r**4 + (60*R**3 * (phi.cos())**2 * phi.sin()*(s32*(2*l).sin() + c32*(2*l).cos()))/r**5 + (2*R**3 * phi.cos()*(15*(phi.sin())**2 - 3)*(c31*l.cos() + s31*l.sin()))/r**5)
    aPg_l =  -mue*((3*R**2 * (phi.cos())**2 * (2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**3 + (15*R**3 * (phi.cos())**3 * (3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**4 + (3*R**2 * phi.cos()*phi.sin()*(c21*l.sin() - s21*l.cos()))/r**3 + (15*R**3 * (phi.cos())**2 * phi.sin()*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (R**3 * phi.cos()*(15*(phi.sin())**2 - 3)*(c31*l.sin() - s31*l.cos()))/(2*r**4))
    aPg_phi = mue*((15*R**3 * (phi.cos())**3 * (s32*(2*l).sin() + c32*(2*l).cos()))/r**4 + (3*R**2 * (phi.cos())**2 * (c21*l.cos() + s21*l.sin()))/r**3 - (3*R**2 * (phi.sin())**2 * (c21*l.cos() + s21*l.sin()))/r**3 + (R**3 * c30*phi.cos()*(5*(phi.sin())**2 - 3))/(2*r**4) - (30*R**3 * phi.cos()*(phi.sin())**2 * (s32*(2*l).sin() + c32*(2*l).cos()))/r**4 - (45*R**3 * (phi.cos())**2 * phi.sin()*(s33*(3*l).sin() + c33*(3*l).cos()))/r**4 + (5*R**3 * c30*phi.cos()*(phi.sin())**2)/r**4 - (R**3 * phi.sin()*(15*(phi.sin())**2 - 3)*(c31*l.cos() + s31*l.sin()))/(2*r**4) + (15*R**3 * (phi.cos())**2 * phi.sin()*(c31*l.cos() + s31*l.sin()))/r**4 - (6*R**2 * phi.cos()*phi.sin()*(s22*(2*l).sin() + c22*(2*l).cos()))/r**3 + (3*R**2 * c20*phi.cos()*phi.sin())/r**3)
    
    
    Ddyn = array.zeros(12)
    
    #DYNAMICS (CONTROLLED)
    Ddyn[0] = v
    Ddyn[1] = csi
    Ddyn[2] = n
    Ddyn[3] = -mue/r**2 + r*n**2 + r*(csi + omega)**2 *(phi.cos())**2 + aPg_r - l_v 
    Ddyn[4] = 2*n*(csi + omega)*phi.tan() - 2*v/r *(csi + omega) + aPg_l/(r * phi.cos())**2 - l_csi/(r * phi.cos())**2 
    Ddyn[5] = -2*v/r *n - (csi + omega)**2 *phi.sin()*phi.cos() + aPg_phi/r**2 - l_n/r**2 
        
    #COSTATE DYAMICS --- from matlab symbolic toolbox
    Ddyn[6] = - l_n*((2*l_n)/r**3 + (2*n*v)/r**2 - (2*mue*((15*R**3*phi.cos()**3*(s32*(2*l).sin() + c32*(2*l).cos()))/r**4 + (3*R**2*phi.cos()**2*(c21*l.cos() + s21*l.sin()))/r**3 - (3*R**2*phi.sin()**2*(c21*l.cos() + s21*l.sin()))/r**3 + (R**3*c30*phi.cos()*(5*phi.sin()**2 - 3))/(2*r**4) - (30*R**3*phi.cos()*phi.sin()**2*(s32*(2*l).sin() + c32*(2*l).cos()))/r**4 - (45*R**3*phi.cos()**2*phi.sin()*(s33*(3*l).sin() + c33*(3*l).cos()))/r**4 + (5*R**3*c30*phi.cos()*phi.sin()**2)/r**4 - (R**3*phi.sin()*(15*phi.sin()**2 - 3)*(c31*l.cos() + s31*l.sin()))/(2*r**4) + (15*R**3*phi.cos()**2*phi.sin()*(c31*l.cos() + s31*l.sin()))/r**4 - (6*R**2*phi.cos()*phi.sin()*(s22*(2*l).sin() + c22*(2*l).cos()))/r**3 + (3*R**2*c20*phi.cos()*phi.sin())/r**3))/r**3 - (mue*((60*R**3*phi.cos()**3*(s32*(2*l).sin() + c32*(2*l).cos()))/r**5 + (9*R**2*phi.cos()**2*(c21*l.cos() + s21*l.sin()))/r**4 - (9*R**2*phi.sin()**2*(c21*l.cos() + s21*l.sin()))/r**4 + (2*R**3*c30*phi.cos()*(5*phi.sin()**2 - 3))/r**5 - (120*R**3*phi.cos()*phi.sin()**2*(s32*(2*l).sin() + c32*(2*l).cos()))/r**5 - (180*R**3*phi.cos()**2*phi.sin()*(s33*(3*l).sin() + c33*(3*l).cos()))/r**5 + (20*R**3*c30*phi.cos()*phi.sin()**2)/r**5 - (2*R**3*phi.sin()*(15*phi.sin()**2 - 3)*(c31*l.cos() + s31*l.sin()))/r**5 + (60*R**3*phi.cos()**2*phi.sin()*(c31*l.cos() + s31*l.sin()))/r**5 - (18*R**2*phi.cos()*phi.sin()*(s22*(2*l).sin() + c22*(2*l).cos()))/r**4 + (9*R**2*c20*phi.cos()*phi.sin())/r**4))/r**2) - l_v*(phi.cos()**2*(csi + omega)**2 + mue*((6*R**2*c20*(3*phi.sin()**2 - 1))/r**5 + (36*R**2*phi.cos()**2*(s22*(2*l).sin() + c22*(2*l).cos()))/r**5 + (300*R**3*phi.cos()**3*(s33*(3*l).sin() + c33*(3*l).cos()))/r**6 + (10*R**3*c30*phi.sin()*(5*phi.sin()**2 - 3))/r**6 + (36*R**2*phi.cos()*phi.sin()*(c21*l.cos() + s21*l.sin()))/r**5 + (300*R**3*phi.cos()**2*phi.sin()*(s32*(2*l).sin() + c32*(2*l).cos()))/r**6 + (10*R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.cos() + s31*l.sin()))/r**6) + (2*mue)/r**3 + n**2) - l_csi*((2*l_csi)/(r**3*phi.cos()**2) + (2*v*(csi + omega))/r**2 + (2*mue*((3*R**2*phi.cos()**2*(2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**3 + (15*R**3*phi.cos()**3*(3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**4 + (3*R**2*phi.cos()*phi.sin()*(c21*l.sin() - s21*l.cos()))/r**3 + (15*R**3*phi.cos()**2*phi.sin()*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.sin() - s31*l.cos()))/(2*r**4)))/(r**3*phi.cos()**2) + (mue*((9*R**2*phi.cos()**2*(2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**4 + (60*R**3*phi.cos()**3*(3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**5 + (9*R**2*phi.cos()*phi.sin()*(c21*l.sin() - s21*l.cos()))/r**4 + (60*R**3*phi.cos()**2*phi.sin()*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**5 + (2*R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.sin() - s31*l.cos()))/r**5))/(r**2*phi.cos()**2))
    Ddyn[7] = (l_csi*mue*((3*R**2*phi.cos()**2*(4*s22*(2*l).sin() + 4*c22*(2*l).cos()))/r**3 + (15*R**3*phi.cos()**3*(9*s33*(3*l).sin() + 9*c33*(3*l).cos()))/r**4 + (3*R**2*phi.cos()*phi.sin()*(c21*l.cos() + s21*l.sin()))/r**3 + (15*R**3*phi.cos()**2*phi.sin()*(4*s32*(2*l).sin() + 4*c32*(2*l).cos()))/r**4 + (R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.cos() + s31*l.sin()))/(2*r**4)))/(r**2*phi.cos()**2) - (l_n*mue*((3*R**2*phi.sin()**2*(c21*l.sin() - s21*l.cos()))/r**3 - (3*R**2*phi.cos()**2*(c21*l.sin() - s21*l.cos()))/r**3 - (15*R**3*phi.cos()**3*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (30*R**3*phi.cos()*phi.sin()**2*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (45*R**3*phi.cos()**2*phi.sin()*(3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**4 + (R**3*phi.sin()*(15*phi.sin()**2 - 3)*(c31*l.sin() - s31*l.cos()))/(2*r**4) - (15*R**3*phi.cos()**2*phi.sin()*(c31*l.sin() - s31*l.cos()))/r**4 + (6*R**2*phi.cos()*phi.sin()*(2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**3))/r**2 - l_v*mue*((9*R**2*phi.cos()**2*(2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**4 + (60*R**3*phi.cos()**3*(3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**5 + (9*R**2*phi.cos()*phi.sin()*(c21*l.sin() - s21*l.cos()))/r**4 + (60*R**3*phi.cos()**2*phi.sin()*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**5 + (2*R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.sin() - s31*l.cos()))/r**5)
    Ddyn[8] = l_n*(phi.cos()**2*(csi + omega)**2 - phi.sin()**2*(csi + omega)**2 + (mue*((6*R**2*phi.cos()**2*(s22*(2*l).sin() + c22*(2*l).cos()))/r**3 + (45*R**3*phi.cos()**3*(s33*(3*l).sin() + c33*(3*l).cos()))/r**4 - (3*R**2*c20*phi.cos()**2)/r**3 - (6*R**2*phi.sin()**2*(s22*(2*l).sin() + c22*(2*l).cos()))/r**3 - (30*R**3*phi.sin()**3*(s32*(2*l).sin() + c32*(2*l).cos()))/r**4 + (3*R**2*c20*phi.sin()**2)/r**3 + (5*R**3*c30*phi.sin()**3)/r**4 - (15*R**3*phi.cos()**3*(c31*l.cos() + s31*l.sin()))/r**4 + (R**3*c30*phi.sin()*(5*phi.sin()**2 - 3))/(2*r**4) + (12*R**2*phi.cos()*phi.sin()*(c21*l.cos() + s21*l.sin()))/r**3 + (105*R**3*phi.cos()**2*phi.sin()*(s32*(2*l).sin() + c32*(2*l).cos()))/r**4 - (90*R**3*phi.cos()*phi.sin()**2*(s33*(3*l).sin() + c33*(3*l).cos()))/r**4 + (R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.cos() + s31*l.sin()))/(2*r**4) - (15*R**3*c30*phi.cos()**2*phi.sin())/r**4 + (45*R**3*phi.cos()*phi.sin()**2*(c31*l.cos() + s31*l.sin()))/r**4))/r**2) - l_csi*(2*n*(csi + omega)*(phi.tan()**2 + 1) - (2*l_csi*phi.sin())/(r**2*phi.cos()**3) + (mue*((3*R**2*phi.sin()**2*(c21*l.sin() - s21*l.cos()))/r**3 - (3*R**2*phi.cos()**2*(c21*l.sin() - s21*l.cos()))/r**3 - (15*R**3*phi.cos()**3*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (30*R**3*phi.cos()*phi.sin()**2*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (45*R**3*phi.cos()**2*phi.sin()*(3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**4 + (R**3*phi.sin()*(15*phi.sin()**2 - 3)*(c31*l.sin() - s31*l.cos()))/(2*r**4) - (15*R**3*phi.cos()**2*phi.sin()*(c31*l.sin() - s31*l.cos()))/r**4 + (6*R**2*phi.cos()*phi.sin()*(2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**3))/(r**2*phi.cos()**2) - (2*mue*phi.sin()*((3*R**2*phi.cos()**2*(2*c22*(2*l).sin() - 2*s22*(2*l).cos()))/r**3 + (15*R**3*phi.cos()**3*(3*c33*(3*l).sin() - 3*s33*(3*l).cos()))/r**4 + (3*R**2*phi.cos()*phi.sin()*(c21*l.sin() - s21*l.cos()))/r**3 + (15*R**3*phi.cos()**2*phi.sin()*(2*c32*(2*l).sin() - 2*s32*(2*l).cos()))/r**4 + (R**3*phi.cos()*(15*phi.sin()**2 - 3)*(c31*l.sin() - s31*l.cos()))/(2*r**4)))/(r**2*phi.cos()**3)) + l_v*(mue*((60*R**3*phi.cos()**3*(s32*(2*l).sin() + c32*(2*l).cos()))/r**5 + (9*R**2*phi.cos()**2*(c21*l.cos() + s21*l.sin()))/r**4 - (9*R**2*phi.sin()**2*(c21*l.cos() + s21*l.sin()))/r**4 + (2*R**3*c30*phi.cos()*(5*phi.sin()**2 - 3))/r**5 - (120*R**3*phi.cos()*phi.sin()**2*(s32*(2*l).sin() + c32*(2*l).cos()))/r**5 - (180*R**3*phi.cos()**2*phi.sin()*(s33*(3*l).sin() + c33*(3*l).cos()))/r**5 + (20*R**3*c30*phi.cos()*phi.sin()**2)/r**5 - (2*R**3*phi.sin()*(15*phi.sin()**2 - 3)*(c31*l.cos() + s31*l.sin()))/r**5 + (60*R**3*phi.cos()**2*phi.sin()*(c31*l.cos() + s31*l.sin()))/r**5 - (18*R**2*phi.cos()*phi.sin()*(s22*(2*l).sin() + c22*(2*l).cos()))/r**4 + (9*R**2*c20*phi.cos()*phi.sin())/r**4) + 2*r*phi.cos()*phi.sin()*(csi + omega)**2)
    Ddyn[9] = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r
    Ddyn[10] = l_csi*((2*v)/r - 2*n*phi.tan()) - l_l - l_v*r*phi.cos()**2*(2*csi + 2*omega) + l_n*phi.cos()*phi.sin()*(2*csi + 2*omega)
    Ddyn[11] = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*phi.tan()*(csi + omega)

    return Ddyn


def RK78(Y0: array, X0: float, X1: float, f: Callable[[array, float], array]):

    Y0 = Y0.copy()

    N = len(Y0)

    H0 = 0.001
    HS = 0.1
    H1 = 100.0
    EPS = 1.e-12
    BS = 20 * EPS

    Z = array.zeros((N, 16))
    Y1 = array.zeros(N)

    VIHMAX = 0.0

    HSQR = 1.0 / 9.0
    A = np.zeros(13)
    B = np.zeros((13, 12))
    C = np.zeros(13)
    D = np.zeros(13)

    A = np.array([
        0.0, 1.0/18.0, 1.0/12.0, 1.0/8.0, 5.0/16.0, 3.0/8.0, 59.0/400.0,
        93.0/200.0, 5490023248.0/9719169821.0, 13.0/20.0,
        1201146811.0/1299019798.0, 1.0, 1.0,
    ])

    B[1, 0] = 1.0/18.0
    B[2, 0] = 1.0/48.0
    B[2, 1] = 1.0/16.0
    B[3, 0] = 1.0/32.0
    B[3, 2] = 3.0/32.0
    B[4, 0] = 5.0/16.0
    B[4, 2] = -75.0/64.0
    B[4, 3] = 75.0/64.0
    B[5, 0] = 3.0/80.0
    B[5, 3] = 3.0/16.0
    B[5, 4] = 3.0/20.0
    B[6, 0] = 29443841.0/614563906.0
    B[6, 3] = 77736538.0/692538347.0
    B[6, 4] = -28693883.0/1125000000.0
    B[6, 5] = 23124283.0/1800000000.0
    B[7, 0] = 16016141.0/946692911.0
    B[7, 3] = 61564180.0/158732637.0
    B[7, 4] = 22789713.0/633445777.0
    B[7, 5] = 545815736.0/2771057229.0
    B[7, 6] = -180193667.0/1043307555.0
    B[8, 0] = 39632708.0/573591083.0
    B[8, 3] = -433636366.0/683701615.0
    B[8, 4] = -421739975.0/2616292301.0
    B[8, 5] = 100302831.0/723423059.0
    B[8, 6] = 790204164.0/839813087.0
    B[8, 7] = 800635310.0/3783071287.0
    B[9, 0] = 246121993.0/1340847787.0
    B[9, 3] = -37695042795.0/15268766246.0
    B[9, 4] = -309121744.0/1061227803.0
    B[9, 5] = -12992083.0/490766935.0
    B[9, 6] = 6005943493.0/2108947869.0
    B[9, 7] = 393006217.0/1396673457.0
    B[9, 8] = 123872331.0/1001029789.0
    B[10, 0] = -1028468189.0/846180014.0
    B[10, 3] = 8478235783.0/508512852.0
    B[10, 4] = 1311729495.0/1432422823.0
    B[10, 5] = -10304129995.0/1701304382.0
    B[10, 6] = -48777925059.0/3047939560.0
    B[10, 7] = 15336726248.0/1032824649.0
    B[10, 8] = -45442868181.0/3398467696.0
    B[10, 9] = 3065993473.0/597172653.0
    B[11, 0] = 185892177.0/718116043.0
    B[11, 3] = -3185094517.0/667107341.0
    B[11, 4] = -477755414.0/1098053517.0
    B[11, 5] = -703635378.0/230739211.0
    B[11, 6] = 5731566787.0/1027545527.0
    B[11, 7] = 5232866602.0/850066563.0
    B[11, 8] = -4093664535.0/808688257.0
    B[11, 9] = 3962137247.0/1805957418.0
    B[11, 10] = 65686358.0/487910083.0
    B[12, 0] = 403863854.0/491063109.0
    B[12, 3] = - 5068492393.0/434740067.0
    B[12, 4] = -411421997.0/543043805.0
    B[12, 5] = 652783627.0/914296604.0
    B[12, 6] = 11173962825.0/925320556.0
    B[12, 7] = -13158990841.0/6184727034.0
    B[12, 8] = 3936647629.0/1978049680.0
    B[12, 9] = -160528059.0/685178525.0
    B[12, 10] = 248638103.0/1413531060.0

    C = np.array([
        14005451.0/335480064.0, 0.0, 0.0, 0.0, 0.0, -59238493.0/1068277825.0,
        181606767.0/758867731.0, 561292985.0/797845732.0,
        -1041891430.0/1371343529.0, 760417239.0/1151165299.0,
        118820643.0/751138087.0, -528747749.0/2220607170.0, 1.0/4.0,
    ])

    D = np.array([
        13451932.0/455176623.0, 0.0, 0.0, 0.0, 0.0, -808719846.0/976000145.0,
        1757004468.0/5645159321.0, 656045339.0/265891186.0,
        -3867574721.0/1518517206.0, 465885868.0/322736535.0,
        53011238.0/667516719.0, 2.0/45.0, 0.0,
    ])

    Z[:, 0] = Y0

    H = abs(HS)
    HH0 = abs(H0)
    HH1 = abs(H1)
    X = X0
    RFNORM = 0.0
    ERREST = 0.0

    while X != X1:

        # compute new stepsize
        if RFNORM != 0:
            H = H * min(4.0, np.exp(HSQR * np.log(EPS / RFNORM)))
        if abs(H) > abs(HH1):
            H = HH1
        elif abs(H) < abs(HH0) * 0.99:
            H = HH0
            print("--- WARNING, MINIMUM STEPSIZE REACHED IN RK")

        if (X + H - X1) * H > 0:
            H = X1 - X

        for j in range(13):

            for i in range(N):

                Y0[i] = 0.0
                # EVALUATE RHS AT 13 POINTS
                for k in range(j):
                    Y0[i] = Y0[i] + Z[i, k + 3] * B[j, k]

                Y0[i] = H * Y0[i] + Z[i, 0]

            Y1 = f(Y0, X + H * A[j])

            for i in range(N):
                Z[i, j + 3] = Y1[i]

        for i in range(N):

            Z[i, 1] = 0.0
            Z[i, 2] = 0.0
            # EXECUTE 7TH,8TH ORDER STEPS
            for j in range(13):
                Z[i, 1] = Z[i, 1] + Z[i, j + 3] * D[j]
                Z[i, 2] = Z[i, 2] + Z[i, j + 3] * C[j]

            Y1[i] = (Z[i, 2] - Z[i, 1]) * H
            Z[i, 2] = Z[i, 2] * H + Z[i, 0]

        Y1cons = Y1.cons()

        # ESTIMATE ERROR AND DECIDE ABOUT BACKSTEP
        RFNORM = np.linalg.norm(Y1cons, np.inf)  # type: ignore
        if RFNORM > BS and abs(H / H0) > 1.2:
            H = H / 3.0
            RFNORM = 0
        else:
            for i in range(N):
                Z[i, 0] = Z[i, 2]
            X = X + H
            VIHMAX = max(VIHMAX, H)
            ERREST = ERREST + RFNORM

    Y1 = Z[:, 0]

    return Y1
 


#%% FREE DRIFT PROPAGATION (no control --- initial control set to 0. NO DA VARIABLES)

#initialize state and costate (costate = 0 -- no control applied here)
dyn0_FD = [target[0,0], target[1,0] - ln*np.pi/180, target[2,0], target[3,0], target[4,0], target[5,0],  0, 0, 0, 0, 0, 0]

# Compute final state 
with DA.cache_manager():  # optional, for efficiency
       FDstate = odeint(SPHmotion_propag, dyn0_FD, t_FREEDRIFT)

final_FD = FDstate[nit-1,:]
 

#%% CONTROL SECTION with DA

exp_order = 4
DA.init(exp_order, 12)


dyn0 = array.identity(12)       # initialize state + costate vector reference (EXPANSION POINT) 
dyn0[0]  += 42165.8/ll
dyn0[1]  += 0
dyn0[2]  += 0
dyn0[3]  += 0
dyn0[4]  += 0
dyn0[5]  += 0

dyn0[6]  += 0
dyn0[7]  += 0
dyn0[8]  += 0
dyn0[9]  += 0
dyn0[10] += 0
dyn0[11] += 0


# Set final reference conditions 

Xf_ref = array.zeros(6)
Xf_ref[0] += target[0,1]
Xf_ref[1] += target[1,1] - ln*np.pi/180
Xf_ref[2] += target[2,1]
Xf_ref[3] += target[3,1]
Xf_ref[4] += target[4,1]
Xf_ref[5] += target[5,1]

                                     

# COMPUTE exact solution using simple shooting tecnique ......

# Compute polynomial map of final state 
T0 = perf_counter()       # time RquiRd for integration.. elapsed time 
with DA.cache_manager():  # optional, for efficiency
       Xf = RK78(dyn0, tf1/tt, tf2/tt, SPHmotionGG_CONTROL)
T1 = perf_counter()

# print(str(Xf))
# print(f'{Xf. cons()}')
# print(f'deltaXf = {xf_Rf - Xf[:4].cons()}')
# print(f'{Xf.linear()}')
print(f"Info: time RquiRd for integration = {T1 - T0} s")


# BUILD MAP OF DEFECTS AND INVERT THE POL TO Find Dlambdai
LambdaF = Xf[6:12] 
# Q = np.array([1, 100, 10, 100, 10, 10])

C = (Xf[:6] - Xf_ref)      # Map of DEFECTS on final state (adimensional)


# print(str(C))

# Mxf = Xf[:6]

I = array.identity(6)

M_dir = C.concat(I)

M_dir = M_dir - M_dir.cons()

M_inv = M_dir.invert()


cval = - C.cons()
#print(str(M_inv))

# [C = 0, DeltaX0] 
F = np.array([cval[0], cval[1], cval[2], cval[3], cval[4], cval[5], final_FD[0] - dyn0[0].cons(), final_FD[1], final_FD[2], final_FD[3], final_FD[4], final_FD[5]])       # set final constraint = 0 to match pos and vel, concatenated with initial perturbed pos and vel 

Initial_conditions = (M_inv).eval(F)

# print(f"Delta initial conditions (NON DIMENSIONAL):\n{Initial_conditions}\n")

# print(f"Delta initial conditions (ADIMENSIONAL):\n{Initial_conditions}\n")


LAMBDA0 = Initial_conditions[6:]

# np.savetxt('LAMBDA0_GG.txt', LAMBDA0, fmt='%.16f')










