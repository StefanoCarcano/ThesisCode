clearvars; close all; clc;


% SCRIPT PLOTTING THE ONE-CYCLE STATION KEEPING RESULTS for Energy Optimal Problem
% TAKE DATA FROM PYTHON ONE-CYCLE CODE
% TAKE DATA FROM TARGET OPTIMIZATION CODE

%% DIMENSIONALIZATION and SETUP
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem)

% Performance parameters
Mi = 3000; %initial mass kg
Isp = 3800; % spec. impulse s
g0 = 9.81;  % m/s^2

% TIME
hours = 3600;                               
days = 24*hours;

% t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                             %initial time MJD2000 (seconds)
t0 = date2mjd2000([2023, 01, 01, 0, 0, 0])*days;                             %initial time MJD2000 (seconds)

tc = 1;                             % control duration
tfd = importdata('tfd_BEST.txt');   % Free Drift duration (from target optimization procedure)
 
tf1 = t0 + tfd(1)*days;                                                          
tf2 = tf1 + tc*days;                                                           
nit = 1000; 
t_FREEDRIFT = linspace(t0, tf1, nit);
t_CONTROL = linspace(tf1, tf2, nit);

%% LOAD DATA FROM DACE
sph_FD = importdata('FreeDrift.txt');           % FREE DRIFT TRACK
sph_C1 = importdata('ControlState1.txt');       % LINEAR CONTROL TRACK
sph_C1GG = importdata('ControlState1+GG.txt');  % 4TH ORDER GEOPOT + LINEAR CORRECTION SOLUTION CONTROL TRACK
sph_C2 = importdata('ControlState2.txt');       % QUADRATIC CONTROL TRACK
sph_S = importdata('ShootingState.txt');        % SHOOTING SOLUTION CONTROL TRACK
target = importdata('target_2023_BEST.txt');    % select which target consider
% target = importdata('target_22+1.txt');


%% PLOT 1 cycle
fig = 1; 
figure(fig)  % Groundtrack
plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k','LineWidth',0.1)
hold on
grid on
title('Groundtrack');
xlabel('Longitude [deg]');
ylabel('Latitude [deg]');
plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',2); 
plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
plot(rad2deg(sph_C1(:,2)), rad2deg(sph_C1(:,3)), '-c','LineWidth',2)
% plot(rad2deg(sph_C1(1,2)), rad2deg(sph_C1(1,3)),'sm','LineWidth', 2); 
% plot(rad2deg(sph_C1(end,2)), rad2deg(sph_C1(end,3)),'om','LineWidth',2);
plot(rad2deg(sph_C1GG(:,2)), rad2deg(sph_C1GG(:,3)), '-b','LineWidth',2)
% plot(rad2deg(sph_C2(1,2)), rad2deg(sph_C2(1,3)),'sb','LineWidth', 2); 
% plot(rad2deg(sph_C2(end,2)), rad2deg(sph_C2(end,3)),'ob','LineWidth',2);
plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-.r','LineWidth',1.5)
% plot(rad2deg(sph_C2(1,2)), rad2deg(sph_C2(1,3)),'sb','LineWidth', 2); 
% plot(rad2deg(sph_C2(end,2)), rad2deg(sph_C2(end,3)),'ob','LineWidth',2);
plot(rad2deg(target(2,2))-60, rad2deg(target(3,2)),'om','LineWidth',3);
legend('FD Track', 'Start Free drift', 'End Free drift','Linear solution', 'Linear + GG solution', 'Shooting solution', 'Target', Location='best')
fig = fig + 1; 

figure(fig)
plot((sph_FD(:,1))*ll, (sph_FD(:,4))*ll/tt, '-.k','LineWidth',1)
hold on
grid on
title('Radius and radial vel');
xlabel('Semi major axis [km]');
ylabel('Radial velocity [km/s]');
plot((sph_FD(1,1))*ll, (sph_FD(1,4))*ll/tt,'ok','LineWidth',1.5); 
plot((sph_FD(end,1))*ll, (sph_FD(end,4))*ll/tt,'sk','LineWidth',2);
plot((sph_C1(:,1))*ll, (sph_C1(:,4))*ll/tt, '-c','LineWidth',1)
plot((sph_C2(:,1))*ll, (sph_C2(:,4))*ll/tt, '-b','LineWidth',1)
% plot((sph_C2(1,1))*ll, (sph_C2(1,4))*ll/tt,'sc','LineWidth', 2); 
% plot((sph_C2(end,1))*ll, (sph_C2(end,4))*ll/tt,'oc','LineWidth',2);
plot((sph_S(:,1))*ll, (sph_S(:,4))*ll/tt, '-.r','LineWidth',1)
plot((sph_S(1,1))*ll, (sph_S(1,4))*ll/tt,'sr','LineWidth', 2); 
plot((sph_S(end,1))*ll, (sph_S(end,4))*ll/tt,'or','LineWidth',2);
legend('Track', 'Start Free drift', 'End Free drift', 'Linear + GG solution', '2nd order solution', 'Shooting solution', 'Start control', 'End control', Location='best')
fig = fig + 1;

%% Error 

for i = 1:length(sph_S)
    posErr1(i) = abs(sph_C1(i,1)*ll - sph_S(i,1)*ll);
    lonErr1(i) = abs(rad2deg(sph_C1(i,2)) - rad2deg(sph_S(i,2)));
    latErr1(i) = abs(rad2deg(sph_C1(i,3)) - rad2deg(sph_S(i,3)));
    posErr2(i) = abs(sph_C2(i,1)*ll - sph_S(i,1)*ll);
    lonErr2(i) = abs(rad2deg(sph_C2(i,2)) - rad2deg(sph_S(i,2)));
    latErr2(i) = abs(rad2deg(sph_C2(i,3)) - rad2deg(sph_S(i,3)));

    vErr1(i) = abs(sph_C1(i,4)*ll/tt - sph_S(i,4)*ll/tt);
    csiErr1(i) = abs(rad2deg(sph_C1(i,5))/tt - rad2deg(sph_S(i,5))/tt);
    nErr1(i) = abs(rad2deg(sph_C1(i,6))/tt - rad2deg(sph_S(i,6))/tt);
    vErr2(i) = abs(sph_C2(i,4)*ll/tt - sph_S(i,4)*ll/tt);
    csiErr2(i) = abs(rad2deg(sph_C2(i,5))/tt - rad2deg(sph_S(i,5))/tt);
    nErr2(i) = abs(rad2deg(sph_C2(i,6))/tt - rad2deg(sph_S(i,6))/tt);
end



figure(fig)
subplot(3,1,1)
title('Semi-major axis Error [km]')
yyaxis left
plot((t_CONTROL - t0)/days, posErr1, 'b')
xlabel('Days')
ylabel('|a_{exact} - a_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, posErr2, 'r')
ylabel('|a_{exact} - a_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,2)
title('Longitude Error [deg]')
yyaxis left
plot((t_CONTROL - t0)/days, lonErr1, 'b')
xlabel('Days')
ylabel('|\lambda_{exact} - \lambda_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, lonErr2, 'r')
ylabel('|\lambda_{exact} - \lambda_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,3)
title('Latitude Error [km]')
yyaxis left
plot((t_CONTROL - t0)/days, latErr1, 'b')
xlabel('Days')
ylabel('|\phi_{exact} - \phi_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, latErr2, 'r')
ylabel('|\phi_{exact} - \phi_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')
fig = fig + 1;

figure(fig)
subplot(3,1,1)
title('Radial velocity axis Error [km/s]')
yyaxis left
plot((t_CONTROL - t0)/days, vErr1, 'b')
xlabel('Days')
ylabel('|v_{exact} - v_{1sr}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, vErr2, 'r')
ylabel('|v_{exact} - v_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,2)
title('Longitude drift Error [deg/s]')
yyaxis left
plot((t_CONTROL - t0)/days, csiErr1, 'b')
xlabel('Days')
ylabel('|\xi_{exact} - \xi_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, csiErr2, 'r')
ylabel('|\xi_{exact} - \xi_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,3)
title('Latitude drift Error [deg/s]')
yyaxis left
plot((t_CONTROL - t0)/days, nErr1, 'b')
xlabel('Days')
ylabel('|n_{exact} - n_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, nErr2, 'r')
ylabel('|n_{exact} - n_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')
fig = fig + 1;

%% CONTROL and performances
                                                     
u_rS = - sph_S(:, 10) * ll_c/tt_c^2 ;
u_r1GG = - sph_C1GG(:, 10) * ll_c/tt_c^2 ;
u_r1 = - sph_C1(:, 10) * ll_c/tt_c^2 ;

for i = 1 : nit
    u_lS(i) = - sph_S(i, 11) /tt_c^2 * (sph_S(i, 1)*ll * cos(sph_S(i, 3))) ;
    u_phiS(i) = - sph_S(i, 12) /tt_c^2 * (sph_S(i, 1)*ll);

    u_l1GG(i) = - sph_C1GG(i, 11) /tt_c^2 * (sph_C1GG(i, 1)*ll * cos(sph_C1GG(i, 3))) ;
    u_phi1GG(i) = - sph_C1GG(i, 12) /tt_c^2 * (sph_C1GG(i, 1)*ll);

    u_l1(i) = - sph_C1(i, 11) /tt_c^2 * (sph_C1(i, 1)*ll * cos(sph_C1(i, 3))) ;
    u_phi1(i) = - sph_C1(i, 12) /tt_c^2 * (sph_C1(i, 1)*ll);

end

% compute performance index 
u1GG = [u_r1GG, u_l1GG', u_phi1GG']*1e3;    % control acceleration m/s^2 
U1GG = vecnorm(u1GG,2,2);
% U2 = sort(U2); 
t_int = linspace(0, tc*days, nit);
% u_integral = trapz(U2, t_int);
% Dv = u_integral;                    % m/s
% mf = exp(-(Dv/(Isp*g0)))*Mi;        % Tsiolkovsky
% m_consumed = Mi-mf;

% Mass equation integration  m_dot = -T/Ig0   --- T = m*a  --- a = |u|
acc = mean(U1GG); 
options = odeset('reltol', 1.e-12,'abstol', 1.e-12);

[~, mass] = ode113(@(t,m) mass_int(t, m, acc, Isp, g0), t_int, Mi, options);
 
Mf = mass(end)
M_consumed = Mi - Mf
DV = -log(Mf/Mi)*Isp*g0 

for i = 1 : length(mass)
    T(i) = U1GG(i)*mass(i); 
end 

figure(fig)
plot((t_CONTROL - t0)/24/3600, T, 'c', 'LineWidth', 1.5)
grid on 
title('Thrust')

fig = fig+1; 


figure(fig) 
plot((t_CONTROL - t0)/24/3600, u_r1*1e3, ':c', 'LineWidth', 1.5)
hold on
plot((t_CONTROL - t0)/24/3600, (u_l1)*1e3, '--c', 'LineWidth', 1.5)
plot((t_CONTROL - t0)/24/3600, (u_phi1)*1e3, '-c', 'LineWidth', 1.5)

plot((t_CONTROL - t0)/24/3600, (u_r1GG)*1e3, ':m', 'LineWidth', 1.5)
plot((t_CONTROL - t0)/24/3600, (u_l1GG)*1e3, '--m', 'LineWidth', 1.5)
plot((t_CONTROL - t0)/24/3600, (u_phi1GG)*1e3, '-m', 'LineWidth', 1.5) 

plot((t_CONTROL - t0)/24/3600, u_rS*1e3, ':k', 'LineWidth', 1.5)
plot((t_CONTROL - t0)/24/3600, u_lS*1e3, '--k', 'LineWidth', 1.5)
plot((t_CONTROL - t0)/24/3600, u_phiS*1e3, '-k', 'LineWidth', 1.5)

legend('u_{r_1}', 'u_{\lambda_1}', 'u1_{\phi_1}','u_{r_{1,4}}', 'u2_{\lambda_{1,4}}', 'u2_{\phi_{1,4}}', 'u_{r_S}', 'u_{\lambda_S}', 'u_{\phi_S}', Location='best')
xlabel('Days')
ylabel('m/s^{2}')
grid minor
title('4th order GG & non autonomous STM vs 2nd order control vs exact control')

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(1:10) - t0)/24/3600, u_r1GG(1:10)*1e3, ':m', 'LineWidth',3)
hold on
plot((t_CONTROL(1:10) - t0)/24/3600, u_r1(1:10)*1e3, ':c', 'LineWidth',3)
plot((t_CONTROL(1:10) - t0)/24/3600, u_rS(1:10)*1e3, ':k', 'LineWidth',3)

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(1:10) - t0)/24/3600, u_l1GG(1:10)*1e3, '--m', 'LineWidth',3)
hold on
plot((t_CONTROL(1:10) - t0)/24/3600, u_l1(1:10)*1e3, '--c', 'LineWidth',3)
plot((t_CONTROL(1:10) - t0)/24/3600, u_lS(1:10)*1e3, '--k', 'LineWidth',3)

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(1:10) - t0)/24/3600, u_phi1GG(1:10)*1e3, '-m', 'LineWidth',3)
hold on
plot((t_CONTROL(1:10) - t0)/24/3600, u_phi1(1:10)*1e3, '-c', 'LineWidth',3)
plot((t_CONTROL(1:10) - t0)/24/3600, u_phiS(1:10)*1e3, '-k', 'LineWidth',3)



axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(990:end) - t0)/24/3600, u_r1GG(990:end)*1e3, ':m', 'LineWidth',3)
hold on
plot((t_CONTROL(990:end) - t0)/24/3600, u_r1(990:end)*1e3, ':c', 'LineWidth',3)
plot((t_CONTROL(990:end) - t0)/24/3600, u_rS(990:end)*1e3, ':k', 'LineWidth',3)

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(990:end) - t0)/24/3600, u_l1GG(990:end)*1e3, '--m', 'LineWidth',3)
hold on
plot((t_CONTROL(990:end) - t0)/24/3600, u_l1(990:end)*1e3, '--c', 'LineWidth',3)
plot((t_CONTROL(990:end) - t0)/24/3600, u_lS(990:end)*1e3, '--k', 'LineWidth',3)

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(990:end) - t0)/24/3600, u_phi1GG(990:end)*1e3, '-m', 'LineWidth',3)
hold on
plot((t_CONTROL(990:end) - t0)/24/3600, u_phi1(990:end)*1e3, '-c', 'LineWidth',3)
plot((t_CONTROL(990:end) - t0)/24/3600, u_phiS(990:end)*1e3, '-k', 'LineWidth',3)

fig = fig+1; 

% figure(fig)
% plot((t_CONTROL - t0)/24/3600, U2, '-k', 'LineWidth', 1.5)

%% FUNCTIONS

function [m_dot] =  mass_int(~, m, acc, Isp, g0)
    
    m_dot = - (m*acc)/(Isp * g0); 

end

