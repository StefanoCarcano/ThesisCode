# FROM CONTINOUS CONTROL TO BANG BANG SOLUTION. 1CYCLE CONTROL

# % SETUP AND FUNCTIONS


import daceypy_import_helper  # noqa: F401

from time import perf_counter
from typing import Callable

import numpy as np
from numpy.linalg import norm
from scipy.integrate import odeint
from scipy.optimize import fsolve
from scipy import interpolate
from daceypy import DA, array
import random as rnd
# import matplotlib.pyplot as plt


#SETUP

#Adimensionalization 
ll = 42165.8
tt = np.sqrt(ll**3/398600)


# EPOCH AND TARGETS -- TIME -- OPTIMAL TARGET FROM MATLAB
hours = 3600                               
days = 24*hours
        
  
# t0 = np.loadtxt('t02010.txt', dtype = float)                                 # import initial datetime and GHA0 from matlab 
t0 = np.loadtxt('t02023.txt', dtype = float)
target = np.loadtxt('target_2023_BEST.txt', dtype = float)
tfd = np.loadtxt('tfd_BEST.txt', dtype = float)
tc = 1

tf1 = t0 + tfd[0]*days                                                         # final free drift time (in seconds) 
tf2 = tf1 + tc*days                                                            # final control time (in seconds)


nit = 1000 
t_FREEDRIFT = np.linspace(t0, tf1, nit)/tt
t_CONTROL = np.linspace(tf1, tf2, nit)/tt

# GHA at t0 from matlab
G0 = np.loadtxt('G0.txt', dtype = float)

# Dynamics data
R = 6378.137/ll 
mue = 398600*tt**2/ll**3
muS = 1.327124400179870e+11*tt**2/ll**3
muM = 4.902801e+03*tt**2/ll**3
Rgeo = 42165.8/ll                              
omega = np.sqrt(mue/Rgeo**3)
ln = 60  # nominal longitude

# GG perturbation potential data (values taken from 'vallado') 
c20 = -1.083e-3  
c21 = -2.414e-10  
c22 = 1.574e-6  
c30 = 2.532e-6  
c31 = 2.191e-6 
c32 = 3.089e-7  
c33 = 1.006e-7  
s21 = 1.543e-9  
s22 = -9.038e-7  
s31 = 2.687e-7 
s32 = -2.115e-7
s33 = 1.972e-7

# SRP parameters
M = 3000 # kg                                                                  # mass
A = 100 # m^2
Cr = 1.5                  # SRP coefficient 
S = 1353 # W/m^2
c = 2.998*1e8 # speed of ligh

# THRUSTER PARAM 
g0 = 9.8 * 1e-3    # km/s                                              
Tmax = 0.33  # N
Isp = 3800   # s

m0 = 1                                                                         #initial adimensional mass
 


def ephMoon(MJD2000):
       
#ephMoon.m - Ephemerides (cartesian position and velocity) of the Moon.
    T_TDB = MJD2000/36525
    
    angles = np.array([(134.9 + 477198.85*T_TDB)* np.pi/180,
              (259.2 - 413335.38*T_TDB)* np.pi/180,
              (235.7 + 890534.23*T_TDB)* np.pi/180,
              (269.9 +  954397.7*T_TDB)* np.pi/180, 
              (357.5 +  35999.05*T_TDB)* np.pi/180, 
              (186.6 + 966404.05*T_TDB)* np.pi/180, 
              ( 93.3 + 483202.03*T_TDB)* np.pi/180, 
              (228.2 + 960400.87*T_TDB)* np.pi/180, 
              (318.3 +   6003.18*T_TDB)* np.pi/180,
              (217.6 -  407332.2*T_TDB)* np.pi/180,
              ])

    
    # Sinus of the first 10 angles
    s = np.sin(angles[0:10])
    
    # Cosinus of the first 4 angles
    c = np.cos(angles[0:4])
    
    
    # Compute L_ecl, phi_ecl, P and eps
    b = np.array([+6.29, -1.27, +0.66, +0.21, -0.19, -0.11])
    L_ecl =  (218.32 + 481267.883*T_TDB) + np.dot(b, s[0:6])
        
    phi_ecl = np.dot(np.array([+5.13, +0.28, -0.28, -0.17]), s[6:10])
    
    P =   0.9508 + np.dot(np.array([+0.0518, +0.0095, +0.0078, +0.0028]), c)
    
    eps = 23.439291 - 0.0130042*T_TDB - 1.64e-7*T_TDB**2 + 5.04e-7*T_TDB**3
    
    # Transform L_ecl, phi_ecl, P and eps in radians
    L_ecl   = L_ecl   * np.pi/180
    phi_ecl = phi_ecl * np.pi/180
    P       = P       * np.pi/180
    eps     = eps     * np.pi/180
    
    r = 1/np.sin(P) * 6378.16
    xP = r * np.array([np.cos(L_ecl)*np.cos(phi_ecl), np.cos(eps)*np.cos(phi_ecl)*np.sin(L_ecl) - np.sin(eps)*np.sin(phi_ecl), np.sin(eps)*np.cos(phi_ecl)*np.sin(L_ecl) + np.cos(eps)*np.sin(phi_ecl)])
    
    return xP


def uplanet(MJD2000):
    
    kep = np.array([0.0,0.0,0.0,0.0,0.0,0.0])
    DEG2RAD = np.pi/180
    KM  = 149597870.66
    
    #  T = JULIAN CENTURIES SINCE 31/12/1899 at 12:00
    T   = (MJD2000 + 36525)/36525.00
    kep[0] = 1.000000230
    kep[1] = 0.016751040 - 0.000041800*T - 0.0000001260*T**2
    kep[2] = 0.0
    kep[3] = 0.00
    kep[4] = 1.01220833333333333e+2 + 1.7191750*T + 4.52777777777777778e-4*T**2 + 3.33333333333333333e-6*T**3
    XM   = 3.599904975e+4 - 1.50277777777777778e-4*T - 3.33333333333333333e-6*T**2
    kep[5] = 3.58475844444444444e2 + XM*T
       
     
    kep[0]   = kep[0]*KM
    kep[2:6] = kep[2:6]*DEG2RAD
    kep[5]   = np.mod(kep[5], 2*np.pi)
    phi    = kep[5]
         
    for i in range(6):

        g = kep[5] - (phi-kep[1]*np.sin(phi)) 
        g_primo = (-1 + kep[1]*np.cos(phi))
        phi     = phi-g/g_primo
     
    
    theta = 2*np.arctan(np.sqrt((1 + kep[1])/(1 - kep[1]))*np.tan(phi/2));
    
    kep[5] = theta
    
    return kep


def kp2rv(a,e,i,OMEGA,omega,theta,mu):
      
    R_OMEGA = np.array([[np.cos(OMEGA), np.sin(OMEGA), 0], [-np.sin(OMEGA), np.cos(OMEGA), 0], [0, 0, 1]])
    
    R_i = np.array([[1, 0, 0], [0, np.cos(i), np.sin(i)], [0, -np.sin(i), np.cos(i)]])
    
    R_omega = np.array([[np.cos(omega), np.sin(omega), 0], [-np.sin(omega), np.cos(omega), 0], [0, 0, 1]])
    
    T_ge2pf = np.dot(R_omega,R_i)
    T_ge2pf = np.dot(T_ge2pf, R_OMEGA)
    
    T_pf2ge = np.transpose(T_ge2pf)
    
      
    p = a*(1 - e**2)
    h = np.sqrt(mu*p)
    
    r_pf = np.array([p/(1 + e*np.cos(theta))*np.cos(theta), p/(1 + e*np.cos(theta))*np.sin(theta), 0])
    
    v_pf = np.array([(mu/h)*(- np.sin(theta)), (mu/h)*(e + np.cos(theta)), 0])
    
    r_ge = np.dot(T_pf2ge, r_pf)
    v_ge = np.dot(T_pf2ge, v_pf)
    
    r = r_ge
    v = v_ge
    
    return r


def ephMoon_DA(MJD2000):
       
#ephMoon.m - Ephemerides (cartesian position and velocity) of the Moon.
    T_TDB = MJD2000/36525
    
    angles = array.zeros(10)
    angles += [(134.9 + 477198.85*T_TDB)* np.pi/180,
              (259.2 - 413335.38*T_TDB)* np.pi/180,
              (235.7 + 890534.23*T_TDB)* np.pi/180,
              (269.9 +  954397.7*T_TDB)* np.pi/180, 
              (357.5 +  35999.05*T_TDB)* np.pi/180, 
              (186.6 + 966404.05*T_TDB)* np.pi/180, 
              ( 93.3 + 483202.03*T_TDB)* np.pi/180, 
              (228.2 + 960400.87*T_TDB)* np.pi/180, 
              (318.3 +   6003.18*T_TDB)* np.pi/180,
              (217.6 -  407332.2*T_TDB)* np.pi/180,
              ]

    
    # Sinus of the first 10 angles
    s = np.sin(angles[0:10])
    
    # Cosinus of the first 4 angles
    c = np.cos(angles[0:4])
    
    
    # Compute L_ecl, phi_ecl, P and eps
    b = np.array([+6.29, -1.27, +0.66, +0.21, -0.19, -0.11])
    L_ecl =  (218.32 + 481267.883*T_TDB) + np.dot(b, s[0:6])
        
    phi_ecl = np.dot(np.array([+5.13, +0.28, -0.28, -0.17]), s[6:10])
    
    P =   0.9508 + np.dot(np.array([+0.0518, +0.0095, +0.0078, +0.0028]), c)
    
    eps = 23.439291 - 0.0130042*T_TDB - 1.64e-7*T_TDB**2 + 5.04e-7*T_TDB**3
    
    # Transform L_ecl, phi_ecl, P and eps in radians
    L_ecl   = L_ecl   * np.pi/180
    phi_ecl = phi_ecl * np.pi/180
    P       = P       * np.pi/180
    eps     = eps     * np.pi/180
    
    r = 1/np.sin(P) * 6378.16
    xP = r * np.array([np.cos(L_ecl)*np.cos(phi_ecl), np.cos(eps)*np.cos(phi_ecl)*np.sin(L_ecl) - np.sin(eps)*np.sin(phi_ecl), np.sin(eps)*np.cos(phi_ecl)*np.sin(L_ecl) + np.cos(eps)*np.sin(phi_ecl)])
    
    return xP


def uplanet_DA(MJD2000):
    
    kep = array.zeros(6)
    DEG2RAD = np.pi/180
    KM  = 149597870.66
    
    #  T = JULIAN CENTURIES SINCE 31/12/1899 at 12:00
    T   = (MJD2000 + 36525)/36525.00
    kep[0] = 1.000000230
    kep[1] = 0.016751040 - 0.000041800*T - 0.0000001260*T**2
    kep[2] = 0.0
    kep[3] = 0.00
    kep[4] = 1.01220833333333333e+2 + 1.7191750*T + 4.52777777777777778e-4*T**2 + 3.33333333333333333e-6*T**3
    XM   = 3.599904975e+4 - 1.50277777777777778e-4*T - 3.33333333333333333e-6*T**2
    kep[5] = 3.58475844444444444e2 + XM*T
       
     
    kep[0]   = kep[0]*KM
    kep[2:6] = kep[2:6]*DEG2RAD
    kep[5]   = np.mod(kep[5], 2*np.pi)
    phi    = kep[5]
         
    for i in range(6):
 
        g = kep[5] - (phi-kep[1]*np.sin(phi)) 
        g_primo = (-1 + kep[1]*np.cos(phi))
        phi     = phi-g/g_primo
     
    
    theta = 2*np.arctan(np.sqrt((1 + kep[1])/(1 - kep[1]))*np.tan(phi/2));
    
    kep[5] = theta
    
    return kep


def FreeDrift_propag(dyn, t):   
    
    r     = dyn[0]
    eps   = dyn[1]
    phi   = dyn[2]
    v     = dyn[3]
    csi   = dyn[4]
    n     = dyn[5]
    
    l_r   = dyn[6]
    l_l   = dyn[7]  
    l_phi = dyn[8]
    l_v   = dyn[9]
    l_csi = dyn[10]
    l_n   = dyn[11]
               
    l = ln*np.pi/180 + eps
         
    # GG PERTURBATIONS
    aPg_r = -mue*((3*R**2 * c20*(3*(np.sin(phi))**2 - 1))/(2*r**4) + (9*R**2 * (np.cos(phi))**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (60*R**3 * (np.cos(phi))**3 * (s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (2*R**3 * c30*np.sin(phi)*(5*(np.sin(phi))**2 - 3))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (60*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (2*R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5)
    aPg_l =  -mue*((3*R**2 * (np.cos(phi))**2 * (2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3 * (np.cos(phi))**3 * (3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2 * np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4))/(r*np.cos(phi))
    aPg_phi = mue*((15*R**3 * (np.cos(phi))**3 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2 * (np.cos(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2 * (np.sin(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3 * c30*np.cos(phi)*(5*(np.sin(phi))**2 - 3))/(2*r**4) - (30*R**3 * np.cos(phi)*(np.sin(phi))**2 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3 * c30*np.cos(phi)*(np.sin(phi))**2)/r**4 - (R**3 * np.sin(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2 * np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2 * c20*np.cos(phi)*np.sin(phi))/r**3)/r
    
    # % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt             #% time in days (Dimensional for ephemeris)
    MJD2000 = tdays

    eps = np.pi * 23.44 /180
    ecl = np.array([[1, 0, 0], [0, np.cos(eps), -np.sin(eps)], [0, np.sin(eps), np.cos(eps)]])   #rotation ecliptic/equatorial
    kep = uplanet(MJD2000)
    r_E = kp2rv(kep[0], kep[1], kep[2], kep[3], kep[4], kep[5], muS)
    r_S = - r_E /ll
       
    r_S = np.dot(ecl, r_S)                  #SUN position inertial geocentric equatorial frame
    r_M = ephMoon(MJD2000)           # MOOn ....
    r_M = r_M /ll
      
    Ds =   np.arcsin(r_S[2]/norm(r_S))
    RAs =  np.arctan2( r_S[1]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ), r_S[0]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ) ) 
    Dm =   np.arcsin(r_M[2]/norm(r_M))
    RAm =  np.arctan2( r_M[1]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ), r_M[0]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ) ) 

    omega_dim = omega/tt
    RA = l + G0 + omega_dim * (t *tt - t0)
    
    cosPSIS = np.sin(phi) * np.sin(Ds) + np.cos(phi) * np.cos(Ds) * np.cos(RA - RAs)
    cosPSIM = np.sin(phi) * np.sin(Dm) + np.cos(phi) * np.cos(Dm) * np.cos(RA - RAm)

    rM = norm(r_M)
    rS = norm(r_S)

    a3r   = muS/rS**3 * r *(3*cosPSIS**2 - 1) + muM/rM**3 * r *(3*cosPSIM**2 - 1)
    a3l   = -3*muS/rS**3 * r * cosPSIS * np.cos(Ds) * np.sin(RA - RAs) - 3*muM/rM**3 * r * cosPSIM * np.cos(Dm) * np.sin(RA - RAm) 
    a3phi = 3*muS/rS**3 * r * cosPSIS * (np.cos(phi) * np.sin(Ds) - np.sin(phi) * np.cos(Ds) * np.cos(RA - RAs)) + 3*muM/rM**3 * r * cosPSIM * (np.cos(phi) * np.sin(Dm) - np.sin(phi) * np.cos(Dm) * np.cos(RA - RAm)) 


    # SRP PERTURBATIONS
    #     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/M        

    Psr = Psr * 1e-3 
    Psr = Psr * tt**2/ll 

    aSRPr   = - Psr * cosPSIS 
    aSRPl   =   Psr * np.cos(Ds) * np.sin(RA - RAs) 
    aSRPphi = - Psr * (np.sin(Ds) * np.cos(phi) - np.cos(Ds) * np.sin(phi) * np.cos(RA - RAs))
     
    
    aP_r   = aPg_r + a3r + aSRPr;
    aP_l   = aPg_l + a3l + aSRPl;
    aP_phi = aPg_phi + a3phi + aSRPphi;

    #DYNAMICS (CONTROLLED)
    Ddyn0 = v
    Ddyn1 = csi
    Ddyn2 = n
    Ddyn3 = -mue/r**2 + r*n**2 + r*(csi + omega)**2 *(np.cos(phi))**2 + aP_r - l_v 
    Ddyn4 = 2*n*(csi + omega)*np.tan(phi) - 2*v/r *(csi + omega) + aP_l/(r * np.cos(phi)) - l_csi/(r * np.cos(phi))**2 
    Ddyn5 = -2*v/r *n - (csi + omega)**2 *np.sin(phi)*np.cos(phi) + aP_phi/r - l_n/r**2 
    
    Ddyn6 = l_n*(((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r - Psr*(np.sin(Ds)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAs)*np.sin(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r**2 - (2*l_n)/r**3 + ((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r**2 + (mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4))/r - (3*cosPSIM*muM*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 - (3*cosPSIS*muS*(np.sin(Ds)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r - (2*n*v)/r**2) - l_csi*((2*l_csi)/(r**3*np.cos(phi)**2) + (2*v*(csi + omega))/r**2 + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Dm)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Dm)*np.sin(RA - RAs))/rS**3)/(r**2*np.cos(phi)) + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r**2*np.cos(phi)) + (mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5))/(r*np.cos(phi)) - (3*cosPSIM*muM*np.cos(Dm)*np.sin(RA - RAm))/rM**3 - (3*cosPSIS*muS*np.cos(Dm)*np.sin(RA - RAs))/rS**3)/(r*np.cos(phi))) - l_v*(np.cos(phi)**2*(csi + omega)**2 + mue*((6*R**2*c20*(3*np.sin(phi)**2 - 1))/r**5 + (36*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**5 + (300*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**6 + (10*R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/r**6 + (36*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**5 + (300*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**6 + (10*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**6) + (2*mue)/r**3 + n**2 + (muM*(3*cosPSIM**2 - 1))/rM**3 + (muS*(3*cosPSIS**2 - 1))/rS**3)
    Ddyn7 = (l_csi*mue*((3*R**2*np.cos(phi)**2*(4*s22*np.sin(2*l) + 4*c22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(9*s33*np.sin(3*l) + 9*c33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(4*s32*np.sin(2*l) + 4*c32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4)))/(r**2*np.cos(phi)**2) - (l_n*mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/r**2 - l_v*mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5)
    Ddyn8 = l_n*(np.cos(phi)**2*(csi + omega)**2 - np.sin(phi)**2*(csi + omega)**2 + ((mue*((6*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (45*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 - (3*R**2*c20*np.cos(phi)**2)/r**3 - (6*R**2*np.sin(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 - (30*R**3*np.sin(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*c20*np.sin(phi)**2)/r**3 + (5*R**3*c30*np.sin(phi)**3)/r**4 - (15*R**3*np.cos(phi)**3*(c31*np.cos(l) + s31*np.sin(l)))/r**4 + (R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) + (12*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (105*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (90*R**3*np.cos(phi)*np.sin(phi)**2*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) - (15*R**3*c30*np.cos(phi)**2*np.sin(phi))/r**4 + (45*R**3*np.cos(phi)*np.sin(phi)**2*(c31*np.cos(l) + s31*np.sin(l)))/r**4))/r - Psr*(np.sin(Ds)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAs)*np.cos(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAm)*np.cos(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAs)*np.cos(phi)))/rS**3)/r) + l_v*(mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4) + 2*r*np.cos(phi)*np.sin(phi)*(csi + omega)**2) - l_csi*(((mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/(r*np.cos(phi)) - (mue*np.sin(phi)*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)**2))/(r*np.cos(phi)) + 2*n*(csi + omega)*(np.tan(phi)**2 + 1) - (2*l_csi*np.sin(phi))/(r**2*np.cos(phi)**3) - (np.sin(phi)*((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Dm)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Dm)*np.sin(RA - RAs))/rS**3))/(r*np.cos(phi)**2))
    Ddyn9 = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r
    Ddyn10 = l_csi*((2*v)/r - 2*n*np.tan(phi)) - l_l - l_v*r*np.cos(phi)**2*(2*csi + 2*omega) + l_n*np.cos(phi)*np.sin(phi)*(2*csi + 2*omega)
    Ddyn11 = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*np.tan(phi)*(csi + omega)
         

    Ddyn = [Ddyn0, Ddyn1, Ddyn2, Ddyn3, Ddyn4, Ddyn5, Ddyn6, Ddyn7, Ddyn8, Ddyn9, Ddyn10, Ddyn11]
    
    return Ddyn


def BANGBANGcontinuation_propag(dyn, t, p):                                    # p: parameter for continuation method 


    r     = dyn[0]
    eps   = dyn[1]
    phi   = dyn[2]
    v     = dyn[3]
    csi   = dyn[4]
    n     = dyn[5]
    m     = dyn[6]
    
    l_r   = dyn[7]
    l_l   = dyn[8]  
    l_phi = dyn[9]
    l_v   = dyn[10]
    l_csi = dyn[11]
    l_n   = dyn[12]
    l_m   = dyn[13]
               
    l = ln*np.pi/180 + eps
         
    # GG PERTURBATIONS
    aPg_r = -mue*((3*R**2 * c20*(3*(np.sin(phi))**2 - 1))/(2*r**4) + (9*R**2 * (np.cos(phi))**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (60*R**3 * (np.cos(phi))**3 * (s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (2*R**3 * c30*np.sin(phi)*(5*(np.sin(phi))**2 - 3))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (60*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (2*R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5)
    aPg_l =  -mue*((3*R**2 * (np.cos(phi))**2 * (2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3 * (np.cos(phi))**3 * (3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2 * np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4))/(r*np.cos(phi))
    aPg_phi = mue*((15*R**3 * (np.cos(phi))**3 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2 * (np.cos(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2 * (np.sin(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3 * c30*np.cos(phi)*(5*(np.sin(phi))**2 - 3))/(2*r**4) - (30*R**3 * np.cos(phi)*(np.sin(phi))**2 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3 * c30*np.cos(phi)*(np.sin(phi))**2)/r**4 - (R**3 * np.sin(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2 * np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2 * c20*np.cos(phi)*np.sin(phi))/r**3)/r
    
    # % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt             #% time in days (Dimensional for ephemeris)
    MJD2000 = tdays

    eps = np.pi * 23.44 /180
    ecl = np.array([[1, 0, 0], [0, np.cos(eps), -np.sin(eps)], [0, np.sin(eps), np.cos(eps)]])   #rotation ecliptic/equatorial
    kep = uplanet(MJD2000)
    r_E = kp2rv(kep[0], kep[1], kep[2], kep[3], kep[4], kep[5], muS)
    r_S = - r_E /ll
       
    r_S = np.dot(ecl, r_S)                  #SUN position inertial geocentric equatorial frame
    r_M = ephMoon(MJD2000)           # MOOn ....
    r_M = r_M /ll
      
    Ds =   np.arcsin(r_S[2]/norm(r_S))
    RAs =  np.arctan2( r_S[1]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ), r_S[0]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ) ) 
    Dm =   np.arcsin(r_M[2]/norm(r_M))
    RAm =  np.arctan2( r_M[1]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ), r_M[0]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ) ) 

    omega_dim = omega/tt
    RA = l + G0 + omega_dim * (t *tt - t0)
    
    cosPSIS = np.sin(phi) * np.sin(Ds) + np.cos(phi) * np.cos(Ds) * np.cos(RA - RAs)
    cosPSIM = np.sin(phi) * np.sin(Dm) + np.cos(phi) * np.cos(Dm) * np.cos(RA - RAm)

    rM = norm(r_M)
    rS = norm(r_S)

    a3r   = muS/rS**3 * r *(3*cosPSIS**2 - 1) + muM/rM**3 * r *(3*cosPSIM**2 - 1)
    a3l   = -3*muS/rS**3 * r * cosPSIS * np.cos(Ds) * np.sin(RA - RAs) - 3*muM/rM**3 * r * cosPSIM * np.cos(Dm) * np.sin(RA - RAm) 
    a3phi = 3*muS/rS**3 * r * cosPSIS * (np.cos(phi) * np.sin(Ds) - np.sin(phi) * np.cos(Ds) * np.cos(RA - RAs)) + 3*muM/rM**3 * r * cosPSIM * (np.cos(phi) * np.sin(Dm) - np.sin(phi) * np.cos(Dm) * np.cos(RA - RAm)) 


    # SRP PERTURBATIONS
    #     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/(m*M)        

    Psr = Psr * 1e-3 
    Psr = Psr * tt**2/ll 

    aSRPr   = - Psr * cosPSIS 
    aSRPl   =   Psr * np.cos(Ds) * np.sin(RA - RAs) 
    aSRPphi = - Psr * (np.sin(Ds) * np.cos(phi) - np.cos(Ds) * np.sin(phi) * np.cos(RA - RAs))
     
    
    aP_r   = aPg_r + a3r + aSRPr;
    aP_l   = aPg_l + a3l + aSRPl;
    aP_phi = aPg_phi + a3phi + aSRPphi;
    
    # SWITCHING FUNCTION CALCULATION 
    c1 = Tmax * tt**2/ll/M *1e-3
    c2 = Tmax *tt**2/ll/M/(Isp/tt * g0 * tt**2/ll) *1e-3
    
    LV = norm([l_v, l_csi, l_n])
    rho = 1 - c1/c2 * LV/m - l_m
    
    u = 1/(1 + np.exp(p * rho))

    #DYNAMICS (CONTROLLED)
    Ddyn0 = v
    Ddyn1 = csi
    Ddyn2 = n
    Ddyn3 = -mue/r**2 + r*n**2 + r*(csi + omega)**2 *(np.cos(phi))**2 + aP_r - c1 * u/m * l_v/LV  
    Ddyn4 = 2*n*(csi + omega)*np.tan(phi) - 2*v/r *(csi + omega) + aP_l/(r * np.cos(phi)) - 1/(r * np.cos(phi))**2 * c1 * u/m * l_csi/LV
    Ddyn5 = -2*v/r *n - (csi + omega)**2 *np.sin(phi)*np.cos(phi) + aP_phi/r - 1/r**2 * c1 * u/m * l_n/LV
    Ddyn6 = -c2 * u
    
    Ddyn7 = l_n*(((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r - Psr*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r**2 + ((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r**2 + (mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4))/r - (3*cosPSIM*muM*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 - (3*cosPSIS*muS*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r - (2*n*v)/r**2 - (2*c1*l_n*u)/(LV*m*r**3)) - l_v*(np.cos(phi)**2*(csi + omega)**2 + mue*((6*R**2*c20*(3*np.sin(phi)**2 - 1))/r**5 + (36*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**5 + (300*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**6 + (10*R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/r**6 + (36*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**5 + (300*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**6 + (10*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**6) + (2*mue)/r**3 + n**2 + (muM*(3*cosPSIM**2 - 1))/rM**3 + (muS*(3*cosPSIS**2 - 1))/rS**3) - l_csi*((2*v*(csi + omega))/r**2 + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Ds)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Ds)*np.sin(RA - RAs))/rS**3)/(r**2*np.cos(phi)) + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r**2*np.cos(phi)) + (mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5))/(r*np.cos(phi)) - (3*cosPSIM*muM*np.cos(Dm)*np.sin(RA - RAm))/rM**3 - (3*cosPSIS*muS*np.cos(Ds)*np.sin(RA - RAs))/rS**3)/(r*np.cos(phi)) + (2*c1*l_csi*u)/(LV*m*r**3*np.cos(phi)**2))     
    Ddyn8 = (l_csi*mue*((3*R**2*np.cos(phi)**2*(4*s22*np.sin(2*l) + 4*c22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(9*s33*np.sin(3*l) + 9*c33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(4*s32*np.sin(2*l) + 4*c32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4)))/(r**2*np.cos(phi)**2) - (l_n*mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/r**2 - l_v*mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5)
    Ddyn9 = l_n*(np.cos(phi)**2*(csi + omega)**2 - np.sin(phi)**2*(csi + omega)**2 + ((mue*((6*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (45*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 - (3*R**2*c20*np.cos(phi)**2)/r**3 - (6*R**2*np.sin(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 - (30*R**3*np.sin(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*c20*np.sin(phi)**2)/r**3 + (5*R**3*c30*np.sin(phi)**3)/r**4 - (15*R**3*np.cos(phi)**3*(c31*np.cos(l) + s31*np.sin(l)))/r**4 + (R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) + (12*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (105*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (90*R**3*np.cos(phi)*np.sin(phi)**2*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) - (15*R**3*c30*np.cos(phi)**2*np.sin(phi))/r**4 + (45*R**3*np.cos(phi)*np.sin(phi)**2*(c31*np.cos(l) + s31*np.sin(l)))/r**4))/r - Psr*(np.sin(Ds)*np.sin(phi) + np.cos(Ds)*np.cos(RA - RAs)*np.cos(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAm)*np.cos(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.sin(phi) + np.cos(Ds)*np.cos(RA - RAs)*np.cos(phi)))/rS**3)/r) - l_csi*(((mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/(r*np.cos(phi)) - (mue*np.sin(phi)*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)**2))/(r*np.cos(phi)) + 2*n*(csi + omega)*(np.tan(phi)**2 + 1) - (np.sin(phi)*((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Ds)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Ds)*np.sin(RA - RAs))/rS**3))/(r*np.cos(phi)**2) - (2*c1*l_csi*u*np.sin(phi))/(LV*m*r**2*np.cos(phi)**3)) + l_v*(mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4) + 2*r*np.cos(phi)*np.sin(phi)*(csi + omega)**2)
    Ddyn10 = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r
    Ddyn11 = l_csi*((2*v)/r - 2*n*np.tan(phi)) - l_l - l_v*r*np.cos(phi)**2*(2*csi + 2*omega) + l_n*np.cos(phi)*np.sin(phi)*(2*csi + 2*omega)
    Ddyn12 = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*np.tan(phi)*(csi + omega)
    Ddyn13 = -c1*u/m**2 * LV    

    Ddyn = [Ddyn0, Ddyn1, Ddyn2, Ddyn3, Ddyn4, Ddyn5, Ddyn6, Ddyn7, Ddyn8, Ddyn9, Ddyn10, Ddyn11, Ddyn12, Ddyn13]
    
    return Ddyn


def BANGBANG_propag(dyn, t):                           
    
    
    r     = dyn[0]
    eps   = dyn[1]
    phi   = dyn[2]
    v     = dyn[3]
    csi   = dyn[4]
    n     = dyn[5]
    m     = dyn[6]
    
    l_r   = dyn[7]
    l_l   = dyn[8]  
    l_phi = dyn[9]
    l_v   = dyn[10]
    l_csi = dyn[11]
    l_n   = dyn[12]
    l_m   = dyn[13]
               
    l = ln*np.pi/180 + eps
         
    # GG PERTURBATIONS
    aPg_r = -mue*((3*R**2 * c20*(3*(np.sin(phi))**2 - 1))/(2*r**4) + (9*R**2 * (np.cos(phi))**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (60*R**3 * (np.cos(phi))**3 * (s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (2*R**3 * c30*np.sin(phi)*(5*(np.sin(phi))**2 - 3))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (60*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (2*R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5)
    aPg_l =  -mue*((3*R**2 * (np.cos(phi))**2 * (2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3 * (np.cos(phi))**3 * (3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2 * np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4))/(r*np.cos(phi))
    aPg_phi = mue*((15*R**3 * (np.cos(phi))**3 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2 * (np.cos(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2 * (np.sin(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3 * c30*np.cos(phi)*(5*(np.sin(phi))**2 - 3))/(2*r**4) - (30*R**3 * np.cos(phi)*(np.sin(phi))**2 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3 * c30*np.cos(phi)*(np.sin(phi))**2)/r**4 - (R**3 * np.sin(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2 * np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2 * c20*np.cos(phi)*np.sin(phi))/r**3)/r
    
    # % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt             #% time in days (Dimensional for ephemeris)
    MJD2000 = tdays

    eps = np.pi * 23.44 /180
    ecl = np.array([[1, 0, 0], [0, np.cos(eps), -np.sin(eps)], [0, np.sin(eps), np.cos(eps)]])   #rotation ecliptic/equatorial
    kep = uplanet(MJD2000)
    r_E = kp2rv(kep[0], kep[1], kep[2], kep[3], kep[4], kep[5], muS)
    r_S = - r_E /ll
       
    r_S = np.dot(ecl, r_S)                  #SUN position inertial geocentric equatorial frame
    r_M = ephMoon(MJD2000)           # MOOn ....
    r_M = r_M /ll
      
    Ds =   np.arcsin(r_S[2]/norm(r_S))
    RAs =  np.arctan2( r_S[1]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ), r_S[0]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ) ) 
    Dm =   np.arcsin(r_M[2]/norm(r_M))
    RAm =  np.arctan2( r_M[1]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ), r_M[0]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ) ) 

    omega_dim = omega/tt
    RA = l + G0 + omega_dim * (t *tt - t0)
    
    cosPSIS = np.sin(phi) * np.sin(Ds) + np.cos(phi) * np.cos(Ds) * np.cos(RA - RAs)
    cosPSIM = np.sin(phi) * np.sin(Dm) + np.cos(phi) * np.cos(Dm) * np.cos(RA - RAm)

    rM = norm(r_M)
    rS = norm(r_S)

    a3r   = muS/rS**3 * r *(3*cosPSIS**2 - 1) + muM/rM**3 * r *(3*cosPSIM**2 - 1)
    a3l   = -3*muS/rS**3 * r * cosPSIS * np.cos(Ds) * np.sin(RA - RAs) - 3*muM/rM**3 * r * cosPSIM * np.cos(Dm) * np.sin(RA - RAm) 
    a3phi = 3*muS/rS**3 * r * cosPSIS * (np.cos(phi) * np.sin(Ds) - np.sin(phi) * np.cos(Ds) * np.cos(RA - RAs)) + 3*muM/rM**3 * r * cosPSIM * (np.cos(phi) * np.sin(Dm) - np.sin(phi) * np.cos(Dm) * np.cos(RA - RAm)) 


    # SRP PERTURBATIONS
    #     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/(m*M)        

    Psr = Psr * 1e-3 
    Psr = Psr * tt**2/ll 

    aSRPr   = - Psr * cosPSIS 
    aSRPl   =   Psr * np.cos(Ds) * np.sin(RA - RAs) 
    aSRPphi = - Psr * (np.sin(Ds) * np.cos(phi) - np.cos(Ds) * np.sin(phi) * np.cos(RA - RAs))
     
    
    aP_r   = aPg_r + a3r + aSRPr;
    aP_l   = aPg_l + a3l + aSRPl;
    aP_phi = aPg_phi + a3phi + aSRPphi;
    
    # SWITCHING FUNCTION CALCULATION 
    c1 = Tmax * tt**2/ll/M *1e-3
    c2 = Tmax *tt**2/ll/M/(Isp/tt * g0 * tt**2/ll) *1e-3
    
    LV = norm([l_v, l_csi, l_n])
    rho = 1 - c1/c2 * LV/m - l_m
    
    if rho > 0 :
        u = 0
    elif rho == 0: 
        u = rnd.uniform(0,1)
    else:
        u = 1
    

    #DYNAMICS (CONTROLLED)
    Ddyn0 = v
    Ddyn1 = csi
    Ddyn2 = n
    Ddyn3 = -mue/r**2 + r*n**2 + r*(csi + omega)**2 *(np.cos(phi))**2 + aP_r - c1 * u/m * l_v/LV  
    Ddyn4 = 2*n*(csi + omega)*np.tan(phi) - 2*v/r *(csi + omega) + aP_l/(r * np.cos(phi)) - 1/(r * np.cos(phi))**2 * c1 * u/m * l_csi/LV
    Ddyn5 = -2*v/r *n - (csi + omega)**2 *np.sin(phi)*np.cos(phi) + aP_phi/r - 1/r**2 * c1 * u/m * l_n/LV
    Ddyn6 = -c2 * u
    
    Ddyn7 = l_n*(((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r - Psr*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r**2 + ((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r**2 + (mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4))/r - (3*cosPSIM*muM*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 - (3*cosPSIS*muS*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r - (2*n*v)/r**2 - (2*c1*l_n*u)/(LV*m*r**3)) - l_v*(np.cos(phi)**2*(csi + omega)**2 + mue*((6*R**2*c20*(3*np.sin(phi)**2 - 1))/r**5 + (36*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**5 + (300*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**6 + (10*R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/r**6 + (36*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**5 + (300*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**6 + (10*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**6) + (2*mue)/r**3 + n**2 + (muM*(3*cosPSIM**2 - 1))/rM**3 + (muS*(3*cosPSIS**2 - 1))/rS**3) - l_csi*((2*v*(csi + omega))/r**2 + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Ds)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Ds)*np.sin(RA - RAs))/rS**3)/(r**2*np.cos(phi)) + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r**2*np.cos(phi)) + (mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5))/(r*np.cos(phi)) - (3*cosPSIM*muM*np.cos(Dm)*np.sin(RA - RAm))/rM**3 - (3*cosPSIS*muS*np.cos(Ds)*np.sin(RA - RAs))/rS**3)/(r*np.cos(phi)) + (2*c1*l_csi*u)/(LV*m*r**3*np.cos(phi)**2))     
    Ddyn8 = (l_csi*mue*((3*R**2*np.cos(phi)**2*(4*s22*np.sin(2*l) + 4*c22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(9*s33*np.sin(3*l) + 9*c33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(4*s32*np.sin(2*l) + 4*c32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4)))/(r**2*np.cos(phi)**2) - (l_n*mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/r**2 - l_v*mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5)
    Ddyn9 = l_n*(np.cos(phi)**2*(csi + omega)**2 - np.sin(phi)**2*(csi + omega)**2 + ((mue*((6*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (45*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 - (3*R**2*c20*np.cos(phi)**2)/r**3 - (6*R**2*np.sin(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 - (30*R**3*np.sin(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*c20*np.sin(phi)**2)/r**3 + (5*R**3*c30*np.sin(phi)**3)/r**4 - (15*R**3*np.cos(phi)**3*(c31*np.cos(l) + s31*np.sin(l)))/r**4 + (R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) + (12*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (105*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (90*R**3*np.cos(phi)*np.sin(phi)**2*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) - (15*R**3*c30*np.cos(phi)**2*np.sin(phi))/r**4 + (45*R**3*np.cos(phi)*np.sin(phi)**2*(c31*np.cos(l) + s31*np.sin(l)))/r**4))/r - Psr*(np.sin(Ds)*np.sin(phi) + np.cos(Ds)*np.cos(RA - RAs)*np.cos(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAm)*np.cos(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.sin(phi) + np.cos(Ds)*np.cos(RA - RAs)*np.cos(phi)))/rS**3)/r) - l_csi*(((mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/(r*np.cos(phi)) - (mue*np.sin(phi)*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)**2))/(r*np.cos(phi)) + 2*n*(csi + omega)*(np.tan(phi)**2 + 1) - (np.sin(phi)*((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Ds)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Ds)*np.sin(RA - RAs))/rS**3))/(r*np.cos(phi)**2) - (2*c1*l_csi*u*np.sin(phi))/(LV*m*r**2*np.cos(phi)**3)) + l_v*(mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4) + 2*r*np.cos(phi)*np.sin(phi)*(csi + omega)**2)
    Ddyn10 = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r
    Ddyn11 = l_csi*((2*v)/r - 2*n*np.tan(phi)) - l_l - l_v*r*np.cos(phi)**2*(2*csi + 2*omega) + l_n*np.cos(phi)*np.sin(phi)*(2*csi + 2*omega)
    Ddyn12 = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*np.tan(phi)*(csi + omega)
    Ddyn13 = -c1*u/m**2 * LV    

    Ddyn = [Ddyn0, Ddyn1, Ddyn2, Ddyn3, Ddyn4, Ddyn5, Ddyn6, Ddyn7, Ddyn8, Ddyn9, Ddyn10, Ddyn11, Ddyn12, Ddyn13]
    
    return Ddyn


def BANGBANG_ControlDA(dyn: array, tau: float, t_startC, t_endC) -> array:     # t_startC = inital control; t_endC = switching time
    
    p = 15
                                                                               # tau goes from 0 to 1. tau = t_tilde/(tf-t0). t_tilde = t - t0 
    r     = dyn[0]
    eps   = dyn[1]
    phi   = dyn[2]
    v     = dyn[3]
    csi   = dyn[4]
    n     = dyn[5]
    m     = dyn[6]
    
    l_r   = dyn[7]
    l_l   = dyn[8]  
    l_phi = dyn[9]
    l_v   = dyn[10]
    l_csi = dyn[11]
    l_n   = dyn[12]
    l_m   = dyn[13]
               
    l = ln*np.pi/180 + eps
    
    # TIME 
    t = t_startC + (t_endC - t_startC) * tau
         
    # GG PERTURBATIONS
    aPg_r = -mue*((3*R**2 * c20*(3*(np.sin(phi))**2 - 1))/(2*r**4) + (9*R**2 * (np.cos(phi))**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (60*R**3 * (np.cos(phi))**3 * (s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (2*R**3 * c30*np.sin(phi)*(5*(np.sin(phi))**2 - 3))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (60*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (2*R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5)
    aPg_l =  -mue*((3*R**2 * (np.cos(phi))**2 * (2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3 * (np.cos(phi))**3 * (3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2 * np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3 * np.cos(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4))/(r*np.cos(phi))
    aPg_phi = mue*((15*R**3 * (np.cos(phi))**3 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2 * (np.cos(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2 * (np.sin(phi))**2 * (c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3 * c30*np.cos(phi)*(5*(np.sin(phi))**2 - 3))/(2*r**4) - (30*R**3 * np.cos(phi)*(np.sin(phi))**2 * (s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3 * (np.cos(phi))**2 * np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3 * c30*np.cos(phi)*(np.sin(phi))**2)/r**4 - (R**3 * np.sin(phi)*(15*(np.sin(phi))**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3 * (np.cos(phi))**2 * np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2 * np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2 * c20*np.cos(phi)*np.sin(phi))/r**3)/r
    
    # % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt             #% time in days (Dimensional for ephemeris)
    MJD2000 = tdays

    eps = np.pi * 23.44 /180
    ecl = np.array([[1, 0, 0], [0, np.cos(eps), -np.sin(eps)], [0, np.sin(eps), np.cos(eps)]])   #rotation ecliptic/equatorial
    kep = uplanet_DA(MJD2000)
    r_E = kp2rv(kep[0], kep[1], kep[2], kep[3], kep[4], kep[5], muS)
    r_S = - r_E /ll
       
    r_S = np.dot(ecl, r_S)                  # SUN position inertial geocentric equatorial frame
    r_M = ephMoon_DA(MJD2000)               # MOOn ....
    r_M = r_M /ll
      
    Ds =   np.arcsin(r_S[2]/norm(r_S))
    RAs =  np.arctan2( r_S[1]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ), r_S[0]/np.sqrt( (r_S[0])**2 + (r_S[1])**2 ) ) 
    Dm =   np.arcsin(r_M[2]/norm(r_M))
    RAm =  np.arctan2( r_M[1]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ), r_M[0]/np.sqrt( (r_M[0])**2 + (r_M[1])**2 ) ) 

    omega_dim = omega/tt
    RA = l + G0 + omega_dim * (t *tt - t0)
    
    cosPSIS = np.sin(phi) * np.sin(Ds) + np.cos(phi) * np.cos(Ds) * np.cos(RA - RAs)
    cosPSIM = np.sin(phi) * np.sin(Dm) + np.cos(phi) * np.cos(Dm) * np.cos(RA - RAm)

    rM = norm(r_M)
    rS = norm(r_S)

    a3r   = muS/rS**3 * r *(3*cosPSIS**2 - 1) + muM/rM**3 * r *(3*cosPSIM**2 - 1)
    a3l   = -3*muS/rS**3 * r * cosPSIS * np.cos(Ds) * np.sin(RA - RAs) - 3*muM/rM**3 * r * cosPSIM * np.cos(Dm) * np.sin(RA - RAm) 
    a3phi = 3*muS/rS**3 * r * cosPSIS * (np.cos(phi) * np.sin(Ds) - np.sin(phi) * np.cos(Ds) * np.cos(RA - RAs)) + 3*muM/rM**3 * r * cosPSIM * (np.cos(phi) * np.sin(Dm) - np.sin(phi) * np.cos(Dm) * np.cos(RA - RAm)) 


    # SRP PERTURBATIONS
    #     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/(m*M)        

    Psr = Psr * 1e-3 
    Psr = Psr * tt**2/ll 

    aSRPr   = - Psr * cosPSIS 
    aSRPl   =   Psr * np.cos(Ds) * np.sin(RA - RAs) 
    aSRPphi = - Psr * (np.sin(Ds) * np.cos(phi) - np.cos(Ds) * np.sin(phi) * np.cos(RA - RAs))
     
    
    aP_r   = aPg_r + a3r + aSRPr
    aP_l   = aPg_l + a3l + aSRPl
    aP_phi = aPg_phi + a3phi + aSRPphi
    
    # SWITCHING FUNCTION CALCULATION 
    c1 = Tmax * tt**2/ll/M *1e-3
    c2 = Tmax *tt**2/ll/M/(Isp/tt * g0 * tt**2/ll) *1e-3
    
    LV = norm([l_v, l_csi, l_n])
    rho = 1 - c1/c2 * LV/m - l_m
    
    
    u = 1/(1 + np.exp(p * rho))
    
    # if rho.cons() > 0 :
    #     u = 0
    # elif rho.cons() == 0: 
    #     u = rnd.uniform(0,1)
    # else:
    #     u = 1
    
    
    Ddyn = array.zeros(14)
    
    #DYNAMICS (CONTROLLED)
    
    Ddyn[0] = v
    Ddyn[1] = csi
    Ddyn[2] = n
    Ddyn[3] = -mue/r**2 + r*n**2 + r*(csi + omega)**2 *(np.cos(phi))**2 + aP_r - c1 * u/m * l_v/LV  
    Ddyn[4] = 2*n*(csi + omega)*np.tan(phi) - 2*v/r *(csi + omega) + aP_l/(r * np.cos(phi)) - 1/(r * np.cos(phi))**2 * c1 * u/m * l_csi/LV
    Ddyn[5] = -2*v/r *n - (csi + omega)**2 *np.sin(phi)*np.cos(phi) + aP_phi/r - 1/r**2 * c1 * u/m * l_n/LV
    Ddyn[6] = -c2 * u
    
    Ddyn[7] = l_n*(((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r - Psr*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r**2 + ((mue*((15*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 - (3*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) - (30*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (45*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (5*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**4 - (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) + (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**4 - (6*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (3*R**2*c20*np.cos(phi)*np.sin(phi))/r**3))/r**2 + (mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4))/r - (3*cosPSIM*muM*(np.sin(Dm)*np.cos(phi) - np.cos(Dm)*np.cos(RA - RAm)*np.sin(phi)))/rM**3 - (3*cosPSIS*muS*(np.sin(Ds)*np.cos(phi) - np.cos(Ds)*np.cos(RA - RAs)*np.sin(phi)))/rS**3)/r - (2*n*v)/r**2 - (2*c1*l_n*u)/(LV*m*r**3)) - l_v*(np.cos(phi)**2*(csi + omega)**2 + mue*((6*R**2*c20*(3*np.sin(phi)**2 - 1))/r**5 + (36*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**5 + (300*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**6 + (10*R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/r**6 + (36*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**5 + (300*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**6 + (10*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**6) + (2*mue)/r**3 + n**2 + (muM*(3*cosPSIM**2 - 1))/rM**3 + (muS*(3*cosPSIS**2 - 1))/rS**3) - l_csi*((2*v*(csi + omega))/r**2 + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Ds)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Ds)*np.sin(RA - RAs))/rS**3)/(r**2*np.cos(phi)) + ((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r**2*np.cos(phi)) + (mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5))/(r*np.cos(phi)) - (3*cosPSIM*muM*np.cos(Dm)*np.sin(RA - RAm))/rM**3 - (3*cosPSIS*muS*np.cos(Ds)*np.sin(RA - RAs))/rS**3)/(r*np.cos(phi)) + (2*c1*l_csi*u)/(LV*m*r**3*np.cos(phi)**2))     
    Ddyn[8] = (l_csi*mue*((3*R**2*np.cos(phi)**2*(4*s22*np.sin(2*l) + 4*c22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(9*s33*np.sin(3*l) + 9*c33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(4*s32*np.sin(2*l) + 4*c32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4)))/(r**2*np.cos(phi)**2) - (l_n*mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/r**2 - l_v*mue*((9*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**4 + (60*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**5 + (9*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**4 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**5 + (2*R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/r**5)
    Ddyn[9] = l_n*(np.cos(phi)**2*(csi + omega)**2 - np.sin(phi)**2*(csi + omega)**2 + ((mue*((6*R**2*np.cos(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 + (45*R**3*np.cos(phi)**3*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 - (3*R**2*c20*np.cos(phi)**2)/r**3 - (6*R**2*np.sin(phi)**2*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**3 - (30*R**3*np.sin(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 + (3*R**2*c20*np.sin(phi)**2)/r**3 + (5*R**3*c30*np.sin(phi)**3)/r**4 - (15*R**3*np.cos(phi)**3*(c31*np.cos(l) + s31*np.sin(l)))/r**4 + (R**3*c30*np.sin(phi)*(5*np.sin(phi)**2 - 3))/(2*r**4) + (12*R**2*np.cos(phi)*np.sin(phi)*(c21*np.cos(l) + s21*np.sin(l)))/r**3 + (105*R**3*np.cos(phi)**2*np.sin(phi)*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**4 - (90*R**3*np.cos(phi)*np.sin(phi)**2*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/(2*r**4) - (15*R**3*c30*np.cos(phi)**2*np.sin(phi))/r**4 + (45*R**3*np.cos(phi)*np.sin(phi)**2*(c31*np.cos(l) + s31*np.sin(l)))/r**4))/r - Psr*(np.sin(Ds)*np.sin(phi) + np.cos(Ds)*np.cos(RA - RAs)*np.cos(phi)) + (3*cosPSIM*muM*r*(np.sin(Dm)*np.sin(phi) + np.cos(Dm)*np.cos(RA - RAm)*np.cos(phi)))/rM**3 + (3*cosPSIS*muS*r*(np.sin(Ds)*np.sin(phi) + np.cos(Ds)*np.cos(RA - RAs)*np.cos(phi)))/rS**3)/r) - l_csi*(((mue*((3*R**2*np.sin(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (3*R**2*np.cos(phi)**2*(c21*np.sin(l) - s21*np.cos(l)))/r**3 - (15*R**3*np.cos(phi)**3*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (30*R**3*np.cos(phi)*np.sin(phi)**2*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (45*R**3*np.cos(phi)**2*np.sin(phi)*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4) - (15*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.sin(l) - s31*np.cos(l)))/r**4 + (6*R**2*np.cos(phi)*np.sin(phi)*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3))/(r*np.cos(phi)) - (mue*np.sin(phi)*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)**2))/(r*np.cos(phi)) + 2*n*(csi + omega)*(np.tan(phi)**2 + 1) - (np.sin(phi)*((mue*((3*R**2*np.cos(phi)**2*(2*c22*np.sin(2*l) - 2*s22*np.cos(2*l)))/r**3 + (15*R**3*np.cos(phi)**3*(3*c33*np.sin(3*l) - 3*s33*np.cos(3*l)))/r**4 + (3*R**2*np.cos(phi)*np.sin(phi)*(c21*np.sin(l) - s21*np.cos(l)))/r**3 + (15*R**3*np.cos(phi)**2*np.sin(phi)*(2*c32*np.sin(2*l) - 2*s32*np.cos(2*l)))/r**4 + (R**3*np.cos(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.sin(l) - s31*np.cos(l)))/(2*r**4)))/(r*np.cos(phi)) - Psr*np.cos(Ds)*np.sin(RA - RAs) + (3*cosPSIM*muM*r*np.cos(Dm)*np.sin(RA - RAm))/rM**3 + (3*cosPSIS*muS*r*np.cos(Ds)*np.sin(RA - RAs))/rS**3))/(r*np.cos(phi)**2) - (2*c1*l_csi*u*np.sin(phi))/(LV*m*r**2*np.cos(phi)**3)) + l_v*(mue*((60*R**3*np.cos(phi)**3*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 + (9*R**2*np.cos(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 - (9*R**2*np.sin(phi)**2*(c21*np.cos(l) + s21*np.sin(l)))/r**4 + (2*R**3*c30*np.cos(phi)*(5*np.sin(phi)**2 - 3))/r**5 - (120*R**3*np.cos(phi)*np.sin(phi)**2*(s32*np.sin(2*l) + c32*np.cos(2*l)))/r**5 - (180*R**3*np.cos(phi)**2*np.sin(phi)*(s33*np.sin(3*l) + c33*np.cos(3*l)))/r**5 + (20*R**3*c30*np.cos(phi)*np.sin(phi)**2)/r**5 - (2*R**3*np.sin(phi)*(15*np.sin(phi)**2 - 3)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 + (60*R**3*np.cos(phi)**2*np.sin(phi)*(c31*np.cos(l) + s31*np.sin(l)))/r**5 - (18*R**2*np.cos(phi)*np.sin(phi)*(s22*np.sin(2*l) + c22*np.cos(2*l)))/r**4 + (9*R**2*c20*np.cos(phi)*np.sin(phi))/r**4) + 2*r*np.cos(phi)*np.sin(phi)*(csi + omega)**2)
    Ddyn[10] = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r
    Ddyn[11] = l_csi*((2*v)/r - 2*n*np.tan(phi)) - l_l - l_v*r*np.cos(phi)**2*(2*csi + 2*omega) + l_n*np.cos(phi)*np.sin(phi)*(2*csi + 2*omega)
    Ddyn[12] = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*np.tan(phi)*(csi + omega)
    Ddyn[13] = -c1*u/m**2 * LV    

    
    return Ddyn * (t_endC - t_startC)


def RK78(Y0: array, X0: float, X1: float, t_sC, t_enC, f: Callable[[array, float, DA, DA], array]):

    Y0 = Y0.copy()

    N = len(Y0)

    H0 = 0.001
    HS = 0.1
    H1 = 100.0
    EPS = 1.e-12
    BS = 20 * EPS

    Z = array.zeros((N, 16))
    Y1 = array.zeros(N)

    VIHMAX = 0.0

    HSQR = 1.0 / 9.0
    A = np.zeros(13)
    B = np.zeros((13, 12))
    C = np.zeros(13)
    D = np.zeros(13)

    A = np.array([
        0.0, 1.0/18.0, 1.0/12.0, 1.0/8.0, 5.0/16.0, 3.0/8.0, 59.0/400.0,
        93.0/200.0, 5490023248.0/9719169821.0, 13.0/20.0,
        1201146811.0/1299019798.0, 1.0, 1.0,
    ])

    B[1, 0] = 1.0/18.0
    B[2, 0] = 1.0/48.0
    B[2, 1] = 1.0/16.0
    B[3, 0] = 1.0/32.0
    B[3, 2] = 3.0/32.0
    B[4, 0] = 5.0/16.0
    B[4, 2] = -75.0/64.0
    B[4, 3] = 75.0/64.0
    B[5, 0] = 3.0/80.0
    B[5, 3] = 3.0/16.0
    B[5, 4] = 3.0/20.0
    B[6, 0] = 29443841.0/614563906.0
    B[6, 3] = 77736538.0/692538347.0
    B[6, 4] = -28693883.0/1125000000.0
    B[6, 5] = 23124283.0/1800000000.0
    B[7, 0] = 16016141.0/946692911.0
    B[7, 3] = 61564180.0/158732637.0
    B[7, 4] = 22789713.0/633445777.0
    B[7, 5] = 545815736.0/2771057229.0
    B[7, 6] = -180193667.0/1043307555.0
    B[8, 0] = 39632708.0/573591083.0
    B[8, 3] = -433636366.0/683701615.0
    B[8, 4] = -421739975.0/2616292301.0
    B[8, 5] = 100302831.0/723423059.0
    B[8, 6] = 790204164.0/839813087.0
    B[8, 7] = 800635310.0/3783071287.0
    B[9, 0] = 246121993.0/1340847787.0
    B[9, 3] = -37695042795.0/15268766246.0
    B[9, 4] = -309121744.0/1061227803.0
    B[9, 5] = -12992083.0/490766935.0
    B[9, 6] = 6005943493.0/2108947869.0
    B[9, 7] = 393006217.0/1396673457.0
    B[9, 8] = 123872331.0/1001029789.0
    B[10, 0] = -1028468189.0/846180014.0
    B[10, 3] = 8478235783.0/508512852.0
    B[10, 4] = 1311729495.0/1432422823.0
    B[10, 5] = -10304129995.0/1701304382.0
    B[10, 6] = -48777925059.0/3047939560.0
    B[10, 7] = 15336726248.0/1032824649.0
    B[10, 8] = -45442868181.0/3398467696.0
    B[10, 9] = 3065993473.0/597172653.0
    B[11, 0] = 185892177.0/718116043.0
    B[11, 3] = -3185094517.0/667107341.0
    B[11, 4] = -477755414.0/1098053517.0
    B[11, 5] = -703635378.0/230739211.0
    B[11, 6] = 5731566787.0/1027545527.0
    B[11, 7] = 5232866602.0/850066563.0
    B[11, 8] = -4093664535.0/808688257.0
    B[11, 9] = 3962137247.0/1805957418.0
    B[11, 10] = 65686358.0/487910083.0
    B[12, 0] = 403863854.0/491063109.0
    B[12, 3] = - 5068492393.0/434740067.0
    B[12, 4] = -411421997.0/543043805.0
    B[12, 5] = 652783627.0/914296604.0
    B[12, 6] = 11173962825.0/925320556.0
    B[12, 7] = -13158990841.0/6184727034.0
    B[12, 8] = 3936647629.0/1978049680.0
    B[12, 9] = -160528059.0/685178525.0
    B[12, 10] = 248638103.0/1413531060.0

    C = np.array([
        14005451.0/335480064.0, 0.0, 0.0, 0.0, 0.0, -59238493.0/1068277825.0,
        181606767.0/758867731.0, 561292985.0/797845732.0,
        -1041891430.0/1371343529.0, 760417239.0/1151165299.0,
        118820643.0/751138087.0, -528747749.0/2220607170.0, 1.0/4.0,
    ])

    D = np.array([
        13451932.0/455176623.0, 0.0, 0.0, 0.0, 0.0, -808719846.0/976000145.0,
        1757004468.0/5645159321.0, 656045339.0/265891186.0,
        -3867574721.0/1518517206.0, 465885868.0/322736535.0,
        53011238.0/667516719.0, 2.0/45.0, 0.0,
    ])

    Z[:, 0] = Y0

    H = abs(HS)
    HH0 = abs(H0)
    HH1 = abs(H1)
    X = X0
    RFNORM = 0.0
    ERREST = 0.0

    while X != X1:

        # compute new stepsize
        if RFNORM != 0:
            H = H * min(4.0, np.exp(HSQR * np.log(EPS / RFNORM)))
        if abs(H) > abs(HH1):
            H = HH1
        elif abs(H) < abs(HH0) * 0.99:
            H = HH0
            # print("--- WARNING, MINIMUM STEPSIZE REACHED IN RK")

        if (X + H - X1) * H > 0:
            H = X1 - X

        for j in range(13):

            for i in range(N):

                Y0[i] = 0.0
                # EVALUATE RHS AT 13 POINTS
                for k in range(j):
                    Y0[i] = Y0[i] + Z[i, k + 3] * B[j, k]

                Y0[i] = H * Y0[i] + Z[i, 0]

            Y1 = f(Y0, X + H * A[j], t_sC, t_enC)

            for i in range(N):
                Z[i, j + 3] = Y1[i]

        for i in range(N):

            Z[i, 1] = 0.0
            Z[i, 2] = 0.0
            # EXECUTE 7TH,8TH ORDER STEPS
            for j in range(13):
                Z[i, 1] = Z[i, 1] + Z[i, j + 3] * D[j]
                Z[i, 2] = Z[i, 2] + Z[i, j + 3] * C[j]

            Y1[i] = (Z[i, 2] - Z[i, 1]) * H
            Z[i, 2] = Z[i, 2] * H + Z[i, 0]

        Y1cons = Y1.cons()

        # ESTIMATE ERROR AND DECIDE ABOUT BACKSTEP
        RFNORM = np.linalg.norm(Y1cons, np.inf)  # type: ignore
        if RFNORM > BS and abs(H / H0) > 1.2:
            H = H / 3.0
            RFNORM = 0
        else:
            for i in range(N):
                Z[i, 0] = Z[i, 2]
            X = X + H
            VIHMAX = max(VIHMAX, H)
            ERREST = ERREST + RFNORM

    Y1 = Z[:, 0]

    return Y1


def ShootingFun(l, initial, final, p):
   
    xf = final
    x0 = initial 
    Dyn0_Shoot = np.append(x0, l) 
    xx = odeint(BANGBANGcontinuation_propag, Dyn0_Shoot, t_CONTROL, args = (p, ))
    f = np.array([xx[nit-1,0]-xf[0], xx[nit-1,1]-xf[1], xx[nit-1,2]-xf[2],  xx[nit-1,3]-xf[3], xx[nit-1,4]-xf[4], xx[nit-1,5]-xf[5], xx[nit-1,13]-xf[6]])
    
    return f


def ShootingFunBB(l, initial, final):
   
    xf = final
    x0 = initial 
    Dyn0_Shoot = np.append(x0, l) 
    xx = odeint(BANGBANG_propag, Dyn0_Shoot, t_CONTROL)
    f = np.array([xx[nit-1,0]-xf[0], xx[nit-1,1]-xf[1], xx[nit-1,2]-xf[2],  xx[nit-1,3]-xf[3], xx[nit-1,4]-xf[4], xx[nit-1,5]-xf[5], xx[nit-1,13]-xf[6]])
    
    return f
 
    
# %% REFERENCE TRAJECTORY


# FREE DRIFT PROPAGATION (no control --- initial control set to 0. NO DA VARIABLES)

#initialize state and costate (costate = 0 -- no control applied here)
T0 = perf_counter()

dyn0_FD = [target[0,0], target[1,0] - ln*np.pi/180, target[2,0], target[3,0], target[4,0], target[5,0],  0, 0, 0, 0, 0, 0]

# Compute final state 
with DA.cache_manager():  # optional, for efficiency
       FDstate = odeint(FreeDrift_propag, dyn0_FD, t_FREEDRIFT)

final_FD = FDstate[nit-1,:]

# np.savetxt('FD_BB.txt', FDstate, fmt='%.16f')
 

# STEP1 -- load EOP costate solution. Initial guess for continuation method. Bang-Bang fuel optimal control computation

l_EOP = np.loadtxt('LAMBDA0_EOP2.txt', dtype = float)                          # load EOP solution (2nd order expansion)

p = 15

lm0 = 1                        #trial and error --- must be monotona decrescente. from high value to final value = 0. NONNEGATIVE  
lmf = 0

initial = [final_FD[0], final_FD[1], final_FD[2], final_FD[3], final_FD[4], final_FD[5], m0]
final = [target[0,1], target[1,1] - ln*np.pi/180, target[2,1], target[3,1], target[4,1], target[5,1], lmf]
lamda0_guess = np.array([l_EOP[0], l_EOP[1], l_EOP[2], l_EOP[3], l_EOP[4], l_EOP[5], lm0])

LAMBDA0_S = fsolve(ShootingFun, lamda0_guess, args = (initial, final, p,))

dyn0_shoot = np.append(initial, LAMBDA0_S)
ShootingState = odeint(BANGBANGcontinuation_propag, dyn0_shoot, t_CONTROL, args = (p,))
# np.savetxt('ShootBBcont_p15.txt', ShootingState, fmt='%.16f')

# TAKE CONTINOUITY APPROACH FINAL SOLUTION (LAMBDAs at p) and use it to integrate the real BANG BANG FOP
LAMBDA0_S = fsolve(ShootingFunBB, LAMBDA0_S, args = (initial, final))

dyn0_shoot = np.append(initial, LAMBDA0_S)
ShootingState = odeint(BANGBANG_propag, dyn0_shoot, t_CONTROL)

# np.savetxt('ShootBB.txt', ShootingState, fmt='%.16f')



# SWITCHING TIMES SHOOTING

xx = ShootingState
ts = [ ]
rho_list = [ ]
 
c1 = Tmax * tt**2/ll/M *1e-3
c2 = Tmax *tt**2/ll/M/(Isp/tt * g0 * tt**2/ll) *1e-3 


for i in range(len(xx)):
    l_v = xx[i,10]
    l_csi = xx[i,11]
    l_n = xx[i,12]
    l_m = xx[i,13] 
    mass = xx[i,6] 
    
    LV = norm([l_v, l_csi, l_n])
    rho_list.append(1 - c1/c2 * LV/mass - l_m)
    
rho = np.array([rho_list])
rho_fun = interpolate.interp1d(t_CONTROL, rho)  

y = rho_fun(t_CONTROL)
# plt.plot(t_CONTROL, y[0,:])
# plt.show  

rho0 = y[0,0]
err = 1
tol = 1e-10

for i in range(1,len(xx)):
    RHO = y[0,i]
    if RHO*rho0 < 0 :
        a = t_CONTROL[i-1]
        b = t_CONTROL[i]
        
        while err > tol:
            z = (b+a)/2
            
            if rho_fun(z) == 0:
                err = 0
            else:
                err = abs(rho_fun(z))
                
            if rho_fun(a) * rho_fun(z) > 0:
                a = z
            else:
                b = z
                   
            
        ts.append(z)
        err = 1
        
    rho0 = y[0,i]
 
    
t_switch = []
for i in range(len(ts)):
     t_switch.append(ts[i]*tt)


# Calculate reference state at every switch
Xf_ref = np.zeros([len(t_switch), 14])
 
for i in range(len(t_switch)):    
    ts = t_switch[i]    
    t_propag = np.linspace(tf1, ts, nit)/tt
    dyn0_shoot = np.append(initial, LAMBDA0_S)
    state = odeint(BANGBANG_propag, dyn0_shoot, t_propag)
    Xf_ref[i, :] = state[nit-1, :]
    
T1 = perf_counter()
    
print(f"Info: time RquiRd for numerical reference = {T1 - T0} s")

# np.savetxt('ShootBB.txt', ShootingState, fmt='%.16f')


#%%  DA BANG-BANG SOLUTION  -- EXPANSION AROUND THE REFERENCE 
exp_order = 2
DA.init(exp_order, 15)

# Initialize DA variables
dyn0 = array.identity(14)       # initialize state + costate vector reference (EXPANSION POINT is reference) 

dyn0[0]  += final_FD[0]
dyn0[1]  += final_FD[1]
dyn0[2]  += final_FD[2]
dyn0[3]  += final_FD[3]
dyn0[4]  += final_FD[4]
dyn0[5]  += final_FD[5]
dyn0[6]  += m0

dyn0[7]  += LAMBDA0_S[0]
dyn0[8]  += LAMBDA0_S[1]
dyn0[9]  += LAMBDA0_S[2]
dyn0[10] += LAMBDA0_S[3]
dyn0[11] += LAMBDA0_S[4]
dyn0[12] += LAMBDA0_S[5]
dyn0[13] += LAMBDA0_S[6]


# Expansion of polynomial map 
t_startC = tf1/tt

# Set DA perturbations on free-drift final state. IMPOSE DRHO = 0 at switching time.  State and costate perturbations are DA variables and must be assigned at the end  
F = array.zeros(15) 
F[0] += 0       # Drho is imposed = 0 at the switching time.  

F[1] += DA(1)
F[2] += DA(2)
F[3] += DA(3)
F[4] += DA(4)
F[5] += DA(5)
F[6] += DA(6)
F[7] += DA(7)

F[8] += DA(8)
F[9] += DA(9)
F[10] += DA(10)
F[11] += DA(11)
F[12] += DA(12)
F[13] += DA(13)
F[14] += DA(14)


T2 = perf_counter()
for i in range(len(t_switch)):
    # Compute polynomial map of final state for every switching time. The last iteration gives the variables at the last switching time. Then we need to propagate to the final point. 
       
    t_endC = (t_switch[i]/tt + DA(15))
        
    # with DA.cache_manager():  # optional, for efficiency
    Xf = RK78(dyn0, 0, 1, t_startC, t_endC, BANGBANG_ControlDA) 
                      
    m = Xf[6]
    l_v = Xf[10]
    l_csi = Xf[11]
    l_n = Xf[12]
    l_m = Xf[13]
     
    LV = norm([l_v, l_csi, l_n])
    
    M_rho = 1 - c1/c2 * LV/m - l_m
    
    Map = array.zeros(15)
    Map[0]  += M_rho - M_rho.cons()   #subtract constant part (at switch rho = 0). Due to bisection method we remain with small constnat part of rho. SUBTRACT IT!!
     
    Map[1]  += DA(1)
    Map[2]  += DA(2)
    Map[3]  += DA(3)
    Map[4]  += DA(4)
    Map[5]  += DA(5)
    Map[6]  += DA(6)
    Map[7]  += DA(7)
    
    Map[8]  += DA(8)
    Map[9]  += DA(9)
    Map[10] += DA(10)
    Map[11] += DA(11)
    Map[12] += DA(12)
    Map[13] += DA(13)
    Map[14] += DA(14)
    
    
    # Map = Map - Map.cons()
    M_inv = Map.invert()                                              #Invert polynomial map to find first real perturbed switching time     
    DELTA = (M_inv).eval(F)
    # print(f"Delta switching time (ADIMENSIONAL!!):\n{DELTA[14]}\n")
    
    
    t_startC = t_switch[i]/tt + DELTA[14]   #update initial time for next iteration
    
    X_at_switch = Xf.eval(DELTA) 
    
    dyn0 = array.zeros(14)
    dyn0[0]  += X_at_switch[0]
    dyn0[1]  += X_at_switch[1]
    dyn0[2]  += X_at_switch[2]
    dyn0[3]  += X_at_switch[3]
    dyn0[4]  += X_at_switch[4]
    dyn0[5]  += X_at_switch[5]
    dyn0[6]  += X_at_switch[6]
    
    dyn0[7]  += X_at_switch[7]
    dyn0[8]  += X_at_switch[8]
    dyn0[9]  += X_at_switch[9]
    dyn0[10] += X_at_switch[10]
    dyn0[11] += X_at_switch[11]
    dyn0[12] += X_at_switch[12]
    dyn0[13] += X_at_switch[13]
    
    
    # perturbation = np.array([0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0,   0,  0])
         
    # final = dyn0.eval(perturbation)
    # print(f" Error on switching state wrt reference (no perturbations):\n{final - Xf_ref[i, :]}\n")


# FINAL PROPAGATION  
t_endC = tf2/tt

#TARGET
targ = array.zeros(6)
targ[0] += target[0,1]
targ[1] += target[1,1] - ln*np.pi/180
targ[2] += target[2,1]
targ[3] += target[3,1]
targ[4] += target[4,1]
targ[5] += target[5,1]
    
# with DA.cache_manager():  # optional, for efficiency
Xf = RK78(dyn0, 0, 1, t_startC, t_endC, BANGBANG_ControlDA) 


# perturbation = np.array([0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0,   0,  0])
     
# final = Xf.eval(perturbation)
# print(f" final state (no perturbations):\n{final}\n")


Map_xf = Xf[:6] - targ
cval = - Map_xf.cons()                
# Map_xf = Xf[:6] - Xf[:6].cons()
Map_lmf = Xf[13] - Xf[13].cons()


final_MAP = array.zeros(15) 

final_MAP[0]  += DA(1)
final_MAP[1]  += DA(2)
final_MAP[2]  += DA(3)
final_MAP[3]  += DA(4)
final_MAP[4]  += DA(5)
final_MAP[5]  += DA(6)
final_MAP[6]  += DA(7)

final_MAP[7]  += Map_xf[0]
final_MAP[8]  += Map_xf[1]
final_MAP[9]  += Map_xf[2]
final_MAP[10] += Map_xf[3]
final_MAP[11] += Map_xf[4]
final_MAP[12] += Map_xf[5]
final_MAP[13] += Map_lmf

final_MAP[14] += DA(15)


INVERSE = final_MAP.invert()

T3 = perf_counter() 

print(f"Info: time RquiRd for 4th order expansion = {T3 - T2} s")                                            

# impose initial perturbations, final pert = 0 and lmf = 0. dtf = 0.
# perturbation = np.array([0, -0.005*np.pi/180, 0.005*np.pi/180, 0, 0, 0, 0,  cval[0], cval[1], cval[2], cval[3], cval[4], cval[5],   0,  0])
     
# CONTR = INVERSE.eval(perturbation)
# print(f"Delta initial conditions:\n{CONTR}\n") 

# # Propagate control trajectory and find new initial conditions when control is switched off and free drift restarts (new cycle)
# Pert = perturbation 
# dyn0_C = [Pert[0] + final_FD[0], Pert[1] + final_FD[1], Pert[2] + final_FD[2], Pert[3] + final_FD[3], Pert[4] + final_FD[4], Pert[5] + final_FD[5], Pert[6] + m0, 
#           CONTR[7] + LAMBDA0_S[0], CONTR[8] + LAMBDA0_S[1], CONTR[9] + LAMBDA0_S[2], CONTR[10] + LAMBDA0_S[3], CONTR[11] + LAMBDA0_S[4], CONTR[12] + LAMBDA0_S[5], CONTR[13] + LAMBDA0_S[6] ]


# ContrState = odeint(BANGBANG_propag, dyn0_C, t_CONTROL)

# np.savetxt('ContrStateBB_4.txt', ContrState, fmt='%.16f') 
         
    

#%% ANAYSIS WITH VARYING SRP COEFFICIENT 


# Cr_vect = np.linspace(1, 2, 100)                  # SRP coefficient --  from 0 to 2 (total absorption -- total reflection)

# ContrState_Cr = np.zeros([nit, 14, len(Cr_vect)])
# FDstate_Cr = np.zeros([nit, 12, len(Cr_vect)])

# t_FD_next = np.linspace(tf2, tf2 + tfd[1]*days, nit)/tt
                                                            

# for i in range(len(Cr_vect)): 
#     Cr = Cr_vect[i]
    
#     # FREE DRIFT PROPAGATION (no control --- initial control set to 0. NO DA VARIABLES)

#     #initialize state and costate (costate = 0 -- no control applied here)
#     dyn0_FD = [target[0,0], target[1,0] - ln*np.pi/180, target[2,0], target[3,0], target[4,0], target[5,0],  0, 0, 0, 0, 0, 0]

#     # Compute final state 
#     with DA.cache_manager():  # optional, for efficiency
#             FDstate = odeint(FreeDrift_propag, dyn0_FD, t_FREEDRIFT)

#     final_FD_Cr = FDstate[nit-1,:]
    
#     # impose initial perturbations, final pert = 0 and lmf = 0. dtf = 0.
#     perturbation = np.array([final_FD_Cr[0] - final_FD[0], final_FD_Cr[1] - final_FD[1], final_FD_Cr[2] - final_FD[2], 
#                               final_FD_Cr[3] - final_FD[3], final_FD_Cr[4] - final_FD[4], final_FD_Cr[5] - final_FD[5], 0,  
#                               cval[0], cval[1], cval[2], cval[3], cval[4], cval[5],   0,  0])
         
#     CONTR = INVERSE.eval(perturbation)
#     # print(f"Delta initial conditions:\n{CONTR}\n") 

#     # Propagate control trajectory and find new initial conditions when control is switched off and free drift restarts (new cycle)
#     Pert = perturbation 
#     dyn0_C = [Pert[0] + final_FD[0], Pert[1] + final_FD[1], Pert[2] + final_FD[2], Pert[3] + final_FD[3], Pert[4] + final_FD[4], Pert[5] + final_FD[5], Pert[6] + m0, 
#               CONTR[7] + LAMBDA0_S[0], CONTR[8] + LAMBDA0_S[1], CONTR[9] + LAMBDA0_S[2], CONTR[10] + LAMBDA0_S[3], CONTR[11] + LAMBDA0_S[4], CONTR[12] + LAMBDA0_S[5], 
#               CONTR[13] + LAMBDA0_S[6] ]

#     Cr = 1.5
#     ContrState_Cr[:, :, i] = odeint(BANGBANGcontinuation_propag, dyn0_C, t_CONTROL, args = (p,))
    
    
#     # Next Free drift
#     dyn0_FD = [ContrState_Cr[nit-1, 0, i], ContrState_Cr[nit-1, 1, i], ContrState_Cr[nit-1, 2, i], ContrState_Cr[nit-1, 3, i], ContrState_Cr[nit-1, 4, i], ContrState_Cr[nit-1, 5, i],  0, 0, 0, 0, 0, 0]

#     # Compute final state 
#     with DA.cache_manager():  # optional, for efficiency
#             FDstate_Cr[:, :, i] = odeint(FreeDrift_propag, dyn0_FD, t_FD_next)
    

# ContrState_Cr_2D = ContrState_Cr.reshape(ContrState_Cr.shape[0], -1)
# FDstate_Cr_2D = FDstate_Cr.reshape(FDstate_Cr.shape[0], -1)

       

# np.savetxt('ContrState_Cr1.txt', ContrState_Cr_2D, fmt='%.16f')
# np.savetxt('FDstate_Cr1.txt', FDstate_Cr_2D, fmt='%.16f')




















