clearvars; close all; clc;


% SCRIPT PLOTTING THE ONE-CYCLE STATION KEEPING RESULTS for Fuel Optimal Problem
% TAKE DATA FROM PYTHON ONE-CYCLE CODE
% TAKE DATA FROM TARGET OPTIMIZATION CODE

%% DIMENSIONALIZATION
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem)

% Thrust 
g0 = 9.8 * 1e-3;  %km/s^2                                             
Tmax = 0.3;
Isp = 3800;
M = 3000; 

% Continuation parameter
p = [1,4,8,10,15]; 

% TIME
hours = 3600;                               
days = 24*hours;

% t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                             %initial time MJD2000 (seconds)
t0 = date2mjd2000([2023, 01, 01, 0, 0, 0])*days;                             %initial time MJD2000 (seconds)


tc = 1;
tfd = importdata('tfd_BEST.txt');
 
tf1 = t0 + tfd(1)*days;                                                     
tf2 = tf1 + tc*days; 

nit = 10000; 
t_FREEDRIFT = linspace(t0, tf1, nit);
t_CONTROL = linspace(tf1, tf2, nit);

%% LOAD DATA FROM DACE
sph_FD = importdata('FD_BB.txt');               % FD track
sph_C2_EOP = importdata('ControlState2.txt');   % quadratic EOP

% Continuous solutions -- increase continuation parameter
sph_cont1 = importdata('shootBBcont_p1.txt');   
sph_cont4 = importdata('shootBBcont_p4.txt');
sph_cont8 = importdata('shootBBcont_p8.txt');
sph_cont10 = importdata('shootBBcont_p10.txt');
sph_cont15 = importdata('shootBBcont_p15.txt');
sph_S = sph_cont15; 
% sph_S = importdata('shootBB.txt');            %Real BANG BANG SOLUTION

% sph_C2 = importdata('ContrStateBB_2.txt');     % DA with random initial pert.

sph_Cr1 = importdata('ContrState_Cr1.txt');     % 4th order DA with varying Cr
sph_Cr2 = importdata('ContrState_Cr2.txt');     % 2nd order DA with varying Cr
sph_Cr3 = importdata('ContrState_Cr3.txt');     % 3rd order DA with varying Cr
sph_Cr = sph_Cr1;                               % SELECT WHICH ORDER CONSIDER

% FD_Cr = importdata('FDstate_Cr1.txt');
FD_Cr = importdata('FDstate_Cr2.txt');
% FD_Cr = importdata('FDstate_Cr3.txt');


target = importdata('target_2023_BEST.txt');
% target = importdata('target_22+1.txt');


% RESHAPE ARRAYS 
[n,j] = size(sph_Cr);
N = j/14; 
sphCr_3D = zeros(n, 14, N);
 
for n = 1 : N
    sphCr1_3D(:,:,n) = sph_Cr1(:, n:N:j);
    sphCr2_3D(:,:,n) = sph_Cr2(:, n:N:j);
    sphCr3_3D(:,:,n) = sph_Cr3(:, n:N:j);
    sphCr_3D(:,:,n) = sph_Cr(:, n:N:j);
end


[o,e] = size(FD_Cr);
F = e/12; 
FDCr_3D = zeros(o, 12, F);
for o = 1 : F
    FDCr_3D(:,:,o) = FD_Cr(:, o:F:e);
end


%% PLOT 1 cycle
fig = 1; 

figure(fig)  % Groundtrack
% plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k','LineWidth',0.5)
hold on
grid on
title('Groundtrack');
xlabel('Longitude [deg]');
ylabel('Latitude [deg]');
% plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
plot(rad2deg(sph_C2_EOP(:,2)), rad2deg(sph_C2_EOP(:,3)), '-g','LineWidth',1.5)
% plot(rad2deg(sph_C2(1,2)), rad2deg(sph_C2(1,3)),'sb','LineWidth', 2); 
% plot(rad2deg(sph_C2(end,2)), rad2deg(sph_C2(end,3)),'ob','LineWidth',2);
plot(rad2deg(sph_cont1(:,2)), rad2deg(sph_cont1(:,3)), ':b','LineWidth',1.5)
plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-.r','LineWidth',1.5)
% plot(rad2deg(sph_S(1,2)), rad2deg(sph_S(1,3)),'sb','LineWidth', 2); 
% plot(rad2deg(sph_S(end,2)), rad2deg(sph_S(end,3)),'ob','LineWidth',2);
plot(rad2deg(target(2,2))-60, rad2deg(target(3,2)),'om','LineWidth',2);
legend('End Free drift', 'EOP 2^{nd} order Solution', 'Continuation Solution p = 1', 'Bang-Bang Reference', 'Target', Location='best')

fig = fig+1; 

% figure(fig)
% plot((sph_FD(:,1))*ll, (sph_FD(:,4))*ll/tt, '-.k','LineWidth',1)
% hold on
% grid on
% title('Radius and radial vel');
% xlabel('Semi major axis [km]');
% ylabel('Radial velocity [km/s]');
% plot((sph_FD(1,1))*ll, (sph_FD(1,4))*ll/tt,'ok','LineWidth',1.5); 
% plot((sph_FD(end,1))*ll, (sph_FD(end,4))*ll/tt,'sk','LineWidth',2);
% % plot((sph_C1(:,1))*ll, (sph_C1(:,4))*ll/tt, '-c','LineWidth',1)
% % plot((sph_C2(:,1))*ll, (sph_C2(:,4))*ll/tt, '-b','LineWidth',1)
% % plot((sph_C2(1,1))*ll, (sph_C2(1,4))*ll/tt,'sc','LineWidth', 2); 
% % plot((sph_C2(end,1))*ll, (sph_C2(end,4))*ll/tt,'oc','LineWidth',2);
% plot((sph_S(:,1))*ll, (sph_S(:,4))*ll/tt, '-.r','LineWidth',1)
% plot((sph_S(1,1))*ll, (sph_S(1,4))*ll/tt,'sr','LineWidth', 2); 
% plot((sph_S(end,1))*ll, (sph_S(end,4))*ll/tt,'or','LineWidth',2);
% legend('Track', 'Start Free drift', 'End Free drift', 'Linear solution', '2nd order solution', 'Shooting solution', 'Start control', 'End control', Location='best')

% fig = fig+1; 

%% Thrust and switching times

c1 = Tmax * tt^2/ll/M *1e-3;
c2 = Tmax *tt^2/ll/M/(Isp/tt * g0 * tt^2/ll) *1e-3;

for i = 1 : length(sph_S)
    lv_S = sph_S(i,11); % * ll_c/tt_c^2;
    lcsi_S = sph_S(i,12); % * ll_c^2/tt_c^2;
    ln_S = sph_S(i,13); % * ll_c^2/tt_c^2;
    lm_S = sph_S(i,14); 
    m_S(i) = sph_S(i,7); 

%     lv_C2 = sph_C2(i,11); % * ll_c/tt_c^2;
%     lcsi_C2 = sph_C2(i,12); % * ll_c^2/tt_c^2;
%     ln_C2 = sph_C2(i,13); % * ll_c^2/tt_c^2;
%     lm_C = sph_C2(i,14); 
%     m_C2(i) = sph_C2(i,7); 
    
    LV_S = norm([lv_S, lcsi_S, ln_S]);
    rho_S(i) = 1 - c1/c2 * LV_S/m_S(i) - lm_S;

%     LV_C2 = norm([lv_C2, lcsi_C2, ln_C2]);
%     rho_C2(i) = 1 - c1/c2 * LV_C2/m_C2(i) - lm_C;

    for j = 1 : length(p)
        u_cont(i,j) = 1/(1 + exp(p(j) * rho_S(i)));
    end

%     av(i) = l_v/LV; acsi(i) = l_csi/LV; an(i) = l_n/LV;

    if rho_S(i) > 0
        u_S(i) = 0; 
    else 
        u_S(i) = 1;
    end

%     if rho_C2(i) > 0
%         u_C2(i) = 0; 
%     else 
%         u_C2(i) = 1;
%     end
end

Mf_S = m_S(end)*M;
M_consumed_kg_shooting = M - Mf_S 
DV_ms_shooting = -log(Mf_S/M)*Isp*g0*1e3

% Mf_C2 = m_C2(end)*M;
% M_consumed_kg_2ndORDER = M - Mf_C2 
% DV_ms_2ndORDER = -log(Mf_C2/M)*Isp*g0*1e3

% Computing mass and control for every perturbation (Cr variation)
for i = 1 : N
    for j = 1 : length(sphCr_3D)
        lv_Cr = sphCr_3D(j,11,i); % * ll_c/tt_c^2;
        lcsi_Cr = sphCr_3D(j,12,i); % * ll_c^2/tt_c^2;
        ln_Cr = sphCr_3D(j,13,i); % * ll_c^2/tt_c^2;
        lm_Cr = sphCr_3D(j,14,i); 
        m_Cr(i,j) = sphCr_3D(j,7,i);  
        
        LV_Cr = norm([lv_Cr, lcsi_Cr, ln_Cr]);
        rho_Cr(i,j) = 1 - c1/c2 * LV_Cr/m_Cr(i,j) - lm_Cr;
     
        if rho_Cr(i,j) > 0
            u_Cr(i,j) = 0; 
        else 
            u_Cr(i,j) = 1;
        end
    end
end

% Switching times
% n = 1; 
% j = 1; 
% for i = 1 : length(sph_S)
%     if u(i) < 0.6 && u(i) > 0.4 
%         ts(n, j) = t_CONTROL(i);
%         n = n+1;
%     end
% 
%     if i < length(sph_S)
%         if (u(i)<0.6 && u(i+1) > 0.6) || (u(i) > 0.4 && u(i+1) < 0.4)
%             j = j+1; 
%         end 
%     end 
% end 
% 
% TS = zeros(1, size(ts,2));
% count = zeros(1, size(ts,2));
% for j = 1 : size(ts,2)
%     for i = 1 : length(ts)
%         if ts(i,j) ~= 0 
%             TS(1,j) = TS(1,j) + ts(i,j);
%             count(1,j) = count(1,j) + 1; 
%         end 
%     end 
% end
% 
% switch_DAYS = (TS./count - t0)/days; 
% switch_MJD2000sec = (TS./count);

colormap((cool(N)))
mapcustom = (cool(N));

figure(fig)
plot((t_CONTROL - t0)/days, m_S*M, ':k', 'LineWidth',3)
hold on 
for i = 1 : N
    l = plot((t_CONTROL - t0)/days, m_Cr(i,:)*M, '-', 'Color', mapcustom(i,:), 'LineWidth',2); 
    l.Color = [l.Color, 0.6];
end
title('Mass consumption')
legend('Reference solution', 'DA control with inital perturbation')
% xline(switch_DAYS)
colormap cool
colorb = colorbar;
colorb.Label.String = 'Reflection Coefficient';
legend('Reference solution')
xlabel('Control Epoch from t_0 [Days]')
ylabel('Total mass [kg]')

fig = fig+1; 


% for j = 1 : length(p)
% figure(fig)
% plot((t_CONTROL - t0)/days, u_cont(:,j), '-', 'Color', mapcustom(j,:), 'LineWidth', 1)
% hold on
% end
figure(fig)
plot((t_CONTROL - t0)/days, u_S, ':k', 'LineWidth', 3)
hold on
% leg = num2cell(p);                     %legend
% leg = cellfun(@(leg) strcat("p = ",num2str(leg)), leg, 'UniformOutput', false);
% legend(leg,'location','NorthWest');

for i = 1 : N
    l = plot((t_CONTROL - t0)/days, u_Cr(i,:),'-', 'Color', mapcustom(i,:), 'LineWidth', 2);
    l.Color = [l.Color, 0.5];
end
legend('Reference solution')
xlabel('Control Epoch from t_0 [Days]')
ylabel('u')
% xline(switch_DAYS)
colormap cool
colorb = colorbar;
colorb.Label.String = 'Reflection Coefficient';

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(9300:9360) - t0)/days, u_S(9300:9360), ':k', 'LineWidth',3)
hold on
for i = 1 : N
    q = plot((t_CONTROL(9300:9360) - t0)/days, u_Cr(i,9300:9360),'-', 'Color', mapcustom(i,:), 'LineWidth', 2);
    q.Color = [q.Color, 0.5];
end

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(6540:6620) - t0)/days, u_S(6540:6620), ':k', 'LineWidth',3)
hold on
for i = 1 : N
    q = plot((t_CONTROL(6540:6620) - t0)/days, u_Cr(i,6540:6620),'-', 'Color', mapcustom(i,:), 'LineWidth', 2);
    q.Color = [q.Color, 0.5];
end

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(4270:4350) - t0)/days, u_S(4270:4350), ':k', 'LineWidth',3)
hold on
for i = 1 : N
    q = plot((t_CONTROL(4270:4350) - t0)/days, u_Cr(i,4270:4350),'-', 'Color', mapcustom(i,:), 'LineWidth', 2);
    q.Color = [q.Color, 0.7];
end

axes('position',[.65 .175 .25 .25])
box on 
plot((t_CONTROL(1600:1680) - t0)/days, u_S(1600:1680), ':k', 'LineWidth',3)
hold on
for i = 1 : N
    q = plot((t_CONTROL(1600:1680) - t0)/days, u_Cr(i,1600:1680),'-', 'Color', mapcustom(i,:), 'LineWidth', 2);
    q.Color = [q.Color, 0.5];
end




fig = fig+1; 

% figure(fig)
% plot((t_CONTROL - t0)/days, av, '-', 'LineWidth', 1.5)
% hold on
% plot((t_CONTROL - t0)/days, acsi, '-', 'LineWidth', 1.5)
% plot((t_CONTROL - t0)/days, an, '-', 'LineWidth', 1.5)
% grid minor
% legend('\alpha_{r}', '\alpha_{l}', '\alpha_{\phi}', 'Location','best')
% title('Thrust direction')

% fig = fig+1; 

figure(fig)
plot((t_CONTROL - t0)/days, rho_S, 'k', 'LineWidth',1.5)
hold on
for i = 1 : N
    l = plot((t_CONTROL - t0)/days, rho_Cr(i,:), 'Color', mapcustom(i,:)); 
    l.Color = [l.Color, 0.4];
end
yline(0)
grid minor
title('switching function')
legend('Reference solution', 'DA control with inital perturbation')
colormap cool
colorb = colorbar;
colorb.Label.String = 'Reflection Coefficient';


fig = fig+1; 


%% Plot solution with varying Cr 

figure(fig)
% FD = plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k');
% FD.Color = [FD.Color, 0.3];
hold on
    
xlabel('Longitude [deg]');
ylabel('Latitude [deg]');
% plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'oc','LineWidth',2); 
% plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'.k', 'MarkerSize',20);

% plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-k','LineWidth',1)

for i = 1: N 
    figure(fig)  % Groundtrack

%     l = plot(rad2deg(sphCr_3D(:,2,i)), rad2deg(sphCr_3D(:,3,i)), 'Color', mapcustom(i,:), 'LineWidth',0.5);
%     l.Color = [l.Color, 0.8];
% 
    g = plot(rad2deg(FDCr_3D(:,2,i)), rad2deg(FDCr_3D(:,3,i)), ':', 'Color', mapcustom(i,:), 'LineWidth',0.1);
    g.Color = [g.Color, 0.3];

%     plot(rad2deg(sphCr_3D(1,2,i)), rad2deg(sphCr_3D(1,3,i)),'s', 'Color', mapcustom(i,:)); 
    plot(rad2deg(sphCr_3D(end,2,i)), rad2deg(sphCr_3D(end,3,i)),'o', 'Color', mapcustom(i,:), 'MarkerSize', 9, 'LineWidth',2.5);
%     plot(rad2deg(MC2_3D(end,2,i)), rad2deg(MC2_3D(end,3,i)),'.b');
%     plot(rad2deg(target(2,2))-60, rad2deg(target(3,2)), 'r*','LineWidth',1.5);
%     rectangle('Position',[rad2deg(sph_FD(end,2)) - 0.002, rad2deg(sph_FD(end,3)) - 0.002, 0.004, 0.004], 'EdgeColor','r', 'LineWidth', 1)
    legend('Second Cycle FD')
    axis equal
end

colormap cool
colorb = colorbar;
colorb.Label.String = 'Reflection Coefficient'; 

% figure(fig)
rectangle('Position',[-0.05, -0.05, 0.1, 0.1], 'EdgeColor','g', 'LineWidth',2.5)

fig = fig+1;
 

% ERROR ON FINAL TARGET
target(2,:) = target(2,:) - deg2rad(60);

targ_error_pos_S = abs(sph_S(end, 1:3)' - target(1:3,2));
targ_error_vel_S = abs(sph_S(end, 4:6)' - target(4:6,2));

lambdaS = sph_S(end,2);

phiS = sph_S(end,3);

RS = [cos(lambdaS)*cos(phiS), cos(phiS)*sin(lambdaS), sin(phiS)
      cos(lambdaS)*sin(phiS), sin(lambdaS)*sin(phiS), -cos(phiS)
      -sin(lambdaS),            cos(lambdaS),          0];


targ_error_pos_S = RS\targ_error_pos_S; 
targ_error_vel_S = RS\targ_error_vel_S;

for i = 1:N
    targ_error_pos1(:,i) = abs(sphCr1_3D(end, 1:3, i)' - target(1:3,2));
    targ_error_vel1(:,i) = abs(sphCr1_3D(end, 4:6, i)' - target(4:6,2));

    targ_error_pos2(:,i) = abs(sphCr2_3D(end, 1:3, i)' - target(1:3,2));
    targ_error_vel2(:,i) = abs(sphCr2_3D(end, 4:6, i)' - target(4:6,2));

    targ_error_pos3(:,i) = abs(sphCr3_3D(end, 1:3, i)' - target(1:3,2));
    targ_error_vel3(:,i) = abs(sphCr3_3D(end, 4:6, i)' - target(4:6,2));

    lambda1 = sphCr1_3D(end,2,i);
    lambda2 = sphCr2_3D(end,2,i);
    lambda3 = sphCr3_3D(end,2,i);

    phi1 = sphCr1_3D(end,3,i);
    phi2 = sphCr2_3D(end,3,i);
    phi3 = sphCr3_3D(end,3,i);

    R1 = [cos(lambda1)*cos(phi1), cos(phi1)*sin(lambda1), sin(phi1)
          cos(lambda1)*sin(phi1), sin(lambda1)*sin(phi1), -cos(phi1)
          -sin(lambda1),            cos(lambda1),          0];

    R2 = [cos(lambda2)*cos(phi2), cos(phi2)*sin(lambda2), sin(phi2)
          cos(lambda2)*sin(phi2), sin(lambda2)*sin(phi2), -cos(phi2)
          -sin(lambda2),            cos(lambda2),          0];

    R3 = [cos(lambda3)*cos(phi3), cos(phi3)*sin(lambda3), sin(phi3)
          cos(lambda3)*sin(phi3), sin(lambda3)*sin(phi3), -cos(phi3)
          -sin(lambda3),            cos(lambda3),          0];


    targ_error_pos1(:,i) = R1\targ_error_pos1(:,i); 
    targ_error_vel1(:,i) = R1\targ_error_vel1(:,i); 

    targ_error_pos2(:,i) = R2\targ_error_pos2(:,i); 
    targ_error_vel2(:,i) = R2\targ_error_vel2(:,i);

    targ_error_pos3(:,i) = R3\targ_error_pos3(:,i); 
    targ_error_vel3(:,i) = R3\targ_error_vel3(:,i);
  
end

POSerror_norm_S = vecnorm([targ_error_pos_S]*ll,2);
VELerror_norm_S = vecnorm([targ_error_vel_S]*ll/tt,2);

POSerror_norm1 = mean(vecnorm([targ_error_pos1]*ll,2));
VELerror_norm1 = mean(vecnorm([targ_error_vel1]*ll/tt,2));

POSerror_norm2 = mean(vecnorm([targ_error_pos2]*ll,2));
VELerror_norm2 = mean(vecnorm([targ_error_vel2]*ll/tt,2));

POSerror_norm3 = mean(vecnorm([targ_error_pos3]*ll,2));
VELerror_norm3 = mean(vecnorm([targ_error_vel3]*ll/tt,2));

% PLOT ERROR -- ABSOLUTE VALUE IN LOG SCALE
figure(fig)
subplot(1,2,1)
semilogy([1:1:N], ones(1,N).*POSerror_norm1*1e3, '-', 'LineWidth', 2)
hold on
semilogy([1:1:N], ones(1,N).*POSerror_norm2*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], ones(1,N).*POSerror_norm3*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], ones(1,N).*POSerror_norm_S*1e3, '-k', 'LineWidth', 1)
% semilogy([1:1:N], ones(1,N).*1e-6, '-k', 'LineWidth', 1)
grid on
xlim([1,N])
xlabel('Control Cycle')
ylabel('log|r_{Cf} - r_{T}|')
title('Target Matching error - Position [m]')

subplot(1,2,2)
semilogy([1:1:N], ones(1,N).*VELerror_norm1*1e3, '-', 'LineWidth', 2)
hold on
semilogy([1:1:N], ones(1,N).*VELerror_norm2*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], ones(1,N).*VELerror_norm3*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], ones(1,N).*VELerror_norm_S*1e3, '-k', 'LineWidth', 1)
% semilogy([1:1:N], ones(1,N).*1e-10, '-k', 'LineWidth', 1)
grid on
xlim([1,N])
xlabel('Control Cycle')
ylabel('log|v_{Cf} - v_{T}|')
title('Target Matching error - Velocity [m/s]')



% Extract positions and velocities of the propagated samples at final time -- covariance
sphCr_3D(:,1,:) = sphCr_3D(:,1,:)*ll;
sphCr_3D(:,2,:) = rad2deg(sphCr_3D(:,2,:));
sphCr_3D(:,3,:) = rad2deg(sphCr_3D(:,3,:));

sphCr_3D(:,4,:) = sphCr_3D(:,4,:)*ll/tt;
sphCr_3D(:,5,:) = rad2deg(sphCr_3D(:,5,:))/tt;
sphCr_3D(:,6,:) = rad2deg(sphCr_3D(:,6,:))/tt;



for i = 1:N

    lambda1 = sphCr_3D(1,2,i);
    phi1 = sphCr_3D(1,3,i);
    R1 = [cos(lambda1)*cos(phi1), cos(phi1)*sin(lambda1), sin(phi1)
          cos(lambda1)*sin(phi1), sin(lambda1)*sin(phi1), -cos(phi1)
          -sin(lambda1),            cos(lambda1),          0];

    lambdaf = sphCr_3D(end,2,i);
    phif = sphCr_3D(end,3,i);
    Rf = [cos(lambdaf)*cos(phif), cos(phif)*sin(lambdaf), sin(phif)
          cos(lambdaf)*sin(phif), sin(lambdaf)*sin(phif), -cos(phif)
          -sin(lambdaf),            cos(lambdaf),          0];

    POS_cart_0(:,i) = R1\sphCr_3D(1,1:3,i)'; 
    VEL_cart_0(:,i) = R1\sphCr_3D(1,4:6,i)';

    POS_cart_f(:,i) = Rf\sphCr_3D(end,1:3,i)'; 
    VEL_cart_f(:,i) = Rf\sphCr_3D(end,4:6,i)';
    
end

r0 = squeeze(POS_cart_0)';  %km^2
v0 = squeeze(VEL_cart_0)';  %m^2/s^2

rf = squeeze(POS_cart_f)';  %km^2
vf = squeeze(VEL_cart_f)';  %m^2/s^2


% Compute sample mean and sample covariance of the MC samples at the final time 
% x0 = [r0 v0]; 
% x_mean_0 = mean(x0)';
P0_pos = cov(r0);
P0_vel = cov(v0.*1e3);
T0_pos = sqrt(trace(P0_pos))
T0_vel = sqrt(trace(P0_vel))

Pf_pos = cov(rf);
Pf_vel = cov(vf.*1e3);
Tf_pos = sqrt(trace(Pf_pos))
Tf_vel = sqrt(trace(Pf_vel))


% rf = squeeze(sphCr_3D(end,1:3,:))';
% vf = squeeze(sphCr_3D(end,4:6,:))';
% 
% 
% % Compute sample mean and sample covariance of the MC samples at the final time 
% xf = [rf vf]; 
% x_mean_f = mean(xf)';
% Pf = cov(xf);
% 
% T0 = sqrt(trace(P0))
% Tf = sqrt(trace(Pf))



