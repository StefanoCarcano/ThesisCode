clearvars; close all; clc;


% SCRIPT PLOTTING THE YEAR STATION KEEPING RESULTS for Energy Optimal Problem
% TAKE DATA FROM PYTHON ONE-CYCLE CODE
% TAKE DATA FROM TARGET OPTIMIZATION CODE

%% DIMENSIONALIZATION
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem) 

% Performance parameters
Mi_S = 3000; %initial mass kg
Mi_2 = 3000;
Mi_1GG = 3000; 

Isp = 3800; % spec. impulse s
g0 = 9.8;  % m/s^2

% Time
hours = 3600; 
days = 24*3600; 
% t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                             %initial time MJD2000 (seconds)
t0 = date2mjd2000([2023, 01, 01, 0, 0, 0])*days;                             %initial time MJD2000 (seconds) 

tfd = importdata('tfd_BEST.txt');
tc = 1; 

fig = 1; 

%% LOAD DATA FROM DACE

% load Free Drift tracks (linear: linear; 1GG: 4th order geopot+linear correction; 2: quadratic; s: shooting)
FDlinear = importdata('FD1_year.txt');
FD1GG = importdata('FD1+GG_year.txt');
FD2 = importdata('FD2_year.txt');
FDs = importdata('FDs_year.txt');

% load Control tracks
sph_Clinear = importdata('ContrState1_year.txt');
sph_C1GG = importdata('ControlState_STM.txt');          % solution with 4th order GG + STM around GG solution (same as GG + linear DA)
sph_C2 = importdata('ContrState2_year.txt');
sph_Cs = importdata('ShootingState.txt');

% Load Targets
target = importdata('target_2023_BEST.txt');
% target = importdata('target_22+1.txt');


%% RESHAPE ARRAYS
[n,j] = size(FD1GG);
N = j/12; 
FD_3D = zeros(n, 12, N);
sphC1GG_3D = zeros(n, 12, N);

targ_error_pos1 = zeros(3,N);
targ_error_vel1 = zeros(3,N);
targ_error_pos1GG = zeros(3,N);
targ_error_vel1GG = zeros(3,N);
targ_error_pos2 = zeros(3,N);
targ_error_vel2 = zeros(3,N);
targ_error_posS = zeros(3,N);
targ_error_velS = zeros(3,N);

for n = 1 : N
    FDlinear_3D(:,:,n) = FDlinear(:, n:N:j);
    FD1GG_3D(:,:,n) = FD1GG(:, n:N:j);
    FD2_3D(:,:,n) = FD2(:, n:N:j);
    FDs_3D(:,:,n) = FDs(:, n:N:j);

    sphClinear_3D(:,:,n) = sph_Clinear(:, n:N:j);
    sphC1GG_3D(:,:,n) = sph_C1GG(:, n:N:j);
    sphC2_3D(:,:,n) = sph_C2(:, n:N:j);
    sphCs_3D(:,:,n) = sph_Cs(:, n:N:j);

end


%% MONTHLY CONTROL PLOT and error 
target(2,:) = target(2,:) - deg2rad(60);
color = [[1 0.5 0]; [0.4 0.2 0.1]; [0 1 1]; [1 0 1]; [0.5 1 0.3]; [0.4 0.1 1]; [0.84 0.55 0.32]; [0.9 1 0.2]; [0.05 0.2 0.1]; [0.55 0.4 0.68]; [0.24 1 0.41]; [0.31 0.01 0.65]; [1 0 0.1]; [0.05 0.65 0.25]; [0.85 0.55 0.67]]; 


for i = 1:N
    targ_error_pos1(:, i) = abs(sphClinear_3D(end, 1:3, i)' - target(1:3,i+1));
    targ_error_vel1(:, i) = abs(sphClinear_3D(end, 4:6, i)' - target(4:6,i+1));
    targ_error_pos1GG(:, i) = abs(sphC1GG_3D(end, 1:3, i)' - target(1:3,i+1));
    targ_error_vel1GG(:, i) = abs(sphC1GG_3D(end, 4:6, i)' - target(4:6,i+1));
    targ_error_pos2(:, i) = abs(sphC2_3D(end, 1:3, i)' - target(1:3,i+1));
    targ_error_vel2(:, i) = abs(sphC2_3D(end, 4:6, i)' - target(4:6,i+1));
    targ_error_posS(:, i) = abs(sphCs_3D(end, 1:3, i)' - target(1:3,i+1));
    targ_error_velS(:, i) = abs(sphCs_3D(end, 4:6, i)' - target(4:6,i+1));
    


    figure(fig)  % Groundtrack
%     FD = plot(rad2deg(FDlinear_3D(:,2,i)) + 60, rad2deg(FDlinear_3D(:,3,i)), ':k');
%     FD = plot(rad2deg(FD1GG_3D(:,2,i)) + 60, rad2deg(FD1GG_3D(:,3,i)), ':k');
    FD = plot(rad2deg(FD2_3D(:,2,i)) + 60, rad2deg(FD2_3D(:,3,i)), ':k');
%     FD = plot(rad2deg(FDs_3D(:,2,i)) + 60, rad2deg(FDs_3D(:,3,i)), ':k');
    FD.Color = [FD.Color, 0.5]; 
    hold on
    grid minor
    title('Groundtrack');
    xlabel('Longitude [deg]');
    ylabel('Latitude [deg]'); 

%     plot(rad2deg(sphClinear_3D(:,2,i)) + 60, rad2deg(sphClinear_3D(:,3,i)),'-k','LineWidth',1)
%     plot(rad2deg(sphC1GG_3D(:,2,i)) + 60, rad2deg(sphC1GG_3D(:,3,i)),'-k','LineWidth',1)
    plot(rad2deg(sphC2_3D(:,2,i)) + 60, rad2deg(sphC2_3D(:,3,i)),'-k','LineWidth',1)
%     plot(rad2deg(sphCs_3D(:,2,i)) + 60, rad2deg(sphCs_3D(:,3,i)),'-k','LineWidth',1)
    

%     plot(rad2deg(FDlinear_3D(end,2,i)) + 60, rad2deg(FDlinear_3D(end,3,i)),'sk','MarkerSize', 10,'LineWidth',2.5);  
%     plot(rad2deg(FD1GG_3D(end,2,i)) + 60, rad2deg(FD1GG_3D(end,3,i)),'sk','MarkerSize', 10,'LineWidth',2);  
    plot(rad2deg(FD2_3D(end,2,i)) + 60, rad2deg(FD2_3D(end,3,i)),'sk','MarkerSize', 10,'LineWidth',2); 
%     plot(rad2deg(FDs_3D(end,2,i)) + 60, rad2deg(FDs_3D(end,3,i)),'sk','MarkerSize', 10, 'LineWidth',2.5);

%     plot(rad2deg(sphClinear_3D(end,2,i)) + 60, rad2deg(sphClinear_3D(end,3,i)),'oc','LineWidth',2.5);
%     plot(rad2deg(sphC1GG_3D(end,2,i)) + 60, rad2deg(sphC1GG_3D(end,3,i)),'oc','MarkerSize',12,'LineWidth',2.5);
    plot(rad2deg(sphC2_3D(end,2,i)) + 60, rad2deg(sphC2_3D(end,3,i)),'oc','MarkerSize',12,'LineWidth',2.5);
%     plot(rad2deg(sphCs_3D(end,2,i)) + 60, rad2deg(sphCs_3D(end,3,i)),'oc','MarkerSize',12,'LineWidth',2.5);


    plot(rad2deg(target(2,i)) + 60, rad2deg(target(3,i)),'.r','MarkerSize',30);
    plot(rad2deg(target(2,end)) + 60, rad2deg(target(3,end)),'.r','MarkerSize',30);

%     legend('Free drift after linear control', 'Linear control', 'End free drift', 'End linear control', 'Selected Target points', Location='bestoutside')
%     legend('Free drift after 4th order GG & non autonomous STM', '4th order GG & non autonomous STM control','End Free drift', 'End control4th order GG & non autonomous STM', 'Selected Target points', Location='bestoutside')
%     legend('Free drift after 2nd order control', '2nd order control', 'End free drift', 'End 2nd order control', 'Selected Target points', Location='bestoutside')
    legend('Free drift Tracks', 'Control Tracks', 'End free drift', 'End control', 'Selected Target points', Location='bestoutside')
    

%     figure(fig+1)  
%     FD = plot((FD1GG_3D(:,1,i))*ll, (FD1GG_3D(:,4,i))*ll/tt, '-.k','LineWidth',1); 
%     FD.Color = [FD.Color, 0.1];
%     hold on
%     grid on
%     title('Semi major axis and radial velocity');
%     xlabel('a [km]');
%     ylabel('v [km/s]');
%     %     plot((sphC2_3D(:,1,i))*ll, (sphC2_3D(:,4,i))*ll/tt,'--k','LineWidth',0.5)
%     plot((sphC1GG_3D(:,1,i))*ll, (sphC1GG_3D(:,4,i))*ll/tt,'--k','LineWidth',1)
% %     plot((sph_FD(1,1)), (sph_FD(1,4)),'ok','LineWidth',1.5); 
%     plot((FD1GG_3D(end,1,i))*ll, (FD1GG_3D(end,4,i))*ll/tt,'sk','LineWidth',2);
%     plot((FDs_3D(end,1,i))*ll, (FDs_3D(end,4,i))*ll/tt,'sm','LineWidth',2);
% %     plot((sphC2_3D(1,1,i)), (sphC2_3D(1,4,i)),'sr','LineWidth', 2); 
%     plot((sphC1GG_3D(end,1,i))*ll, (sphC1GG_3D(end,4,i))*ll/tt,'ok','LineWidth',2);
%     plot((sphCs_3D(end,1,i))*ll, (sphCs_3D(end,4,i))*ll/tt,'oc','LineWidth',2);
%     plot((target(1,i))*ll, (target(4,i))*ll/tt,'*r','LineWidth',2);
%     plot((target(1,end))*ll, (target(4,end))*ll/tt,'*r','LineWidth',2);
% %     plot(rad2deg(sphC2_3D(end,2,i)), rad2deg(sphC2_3D(end,3,i)),'or','LineWidth',2);
%     legend('Free drift 4th order GG & non autonomous STM', '4th order GG & non autonomous STM control','End Free drift 4th order GG & non autonomous STM', 'End Free drift shooting', 'End control4th order GG & non autonomous STM', 'End control 2nd order', 'End control shooting', 'Selected Target points', Location='best')

end 

figure(fig)
rectangle('Position',[60-0.05, -0.05, 0.1, 0.1], 'EdgeColor','g', 'LineWidth',2.5)

fig = fig + 2; 


% ERROR (dimensionalize)

for i = 1:N
%     targ_error_pos1(1,i) = ll*(targ_error_pos1(1,i)) * cos(sphClinear_3D(end,2,i)) * cos(sphClinear_3D(end,3,i));
%     targ_error_pos1GG(1,i) = ll*(targ_error_pos1GG(1,i)) * cos(sphC1GG_3D(end,2,i)) * cos(sphC1GG_3D(end,3,i));
%     targ_error_pos2(1,i) = ll*(targ_error_pos2(1,i)) * cos(sphC2_3D(end,2,i)) * cos(sphC2_3D(end,3,i));
%     targ_error_posS(1,i) = ll*(targ_error_posS(1,i)) * cos(sphCs_3D(end,2,i)) * cos(sphCs_3D(end,3,i));
%     
%     targ_error_pos1(2,i) = ll*(targ_error_pos1(1,i)) * sin(sphClinear_3D(end,2,i)) * cos(sphClinear_3D(end,3,i));
%     targ_error_pos1GG(2,i) = ll*(targ_error_pos1GG(1,i)) * sin(sphC1GG_3D(end,2,i)) * cos(sphC1GG_3D(end,3,i));
%     targ_error_pos2(2,i) = ll*(targ_error_pos2(1,i)) * sin(sphC2_3D(end,2,i)) * cos(sphC2_3D(end,3,i));
%     targ_error_posS(2,i) = ll*(targ_error_posS(1,i)) * sin(sphCs_3D(end,2,i)) * cos(sphCs_3D(end,3,i));
%     
%     targ_error_pos1(3,i) = ll*(targ_error_pos1(1,i)) * sin(sphClinear_3D(end,3,i));
%     targ_error_pos1GG(3,i) = ll*(targ_error_pos1GG(1,i)) * sin(sphC1GG_3D(end,3,i));
%     targ_error_pos2(3,i) = ll*(targ_error_pos2(1,i)) *  sin(sphC2_3D(end,3,i));
%     targ_error_posS(3,i) = ll*(targ_error_posS(1,i)) * sin(sphCs_3D(end,3,i));
    lambda1 = sphClinear_3D(end,2,i);
    lambda1GG = sphC1GG_3D(end,2,i);
    lambda2 = sphC2_3D(end,2,i);
    lambdaS = sphCs_3D(end,2,i);

    phi1 = sphClinear_3D(end,3,i);
    phi1GG = sphC1GG_3D(end,3,i);
    phi2 = sphC2_3D(end,3,i);
    phiS = sphCs_3D(end,3,i);

    R1 = [cos(lambda1)*cos(phi1), cos(phi1)*sin(lambda1), sin(phi1)
          cos(lambda1)*sin(phi1), sin(lambda1)*sin(phi1), -cos(phi1)
          -sin(lambda1),            cos(lambda1),          0];

    R1GG = [cos(lambda1GG)*cos(phi1GG), cos(phi1GG)*sin(lambda1GG), sin(phi1GG)
          cos(lambda1GG)*sin(phi1GG), sin(lambda1GG)*sin(phi1GG), -cos(phi1GG)
         -sin(lambda1GG),            cos(lambda1GG),          0];

    R2 = [cos(lambda2)*cos(phi2), cos(phi2)*sin(lambda2), sin(phi2)
          cos(lambda2)*sin(phi2), sin(lambda2)*sin(phi2), -cos(phi2)
         -sin(lambda2),            cos(lambda2),          0];

    RS = [cos(lambdaS)*cos(phiS), cos(phiS)*sin(lambdaS), sin(phiS)
          cos(lambdaS)*sin(phiS), sin(lambdaS)*sin(phiS), -cos(phiS)
         -sin(lambdaS),            cos(lambdaS),          0];
    

    targ_error_pos1(:,i) = R1\targ_error_pos1(:,i); 
    targ_error_pos1GG(:,i) = R1GG\targ_error_pos1GG(:,i);
    targ_error_pos2(:,i) = R2\targ_error_pos2(:,i);
    targ_error_posS(:,i) = RS\targ_error_posS(:,i);

    targ_error_vel1(:,i) = R1\targ_error_vel1(:,i); 
    targ_error_vel1GG(:,i) = R1GG\targ_error_vel1GG(:,i);
    targ_error_vel2(:,i) = R2\targ_error_vel2(:,i);
    targ_error_velS(:,i) = RS\targ_error_velS(:,i);
    
%     targ_error_vel1(1,i) = ll/tt*(targ_error_vel1(1,i)) * cos(sphClinear_3D(end,2,i)) * cos(sphClinear_3D(end,3,i));
%     targ_error_vel1GG(1,i) = ll/tt*(targ_error_vel1GG(1,i)) * cos(sphClinear_3D(end,2,i)) * cos(sphClinear_3D(end,3,i));
%     targ_error_vel2(1,i) = ll/tt*(targ_error_vel2(1,i)) * cos(sphClinear_3D(end,2,i)) * cos(sphClinear_3D(end,3,i));
%     targ_error_velS(1,i) = ll/tt*(targ_error_velS(1,i)) * cos(sphClinear_3D(end,2,i)) * cos(sphClinear_3D(end,3,i));
%     
%     targ_error_vel1(2,i) = rad2deg(targ_error_vel1(2,i))/tt;
%     targ_error_vel1GG(2,i) = rad2deg(targ_error_vel1GG(2,i))/tt;
%     targ_error_vel2(2,i) = rad2deg(targ_error_vel2(2,i))/tt;
%     targ_error_velS(2,i) = rad2deg(targ_error_velS(2,i))/tt;
%     
%     targ_error_vel1(3,i) = rad2deg(targ_error_vel1(3,i))/tt;
%     targ_error_vel1GG(3,i) = rad2deg(targ_error_vel1GG(3,i))/tt;
%     targ_error_vel2(3,i) = rad2deg(targ_error_vel2(3,i))/tt;
%     targ_error_velS(3,i) = rad2deg(targ_error_velS(3,i))/tt;
end
 
% t = 0; 
% for i = 1 : N
%     t = t + t0 + tfd(i) + tc;
%     alpha1(i) = sphClinear_3D(end,2,i) + 1/tt * (t * tt - t0);
%     R = []
% end


% error_pos1_cart = R*targ_error_pos1;
% error_pos1GG_cart = R*targ_error_pos1GG;
% error_pos2_cart = R*targ_error_pos2;
% error_posS_cart = R*targ_error_posS;
% 
% error_vel1_cart = R*targ_error_vel1;
% error_vel1GG_cart = R*targ_error_vel1GG;
% error_vel2_cart = R*targ_error_vel2;
% error_velS_cart = R*targ_error_velS;


POSerror_norm1 = vecnorm([targ_error_pos1]*ll,2);
POSerror_norm2 = vecnorm([targ_error_pos2]*ll,2);
POSerror_norm1GG = vecnorm([targ_error_pos1GG]*ll,2);
POSerror_normS = vecnorm([targ_error_posS]*ll,2);

VELerror_norm1 = vecnorm([targ_error_vel1]*ll/tt,2);
VELerror_norm2 = vecnorm([targ_error_vel2]*ll/tt,2);
VELerror_norm1GG = vecnorm([targ_error_vel1GG]*ll/tt,2);
VELerror_normS = vecnorm([targ_error_velS]*ll/tt,2);


% error_norm1 = vecnorm([targ_error_pos1;targ_error_vel1],2);
% error_norm2 = vecnorm([targ_error_pos2;targ_error_vel2],2);
% error_norm1GG = vecnorm([targ_error_pos1GG;targ_error_vel1GG],2);
% error_normS = vecnorm([targ_error_posS;targ_error_velS],2);

% error_norm1_vel = vecnorm(targ_error_vel1,2);
% error_norm2_vel = vecnorm(targ_error_vel2,2);
% error_norm1GG_vel = vecnorm(targ_error_vel1GG,2);
% error_normS_vel = vecnorm(targ_error_velS,2);


% PLOT ERROR -- ABSOLUTE VALUE IN LOG SCALE
figure(fig)
subplot(1,2,1)
semilogy([1:1:N], POSerror_norm1*1e3, '-', 'LineWidth', 2)
hold on
semilogy([1:1:N], POSerror_norm1GG*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], POSerror_norm2*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], POSerror_normS*1e3, '-', 'LineWidth', 2)
grid on
xlim([1,N])
xlabel('Control Cycle')
ylabel('log|r_{Cf} - r_{T}|')
legend('1st Order', '4th Order autonomous & Linear correction', '2nd Order', 'Shooting', Location='best')
title('Target Matching error - Position [m]')

% fig = fig+1;
% 
% figure(fig)
subplot(1,2,2)
semilogy([1:1:N], VELerror_norm1*1e3, '-', 'LineWidth', 2)
hold on
semilogy([1:1:N], VELerror_norm1GG*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], VELerror_norm2*1e3, '-', 'LineWidth', 2)
semilogy([1:1:N], VELerror_normS*1e3, '-', 'LineWidth', 2)
grid on
xlim([1,N])
xlabel('Control Cycle')
ylabel('log|v_{Cf} - v_{T}|')
legend('1st Order', '4th Order autonomous & Linear correction', '2nd Order', 'Shooting', Location='best')
title('Target Matching error - Velocity [m/s]')

fig = fig+1; 

%% Plot error -- coordinate by coordinate

% position error
% figure(fig)
% subplot(3,1,1)
% title('Target radius matching error -- 4th order autonomous & time dependent STM vs 2nd order control')
% yyaxis left
% plot([1:1:N], targ_error_pos1GG(1,:), '.-b', 'LineWidth', 1)
% hold on
% xline([1:1:N], '--', 'LineWidth', 0.1, 'HandleVisibility', 'off')
% xlabel('Control Cycle')
% ylabel('|r error| [km]')
% xlim([1, N])
% yyaxis right
% plot([1:1:N], targ_error_pos2(1,:), '.-r', 'LineWidth', 1)
% ylabel('|r error| [km]')
% grid minor
% legend('4th order + STM', '2nd order')
% 
% 
% subplot(3,1,2)
% title('Target longitude matching error -- 4th order autonomous & time dependent STM vs 2nd order control')
% yyaxis left
% plot([1:1:N], targ_error_pos1GG(2,:), '.-b', 'LineWidth', 1)
% hold on
% xline([1:1:N], '--', 'LineWidth', 0.1, 'HandleVisibility', 'off') 
% xlabel('Control Cycle')
% ylabel('|\lambda error| [deg]')
% xlim([1, N])
% yyaxis right
% plot([1:1:N], targ_error_pos2(2,:), '.-r', 'LineWidth', 1)
% ylabel('|\lambda error| [deg]')
% grid minor
% legend('4th order + STM', '2nd order')
% 
% 
% subplot(3,1,3)
% title('Target latitude matching error -- 4th order autonomous & time dependent STM vs 2nd order control')
% yyaxis left
% plot([1:1:N], targ_error_pos1GG(3,:), '.-b', 'LineWidth', 1)
% hold on
% xline([1:1:N], '--', 'LineWidth', 0.1, 'HandleVisibility', 'off')
% xlabel('Control Cycle')
% ylabel('|\phi error| [deg]')
% xlim([1, N])
% yyaxis right
% plot([1:1:N], targ_error_pos2(3,:), '.-r', 'LineWidth', 1)
% ylabel('|\phi error| [deg]')
% grid minor
% legend('4th order + STM', '2nd order')
% 
% fig = fig+1; 
% 
% % velocity error
% figure(fig)
% subplot(3,1,1)
% title('Target radial velocity matching error -- 4th order autonomous & time dependent STM vs 2nd order control')
% yyaxis left
% plot([1:1:N], targ_error_vel1GG(1,:) * ll/tt, '.-b', 'LineWidth', 1)
% hold on
% xline([1:1:N], '--', 'LineWidth', 0.1, 'HandleVisibility', 'off') 
% xlabel('Control Cycle')
% ylabel('|v error| [km/s]')
% xlim([1, N])
% yyaxis right
% plot([1:1:N], targ_error_vel2(1,:) * ll/tt, '.-r', 'LineWidth', 1)
% ylabel('|v error| [km/s]')
% grid minor
% legend('4th order + STM', '2nd order')
% 
% 
% subplot(3,1,2)
% title('Target transversal velocity matching error -- 4th order autonomous & time dependent STM vs 2nd order control')
% yyaxis left
% plot([1:1:N], rad2deg(targ_error_vel1GG(2,:))/tt, '.-b', 'LineWidth', 1)
% hold on
% xline([1:1:N], '--', 'LineWidth', 0.1, 'HandleVisibility', 'off')
% xlabel('Control Cycle')
% ylabel('|\xi error| [deg/s]')
% xlim([1, N])
% yyaxis right
% plot([1:1:N], rad2deg(targ_error_vel2(1,:))/tt, '.-r', 'LineWidth', 1)
% ylabel('|\xi error|')
% grid minor
% legend('4th order + STM', '2nd order')
% 
% subplot(3,1,3)
% title('Target out of plane velocity matching error -- 4th order autonomous & time dependent STM vs 2nd order control')
% yyaxis left
% plot([1:1:N], rad2deg(targ_error_vel1GG(3,:))/tt, '.-b', 'LineWidth', 1)
% hold on
% xline([1:1:N], '--', 'LineWidth', 0.1, 'HandleVisibility', 'off') 
% xlabel('Control Cycle')
% ylabel('|n error| [deg/s]')
% xlim([1, N])
% yyaxis right
% plot([1:1:N], rad2deg(targ_error_vel2(1,:))/tt, '.-r', 'LineWidth', 1)
% ylabel('|n error| [deg/s]')
% grid minor
% legend('4th order + STM', '2nd order')
% 
% fig = fig +1; 


% Plot Error 
% x = [1:1:N]; 
% 
% figure()
% subplot(3,1,1)
% plot(x, posErr1(1,:), '.-r') 
% hold on
% plot(x, posErr2(1,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Semi-major axis error [km]')
% grid minor
% legend('1st order error', '2nd order error')
% title('Position Error on target point')
% 
% subplot(3,1,2)
% plot(x, posErr1(2,:), '.-r') 
% hold on
% plot(x, posErr2(2,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Longitude error [deg]')
% grid minor
% legend('1st order error', '2nd order error')
% 
% subplot(3,1,3)
% plot(x, posErr1(3,:), '.-r') 
% hold on
% plot(x, posErr2(3,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Latitude error [deg]')
% grid minor
% legend('1st order error', '2nd order error')
% 
% figure()
% subplot(3,1,1)
% plot(x, velErr1(1,:), '.-r') 
% hold on
% plot(x, velErr2(1,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Radial vel error [km/s]')
% grid minor
% legend('1st order error', '2nd order error')
% title('Velocity error on target point')
% 
% subplot(3,1,2)
% plot(x, velErr1(2,:), '.-r') 
% hold on
% plot(x, velErr2(2,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Longitude drift error [deg/s]')
% grid minor
% legend('1st order error', '2nd order error')
% 
% subplot(3,1,3)
% plot(x, velErr1(3,:), '.-r') 
% hold on
% plot(x, velErr2(3,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Latitude drift error [deg/s]')
% grid minor
% legend('1st order error', '2nd order error')


%% Plot Control

% Control evolution  
%  [ll_c/tt_c^3; ll_c^2/tt_c^3; ll_c^2/tt_c^3;
%   ll_c/tt_c^2; ll_c^2/tt_c^2; ll_c^2/tt_c^2];

nit = 5000;
t = t0; 
time = [];

u_fd = zeros(nit,1);                                                       % Control during freedrift (=0)

for i = 1 : N 

    tf1 = t + tfd(i)*days;                                                     % final free drift time (in seconds) 
    tf2 = tf1 + tc*days;                                                  % final control time (in seconds) 
    t_FREEDRIFT = linspace(t, tf1, nit)./tt;
    t_CONTROL = linspace(tf1, tf2, nit)./tt;

    u_rS = - sphCs_3D(:, 10, i) * ll_c/tt_c^2 ;
    urS(:,i) = [u_fd; u_rS];

    u_r2(:,i) = - sphC2_3D(:, 10, i) * ll_c/tt_c^2 ;
    ur2(:,i) = [u_fd; u_r2(:,i)];

    u_r1GG(:,i) = - sphC1GG_3D(:, 10, i) * ll_c/tt_c^2 ;
    ur1GG(:,i) = [u_fd; u_r1GG(:,i)];

    r(:,i) = [FD1GG_3D(:,1,i); sphC1GG_3D(:,1,i)];
    long(:,i) = [FD1GG_3D(:,2,i); sphC1GG_3D(:,2,i)];
    lat(:,i) = [FD1GG_3D(:,3,i); sphC1GG_3D(:,3,i)];

    v(:,i) = [FDs_3D(:,4,i); sphCs_3D(:,4,i)];
    csi(:,i) = [FDs_3D(:,5,i); sphCs_3D(:,5,i)];
    eta(:,i) = [FDs_3D(:,6,i); sphCs_3D(:,6,i)];
    
    for j = 1 : nit
        u_lS(j,i) = - sphCs_3D(j, 11, i) * ll_c/tt_c^2 / (sphCs_3D(j, 1, i) * cos(sphCs_3D(j, 3, i))) ;
        u_phiS(j,i) = - sphCs_3D(j, 12, i) * ll_c/tt_c^2 / sphCs_3D(j, 1, i);

        u_l2(j,i) = - sphC2_3D(j, 11, i) * ll_c/tt_c^2 / (sphC2_3D(j, 1, i) * cos(sphC2_3D(j, 3, i))) ;
        u_phi2(j,i) = - sphC2_3D(j, 12, i) * ll_c/tt_c^2 / sphC2_3D(j, 1, i);

        u_l1GG(j,i) = - sphC1GG_3D(j, 11, i) * ll_c/tt_c^2 / (sphC1GG_3D(j, 1, i) * cos(sphC1GG_3D(j, 3, i))) ;
        u_phi1GG(j,i) = - sphC1GG_3D(j, 12, i) * ll_c/tt_c^2 / sphC1GG_3D(j, 1, i);
    end
    
    ulS(:,i) = [u_fd; u_lS(:,i)];
    uphiS(:,i) = [u_fd; u_phiS(:,i)];

    ul2(:,i) = [u_fd; u_l2(:,i)];
    uphi2(:,i) = [u_fd; u_phi2(:,i)];

    ul1GG(:,i) = [u_fd; u_l1GG(:,i)];
    uphi1GG(:,i) = [u_fd; u_phi1GG(:,i)];

    time = [time, t_FREEDRIFT, t_CONTROL];

    % compute performance index 
    uS = [u_rS, u_lS(:,i), u_phiS(:,i)].*1e3;  % m/s^2 
    US = vecnorm(uS,2,2);

    u2 = [u_r2, u_l2(:,i), u_phi2(:,i)].*1e3;  % m/s^2 
    U2 = vecnorm(u2,2,2);

    u1GG = [u_r1GG, u_l1GG(:,i), u_phi1GG(:,i)].*1e3;  % m/s^2 
    U1GG = vecnorm(u1GG,2,2);
 
    t_int = linspace(0, tc*days, nit);  

% Mass equation integration  m_dot = -T/Ig0   --- T = m*a  --- a = |u|
    accS = mean(US);
    acc2 = mean(U2); 
    acc1GG = mean(U1GG);

    options = odeset('reltol', 1.e-12,'abstol', 1.e-12);
    
    [~, massS] = ode113(@(t,m) mass_int(t, m, accS, Isp, g0), t_int, Mi_S, options);
    [~, mass2] = ode113(@(t,m) mass_int(t, m, acc2, Isp, g0), t_int, Mi_2, options);
    [~, mass1GG] = ode113(@(t,m) mass_int(t, m, acc1GG, Isp, g0), t_int, Mi_1GG, options);
    
    MfS = massS(end);
    Mf2 = mass2(end);
    Mf1GG = mass1GG(end);

    MS_consumed(i) = Mi_S - MfS;
    M2_consumed(i) = Mi_2 - Mf2;
    M1GG_consumed(i) = Mi_1GG - Mf1GG;

    DV_S(i) = -log(MfS/Mi_S)*Isp*g0; 
    DV_2(i) = -log(Mf2/Mi_2)*Isp*g0;
    DV_1GG(i) = -log(Mf1GG/Mi_1GG)*Isp*g0;

    Mi_S = MfS;
    Mi_2 = Mf2;
    Mi_1GG = Mf1GG;

    for k = 1 : length(mass2)
        T(k,i) = U2(k)*mass2(k); 
    end 

%     figure(fig)
%     plot(t_int/days, U2, '-', 'LineWidth', 1)
%     hold on
%     grid minor

    t = tf2; 
    
end 

% fig = fig+1;

colormap(cool(N))
% mapcustom = (cool(N));
% for i = 1:N
%     figure(fig) 
%     area(linspace(0,24,5000), T(:,i), '-', 'Color', mapcustom(i,:), 'LineWidth', 1.5)
%     hold on
% end
T(:,15) = T(:,14);
tplt = linspace(0,24,5000);
XX = [1:1:N+1];
[X,Y] = meshgrid(linspace(0,24,5000), [1:1:N+1]);
[k,n] = find(T == max(max(T))); 
figure(fig)
surf(X,Y,T')
colorb = colorbar;
colorb.Label.String = 'Thrust [N]';
xlabel('[Hours]')
ylabel('Control Cycle')
grid minor
txt = '\leftarrow T_{MAX}';
text(tplt(k), XX(n), txt)
% xlim([0, (time(end)*tt - t0)/days]) 
% title('2nd order control vs exact control')

fig = fig+1;

Mass_consumed_SHOOTING = sum(MS_consumed)
Mass_consumed_2order = sum(M2_consumed) 
Mass_consumed_1GG = sum(M1GG_consumed) 

Dv_tot_ms_SHOOTING = sum(DV_S)
Dv_tot_ms_2order = sum(DV_2)
Dv_tot_ms_1GG = sum(DV_1GG)


urS_plt = reshape(urS, [], 1);
ulS_plt = reshape(ulS, [], 1);
uphiS_plt = reshape(uphiS, [], 1);


ur2_plt = reshape(ur2, [], 1);
ul2_plt = reshape(ul2, [], 1);
uphi2_plt = reshape(uphi2, [], 1);


colormap((cool(N)))
mapcustom = (cool(N));
for i = 1:N
    figure(fig) 
    plot(linspace(0,24,5000), u_r2(:,i)*1e3, '-', 'Color', mapcustom(i,:), 'LineWidth', 1.5)
    hold on
    plot(linspace(0,24,5000), u_l2(:,i)*1e3, ':', 'Color', mapcustom(i,:), 'LineWidth', 1.5)
    plot(linspace(0,24,5000), u_phi2(:,i)*1e3, '-.', 'Color', mapcustom(i,:), 'LineWidth', 2)
    legend('u2_{r}', 'u2_{l}', 'u2_{\phi}', Location='best')
end
colormap cool
colorb = colorbar('Ticks',[1/14,2/14,3/14,4/14,5/14,6/14,7/14,8/14,9/14,10/14,11/14,12/14,13/14,14/14],'TickLabels',{'1','2','3','4','5','6','7','8','9','10','11','12','13','14'});
colorb.Label.String = 'Control Cycle';
colorb.Ticks

% plot((time.*tt - t0)/24/3600, urS_plt*1e3, 'k', 'LineWidth', 1.5)
% plot((time.*tt - t0)/24/3600, ulS_plt*1e3, '--k', 'LineWidth', 1.5)
% plot((time.*tt - t0)/24/3600, uphiS_plt*1e3, '-.k', 'LineWidth', 1.5)

xlabel('[Hours]')
ylabel('m/s^{2}')
grid minor
% xlim([0, (time(end)*tt - t0)/days]) 
% title('2nd order control vs exact control')
fig = fig+1; 


%Plot coordinate evolution
r_plt = reshape(r, [], 1);
long_plt = reshape(long, [], 1);
lat_plt = reshape(lat, [], 1);

v_plt = reshape(v, [], 1);
csi_plt = reshape(csi, [], 1);
eta_plt = reshape(eta, [], 1);

count = 1;
for i = 1:N
    
    % Positions
    figure(fig)
    
    subplot(3,1,1) 
    plot((time(count:count+4999).*tt - t0)/24/3600, r_plt(count:count+4999)*ll, '-k', 'LineWidth',0.7);
    hold on
    plot((time(count+5000:count+9999).*tt - t0)/24/3600, r_plt(count+5000:count+9999)*ll, '-m', 'LineWidth',2);
%     l.Color = [l.Color, 0.5]; 
%     title('Distance r [km]')
    xlabel('Days')
    ylabel('r [km]')
    grid on
    grid minor

    subplot(3,1,2)
    plot((time(count:count+4999).*tt - t0)/24/3600, rad2deg(lat_plt(count:count+4999)), '-k', 'LineWidth',0.7);
    hold on
    plot((time(count+5000:count+9999).*tt - t0)/24/3600, rad2deg(lat_plt(count+5000:count+9999)), '-m', 'LineWidth',2);
%     title('Latitude \phi [deg]')
    xlabel('Days')
    ylabel('\phi [deg]')
    yline(0.05, ':r', 'LineWidth', 3.5)
    yline(-0.05, ':r', 'LineWidth', 3.5)
    ylim ([-0.07 0.07])
    grid on
    grid minor
    axis tight
    
 
    figure(fig+1)
%     subplot(3,1,2)
    plot((time(count:count+4999).*tt - t0)/24/3600, rad2deg(long_plt(count:count+4999)), '-k', 'LineWidth',0.7);
    hold on
    plot((time(count+5000:count+9999).*tt - t0)/24/3600, rad2deg(long_plt(count+5000:count+9999)), '-m', 'LineWidth',2);
    title('Longitude error \lambda - \lambda_n [deg]')
%     xlabel('Days')
%     ylabel('\lambda - \lambda_n [deg]')
    yline(0.05, ':r', 'LineWidth', 3.5)
    yline(-0.05, ':r', 'LineWidth', 3.5)
    axis tight
    legend('FD phase', 'Controlled Phase')




    % velocities
    figure(fig+2)
    subplot(3,1,1)
    plot((time(count:count+4999).*tt - t0)/24/3600, v_plt(count:count+4999)*1e3*ll/tt, '-k', 'LineWidth',0.7);
    hold on
    plot((time(count+5000:count+9999).*tt - t0)/24/3600, v_plt(count+5000:count+9999)*1e3*ll/tt, '-m', 'LineWidth',2);
%     l.Color = [l.Color, 0.5]; 
    title('Radial velocity v [m/s]')
    xlabel('Days')
%     ylabel('v [m/s]')
    grid on
    grid minor

    subplot(3,1,2)
    plot((time(count:count+4999).*tt - t0)/24/3600, rad2deg(csi_plt(count:count+4999))/tt, '-k', 'LineWidth',0.7);
    hold on
    plot((time(count+5000:count+9999).*tt - t0)/24/3600, rad2deg(csi_plt(count+5000:count+9999))/tt, '-m', 'LineWidth',2);
    title('Transversal velocity \xi [deg/s]')
    xlabel('Days')
%     ylabel('\xi [deg/s]')
    grid on
    grid minor
    axis tight
    
    subplot(3,1,3)
    plot((time(count:count+4999).*tt - t0)/24/3600, rad2deg(eta_plt(count:count+4999))/tt, '-k', 'LineWidth',0.7);
    hold on
    plot((time(count+5000:count+9999).*tt - t0)/24/3600, rad2deg(eta_plt(count+5000:count+9999))/tt, '-m', 'LineWidth',2);
    title('Out of plane velocity \eta [deg/s]')
    xlabel('Days')
    axis tight
    legend('FD phase', 'Controlled Phase')
    

    count = count+10000;
end

figure(fig+1)
xlabel('Days')
ylabel('\lambda - \lambda_n [deg]')
yline(0.05, ':r', 'LineWidth', 4, 'HandleVisibility','off')
yline(-0.05, ':r', 'LineWidth', 4, 'HandleVisibility','off')
ylim([-0.055 0.07])
axes('position',[.65 .175 .25 .25])
box on 
plot((time(10001:15000).*tt - t0)/24/3600, rad2deg(long_plt(10001:15000)), '-k', 'LineWidth',3)
yline(-0.05, ':r', 'LineWidth', 3.5)

axes('position',[.65 .175 .25 .25])
box on 
plot((time(30001:35000).*tt - t0)/24/3600, rad2deg(long_plt(30001:35000)), '-k', 'LineWidth',3)
yline(-0.05, ':r', 'LineWidth', 3.5)

axes('position',[.65 .175 .25 .25])
box on 
plot((time(100001:105000).*tt - t0)/24/3600, rad2deg(long_plt(100001:105000)), '-k', 'LineWidth',3)
yline(-0.05, ':r', 'LineWidth', 3.5)

axes('position',[.65 .175 .25 .25])
box on 
plot((time(130001:135000).*tt - t0)/24/3600, rad2deg(long_plt(130001:135000)), '-k', 'LineWidth',3)
yline(-0.05, ':r', 'LineWidth', 3.5)

axis tight

fig = fig+3;

%% COMPUTATIONAL TIME 
Comp_Time_Shooting = importdata('CompTimeSHOOT.txt') + 0.6;
Comp_Time_STM = importdata('CompTimeSTM.txt');
Comp_Time_DA2 = importdata('CompTimeDA2.txt');

figure(fig)
plot([1:1:N], Comp_Time_Shooting, '-', 'LineWidth',4)
hold on
plot([1:1:N], Comp_Time_STM, '-', 'LineWidth',4)
plot([1:1:N], Comp_Time_DA2, '-', 'LineWidth',4)
xlabel('Control Cycle')
ylabel('Computational Time [s]')
grid on
xlim([1,N])
legend('Shooting', 'Linear Expansion', '2^{nd} order Expansion')

TotTime_Shooting = sum(Comp_Time_Shooting)
TotTime_STM = sum(Comp_Time_STM)
TotTime_DA2 = sum(Comp_Time_DA2)

% %% Control error
% urDA4 = - sph_C4(:,10) * ll_c/tt_c^2;
% urDA1 = - sph_C1(:,10) * ll_c/tt_c^2; 
% urDAtot = - sph_Ctot(:,10) * ll_c/tt_c^2; 
% 
% for i = 1 : length(t_C)
%     ulDA4(i) = - sph_C4(i,11) * ll_c/tt_c^2/ (sph_C4(i,1) * cos(sph_C4(i,3)));
%     uphiDA4(i) = - sph_C4(i,12) * ll_c/tt_c^2/ sph_C4(i,1);
% 
%     ulDA1(i) = - sph_C1(i,11) * ll_c/tt_c^2/ (sph_C1(i,1) * cos(sph_C1(i,3)));
%     uphiDA1(i) = - sph_C1(i,12) * ll_c/tt_c^2/ sph_C1(i,1);
% 
%     ulDAtot(i) = - sph_Ctot(i,11)* ll_c/tt_c^2 / (sph_Ctot(i,1) * cos(sph_Ctot(i,3)));
%     uphiDAtot(i) = - sph_Ctot(i,12)* ll_c/tt_c^2 / sph_Ctot(i,1);
% 
%     u_exact(i) = sqrt(ur(i)^2 + ul(i)^2 + uphi(i)^2); 
%     u_DA4(i) = sqrt(urDA4(i)^2 + ulDA4(i)^2 + uphiDA4(i)^2); 
%     u_DA1(i) = sqrt(urDA1(i)^2 + ulDA1(i)^2 + uphiDA1(i)^2); 
%     u_DAtot(i) = sqrt(urDAtot(i)^2 + ulDAtot(i)^2 + uphiDAtot(i)^2);
%  
% end
% 
% figure()   
% plot((t_S.*tt - t0)/24/3600, ur, 'g')
% hold on
% plot((t_S.*tt - t0)/24/3600, ul, '--g')
% plot((t_S.*tt - t0)/24/3600, uphi, '-.g')
% plot((t_S.*tt - t0)/24/3600, urDA4, 'k')
% plot((t_S.*tt - t0)/24/3600, ulDA4, '--k')
% plot((t_S.*tt - t0)/24/3600, uphiDA4, '-.k')
% legend('u_{r}', 'u_{l}', 'u_{\phi}', 'u_{rDA4}', 'u_{lDA4}', 'u_{\phiDA4}', Location='best')
% xlabel('Days')
% % ylabel('m/s^{2}')
% grid minor
% title('Exact control vs 4th order control')

%% FUNCTIONS

function [m_dot] =  mass_int(~, m, acc, Isp, g0)
    
    m_dot = - (m*acc)/(Isp * g0); 

end
