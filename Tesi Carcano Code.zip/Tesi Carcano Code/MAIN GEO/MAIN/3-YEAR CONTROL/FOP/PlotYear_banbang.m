clearvars; close all; clc;

% SCRIPT PLOTTING THE YEAR STATION KEEPING RESULTS for Fuel Optimal Problem
% TAKE DATA FROM PYTHON ONE-CYCLE CODE
% TAKE DATA FROM TARGET OPTIMIZATION CODE

%% DIMENSIONALIZATION
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem) 

%% Time

hours = 3600; 
days = 24*3600; 
% t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                             %initial time MJD2000 (seconds)
t0 = date2mjd2000([2023, 01, 01, 0, 0, 0])*days;                             %initial time MJD2000 (seconds)


tc = 1;
tfd = importdata('tfd_BEST.txt');

% Thrust 
g0 = 9.8 * 1e-3;                                              
Tmax = 0.33;
Isp = 3800;
M = 3000; 

% Continuation parameter 
p = 15;

%% LOAD DATA FROM DACE

% Load Free-Drift tracks (1: linear; 2: quadratic; s: shooting)
% FD1 = importdata('FD1_year.txt');
% FD2 = importdata('FD2_year.txt');
FDs = importdata('FD_BB_y.txt');

% Load control tracks
% sph_C1 = importdata('ContrState1_year.txt');
sph_Cs = importdata('ShootBB_y.txt');
% sph_C2 = importdata('ContrState2_year.txt');

%Load tragets
% target = importdata('target_22+1.txt');
target = importdata('target_2023_BEST.txt');


%% RESHAPE ARRAYS
[n,j] = size(FDs);
N = j/14; 
FD_3D = zeros(n, 14, N);
targ_error = zeros(6,N); 

for n = 1 : N
%     FD1_3D(:,:,n) = FD1(:, n:N:j); 
%     FD2_3D(:,:,n) = FD2(:, n:N:j);
    FDs_3D(:,:,n) = FDs(:, n:N:j); 
%     sphC1_3D(:,:,n) = sph_C1(:, n:N:j);
%     sphC2_3D(:,:,n) = sph_C2(:, n:N:j);
    sphCs_3D(:,:,n) = sph_Cs(:, n:N:j);
end


%% MONTHLY CONTROL PLOT and error 
fig = 1; 
targ_error(2,:) = targ_error(2,:) - deg2rad(60);

for i = 1:N
    
    targ_error(:, i) = abs(sphCs_3D(end, 1:6, i)' - target(:,i)); 
    

    figure(fig)  % Groundtrack
    FD = plot(rad2deg(FDs_3D(:,2,i)) + 60, rad2deg(FDs_3D(:,3,i)), ':k');
    FD.Color = [FD.Color, 0.5];
    hold on
    grid minor
    title('Groundtrack');
    xlabel('Longitude [deg]');
    ylabel('Latitude [deg]'); 
    plot(rad2deg(sphCs_3D(:,2,i)) + 60, rad2deg(sphCs_3D(:,3,i)),'-k','LineWidth',1)
    plot(rad2deg(FDs_3D(end,2,i)) + 60, rad2deg(FDs_3D(end,3,i)),'sk','MarkerSize', 10,'LineWidth',2);
    plot(rad2deg(sphCs_3D(end,2,i)) + 60, rad2deg(sphCs_3D(end,3,i)),'oc','MarkerSize',12,'LineWidth',2.5);
    plot(rad2deg(target(2,i)), rad2deg(target(3,i)),'.r','MarkerSize',30);
    plot(rad2deg(target(2,end)), rad2deg(target(3,end)),'.r','MarkerSize',30);
    legend('FD track', 'Controlled track', 'End Free drift', 'End control', 'Selected Target points', Location='best')



%     figure(2)  
% %     plot(rad2deg(FD1_3D(:,2,i)), rad2deg(FD1_3D(:,3,i)), '--k','LineWidth',1)
%     hold on
%     grid on
%     title('Semi major axis and radial vel');
%     xlabel('a');
%     ylabel('v');
% %     plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
%     plot((FD1_3D(end,1,i)), (FD1_3D(end,4,i)),'sk','LineWidth',2);
%     plot((FDs_3D(end,1,i)), (FDs_3D(end,4,i)),'sc','LineWidth',2);
% %     plot(rad2deg(sphC1_3D(:,2,i)), rad2deg(sphC1_3D(:,3,i)),'-b','LineWidth',1)
% %     plot(rad2deg(sphC2_3D(1,2,i)), rad2deg(sphC2_3D(1,3,i)),'sr','LineWidth', 2); 
%     plot((sphC1_3D(end,1,i)), (sphC1_3D(end,4,i)),'ok','LineWidth',2);
%     plot((sphCs_3D(end,1,i)), (sphCs_3D(end,4,i)),'oc','LineWidth',2);
%     plot((target(1,i)), (target(4,i)),'*r','LineWidth',2);
% %     plot(rad2deg(sphC2_3D(end,2,i)), rad2deg(sphC2_3D(end,3,i)),'or','LineWidth',2);
%     legend('End Free drift 1st order', 'End Free drift shooting', 'End control 1st order', 'End control shooting', 'Target', Location='best')
    

end 
figure(fig)
rectangle('Position',[60-0.05, -0.05, 0.1, 0.1], 'EdgeColor','g', 'LineWidth',2.5)
fig = fig+1; 

 

%% Plot error
figure()
plot([1:1:N], targ_error, '.', 'MarkerSize', 17)
hold on
xline([1:1:N], '--', 'LineWidth', 0.1)
grid on 
xlabel('Control Cycle')
ylabel('|Coordinate Error|')
legend('a', '\lambda', '\phi', 'v', '\xi', 'n')
title('Target matching error -- 2nd order control ')

% Plot Error 
% x = [1:1:N]; 
% 
% figure()
% subplot(3,1,1)
% plot(x, posErr1(1,:), '.-r') 
% hold on
% plot(x, posErr2(1,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Semi-major axis error [km]')
% grid minor
% legend('1st order error', '2nd order error')
% title('Position Error on target point')
% 
% subplot(3,1,2)
% plot(x, posErr1(2,:), '.-r') 
% hold on
% plot(x, posErr2(2,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Longitude error [deg]')
% grid minor
% legend('1st order error', '2nd order error')
% 
% subplot(3,1,3)
% plot(x, posErr1(3,:), '.-r') 
% hold on
% plot(x, posErr2(3,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Latitude error [deg]')
% grid minor
% legend('1st order error', '2nd order error')
% 
% figure()
% subplot(3,1,1)
% plot(x, velErr1(1,:), '.-r') 
% hold on
% plot(x, velErr2(1,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Radial vel error [km/s]')
% grid minor
% legend('1st order error', '2nd order error')
% title('Velocity error on target point')
% 
% subplot(3,1,2)
% plot(x, velErr1(2,:), '.-r') 
% hold on
% plot(x, velErr2(2,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Longitude drift error [deg/s]')
% grid minor
% legend('1st order error', '2nd order error')
% 
% subplot(3,1,3)
% plot(x, velErr1(3,:), '.-r') 
% hold on
% plot(x, velErr2(3,:), '.-k')
% xlabel('Control Cycle')
% ylabel('Latitude drift error [deg/s]')
% grid minor
% legend('1st order error', '2nd order error')


%% THRUST AND SWITCHING TIMES

nit = 1000;
t = t0; 
time = [];

ufd = zeros(nit,1);                                                        % Control during freedrift (=0)
av_fd = zeros(nit,1);                                                      
acsi_fd = zeros(nit,1);                                                       
an_fd = zeros(nit,1);
Mass = zeros(nit*2, N);
M_fd = ones(nit,1);

for j = 1 : N
    tf1 = t + tfd(j)*days;                                                     % final free drift time (in seconds) 
    tf2 = tf1 + tc*days;                                                  % final control time (in seconds) 
    t_FREEDRIFT = linspace(t, tf1, nit)./tt;
    t_CONTROL = linspace(tf1, tf2, nit)./tt;

    for i = 1 : nit
        l_v = sphCs_3D(i,11,j); % * ll_c/tt_c^2;
        l_csi = sphCs_3D(i,12,j); % * ll_c^2/tt_c^2;
        l_n = sphCs_3D(i,13,j); % * ll_c^2/tt_c^2;
        l_m = sphCs_3D(i,14,j); 
        m(i,j) = sphCs_3D(i,7,j); 
        
        c1 = Tmax * tt^2/ll/M *1e-3;
        c2 = Tmax *tt^2/ll/M/(Isp/tt * g0 * tt^2/ll) *1e-3; 
        
        LV = norm([l_v, l_csi, l_n]);
        rho = 1 - c1/c2 * LV/m(i) - l_m;
        
%         u(i,j) = 1/(1 + exp(p * rho));

        if rho > 0
            u(i,j) = 0;
        else
            u(i,j) = 1;
        end

        av(i,j) = l_v/LV; acsi(i,j) = l_csi/LV; an(i,j) = l_n/LV; 

    end
    
    U(:,j) = [ufd; u(:,j)];
    aV(:,j) = [av_fd; av(:,j)];
    aCsi(:,j) = [acsi_fd; acsi(:,j)];
    aN(:,j) = [an_fd; an(:,j)];  
    Mass(:,j) = [M_fd; m(:,j)];
    M_fd = m(end,j)*ones(nit,1);

    time = [time, t_FREEDRIFT, t_CONTROL];

    t = tf2; 
%     figure(j+2)
%     plot((t_CONTROL - t0)/days,u(:,j))
end

Mf = m(end, end)*M;
M_consumed_kg = M - Mf 
DV_ms = -log(Mf/M)*Isp*g0*1e3  


u_plt = reshape(U, [], 1); 
av_plt = reshape(aV, [], 1); 
acsi_plt = reshape(aCsi, [], 1);
an_plt = reshape(aN, [], 1);
m_plt = reshape(Mass, [], 1);
 

u(:,15) = u(:,14);
XX = [1:1:N+1];
[X,Y] = meshgrid(linspace(0,24,1000), [1:1:N+1]); 
figure()
surf(X,Y,u'*Tmax)
colormap cool
colorb = colorbar;
colorb.Label.String = 'Thrust [N]';
xlabel('[Hours]')
ylabel('Control Cycle')
grid minor
txt = '\leftarrow T_{MAX}';

% xlim([0, (time(end)*tt - t0)/days]) 
% title('2nd order control vs exact control')


figure()
plot((time*tt - t0)/days, av_plt, '-', 'LineWidth', 1.2)
hold on
plot((time*tt - t0)/days, acsi_plt, '-.', 'LineWidth', 1.2)
plot((time*tt - t0)/days, an_plt, '--', 'LineWidth', 1.2)
xlim([0, (time(end)*tt - t0)/days])
legend('\alpha_{r}', '\alpha_{l}', '\alpha_{\phi}')

figure()
plot((time*tt - t0)/days, u_plt, '-', 'LineWidth', 0.8)
xlim([0, (time(end)*tt - t0)/days])

figure()
plot((time*tt - t0)/days, m_plt*M, '-b', 'LineWidth', 3)
hold on
xlim([0, (time(end)*tt - t0)/days])
xlabel('[Days]')
ylabel('Total mass [kg]')
grid minor
title('Mass consumption in a year')
axes('position',[.65 .175 .25 .25])
box on 
plot((time(1000:2000).*tt - t0)/24/3600, (m_plt(1000:2000)*M), '-b', 'LineWidth',3)

axes('position',[.65 .175 .25 .25])
box on 
plot((time(9000:10000).*tt - t0)/24/3600, (m_plt(9000:10000)*M), '-b', 'LineWidth',3)

