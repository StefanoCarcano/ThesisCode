The complete code has been implemented starting from the simplest case and then extendended to a more complex problem. It finally 
gives the 1 year Station Keeping solution for the EOP case (Shooting, DA expansions, autonomous-non autonomous combination) and the FOP
conversion (BANG BANG control). The FOP DA expansion has been also analyzed for the first cycle only. 


1 - First thing is the target optimization procedure. The code finds the optimized targets during an arbitrary time span (1year default)
    It saves a .txt file with positions and velocities of each target. Code on MATLAB. 

2 - In order to comprehend how each cycle works, second thing is the 1CYCLE EOP station keeping. The EOP first code (Python) 
    (EOP_controlGG) finds the control for a geopotential perturbed dynamics only (AUTONOMOUS SOLUTION, same for every cycle!!!!). 
    The EOP second code (EOP_1cycle) finds the complete SK solution (Shooting, DA Arbitrary order (1 RUN for each order, MUST BE UPDATED
    AS WELL AS SAVED FILES NAMES), Autonomous-Non autonomous solution).
    MATLAB Code (Plot_EOP) postprocesses the EOP 1 cycle results.
    
    The FOP 1 cycle (FOP_bbREF_1cycle) turns the EOP solution into a FOP NUMERICALLY (SHOOTING). (the DA second order solution 
    (LAMBDA0_EOP2) is taken as first guess of the FOP). AT THE END of this code, the variation of the reflection coefficient is analyzed 
    and corrected with a DA FOP EXPANSION with different expansion orders. 
    MATLAB Code (Plot_BangBang) postprocesses the FOP 1 cycle results. 

3 - FINALLY, the YEAR solution is found running the EOP year code (EOP_year). The autonomous-non autonomous EOP solution for a year 
    is given by the EOP_yearGG code. Then the FOP code (ONLY NUMERICAL SHOOTING SOLUTION). The sequence is the same as for the 1 cycle case.

NB: Add folders and subfolders to path. SAVE TXT FILES BEFORE RUNNING PLOT CODES. PAY ATTENTION TO SAVED FILES NAMES. 