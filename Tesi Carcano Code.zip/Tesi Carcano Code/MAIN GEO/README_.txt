-In the 'MAIN' folder, the whole code of the thesis.  ---- READ following README inside it. 
-In 'VECCHI + PROVA' folder, some old codes and the GEO DYNAMICS CODES on MATLAB. It also includes the symbolic code used to perform 
 all the needed derivatives of the dynamics. 
-In 'Provided Code' folder, some codes used for the Ephemeris and time conversions (Provided by Prof. Camilla Colombo)   