clearvars; close all; clc;

%% Setup

pert_selector = 3; 

hours = 3600;                                    %Hours to seconds
days = 24*hours;                                 %Days to seconds


ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem)
 

dat.Re = 6378.137/ll; 
dat.mue = 398600*tt^2/ll^3;
dat.muS = astroConstants(4)*tt^2/ll^3; 
dat.muM = astroConstants(20)*tt^2/ll^3;
dat.Rgeo = 42165.8/ll;                             
dat.w = sqrt(dat.mue/(dat.Rgeo)^3);

% values taken from 'vallado' 
grav.c20 = -1.083e-3;  
grav.c21 = -2.414e-10;  
grav.c22 = 1.574e-6;  
grav.c30 = 2.532e-6;  
grav.c31 = 2.191e-6; 
grav.c32 = 3.089e-7;  
grav.c33 = 1.006e-7;  
grav.s21 = 1.543e-9;  
grav.s22 = -9.038e-7;  
grav.s31 = 2.687e-7; 
grav.s32 = -2.115e-7;
grav.s33 = 1.972e-7;

% SRP parameters
SRP.mass = 3000; % kg 
SRP.Surf = 100; % m^2
SRP.Cr = 1.5; 
SRP.S = 1353; % W/m^2
SRP.c = 2.998*1e8; % speed of light

% Set initial FREE-DRIFT (lambda0 = 0) conditions and times
ln = deg2rad(60);                                                          %nominal longitude #degrees
r0 = dat.Rgeo;            r0S = r0;                                        %initial radius (altitude = Rgeo - Re)
eps0 = deg2rad(- 0.04);   eps0S = eps0;                                    %initial longitude error 
phi0 = 0;                 phi0S = phi0;                                    %initial latitude 
v0 = 0;                   v0S = v0; 
csi0 = 0;                 csi0S = csi0; 
n0 = 0;                   n0S = n0; 

% Initial time setup
t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                          % set initial date and convert it in seconds 
 
% GHA reference at initial date
T0 = t0/days/36525; 
G0 = 0; %wrapTo2Pi(deg2rad(100.4606184 + 36000.77004*T0 + 0.000387933*T0^2 -2.583e-8 * T0^3)); % Page 261 orb mech book
dat.G0 = 0;

writematrix(t0, 't0.txt');
writematrix(G0, 'G0.txt');

%% LOAD INITIAL CONTROL FROM PYTHON for each control cycle
L0 = importdata('LAMBDA0_month.txt'); 

%% Propagate every cycle 

time = t0; 

for i = 1 : length(L0)

    y0_FD = [r0, eps0, phi0, v0, csi0, n0, 0, 0, 0, 0, 0, 0];
    y0_FDS = [r0S, eps0S, phi0S, v0S, csi0S, n0S, 0, 0, 0, 0, 0, 0];

    tf1 = time + 2.5*days;                                                 % final free drift time (in seconds) 
    tf2 = tf1 + 0.5*days;                                                  % final control time (in seconds)
    nit = 1000; 
    t_FREEDRIFT = linspace(time, tf1, nit)./tt;
    t_CONTROL = linspace(tf1, tf2, nit)./tt;

    options = odeset('reltol', 1.e-12,'abstol', 1.e-12);
    [t_FD, sph_FD] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_FREEDRIFT, y0_FD, options);
    [~, sph_FDS] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_FREEDRIFT, y0_FDS, options);
    final_FD = sph_FD(end,:)';
    final_FDS = sph_FDS(end,:)';

    y0_C = final_FD;      %Control starts when free drift stops            
    lamda0 = L0(:,i);
    dyn0_C = [y0_C(1:6); lamda0];
    
    % SPHERICAL MOTION -- CONTROL -- PROPAGATION. Spherical equations from t0 to tf:
    [t_C, sph_C] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, dyn0_C, options);
    
    % SHOOTING
    state.initial = final_FDS(1:6);            %end of free drift
    state.final = y0_FDS(1:6)';                %Back to initial free drift state for SK
    
    Dlamda0_Shoot = [0; 0; 0; 0; 0; 0]; 
    lamda0_shooting = Dlamda0_Shoot;
    
    % fsolve options
    options_fsolve = optimoptions(@fsolve,'Maxiter', 1000,'FunctionTolerance', 1e-12, 'StepTolerance',1e-6);
    % fsolve call-- O = output, contains final time and initial conditions for
    % lambda_r, lambda_v
    O = fsolve(@opt_solv, lamda0_shooting, options_fsolve, state, t_CONTROL, dat, grav, SRP, tf1, ln, pert_selector, ll, tt);
    
    dyn0_shoot = [state.initial; O]; 
    
    
    % Propagation to compute state and costate evolution
    [t_S, sph_S] = ode78(@(t,sph)  SPHmotion(t, sph, dat, grav, SRP, tf1, ln, pert_selector, ll, tt), t_CONTROL, dyn0_shoot, options);

    r0S = sph_S(end,1); eps0S = sph_S(end,2); phi0S = sph_S(end,3); v0S = sph_S(end,4); csi0S = sph_S(end,5); n0S = sph_S(end,6);
    r0 = sph_C(end,1); eps0 = sph_C(end,2); phi0 = sph_C(end,3); v0 = sph_C(end,4); csi0 = sph_C(end,5); n0 = sph_C(end,6);
    
    time = tf2;
   
    figure(1)  % Groundtrack
    plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '-k','LineWidth',1)
    hold on
    grid on
    title('Groundtrack');
    xlabel('Longitude [deg]');
    ylabel('Latitude [deg]');
%     plot(rad2deg(sph_FDS(:,2)), rad2deg(sph_FDS(:,3)), '-g','LineWidth',1)
%     plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
    plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
%     plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)),'--m','LineWidth',1)
%     plot(rad2deg(sph_S(1,2)), rad2deg(sph_S(1,3)),'sm','LineWidth', 2); 
%     plot(rad2deg(sph_S(end,2)), rad2deg(sph_S(end,3)),'om','LineWidth',2);
    plot(rad2deg(sph_C(:,2)), rad2deg(sph_C(:,3)),'--b','LineWidth',1)
    plot(rad2deg(sph_C(1,2)), rad2deg(sph_C(1,3)),'sb','LineWidth', 2); 
    plot(rad2deg(sph_C(end,2)), rad2deg(sph_C(end,3)),'ob','LineWidth',2);
    legend('Track', 'End Free drift', 'Controlled track', 'Start control', 'End control', Location='best')

end 

%% FUNCTIONS 

function dsph = SPHmotion(t, dyn, dat, grav, SRP, t0, ln, pert_selector, ll, tt)  
    
    mue = dat.mue; muS = dat.muS; muM = dat.muM;  omega = dat.w;  R = dat.Re;

    m = SRP.mass; A = SRP.Surf; Cr = SRP.Cr; S = SRP.S; c = SRP.c;  G0 = dat.G0;

    c20 = grav.c20;  c21 = grav.c21;  c22 = grav.c22;  c30 = grav.c30;  c31 = grav.c31; 
    c32 = grav.c32;  c33 = grav.c33;  
    s21 = grav.s21;  s22 = grav.s22;  s31 = grav.s31;  s32 = grav.s32;  s33 = grav.s33;

    r = dyn(1);             v = dyn(4); 
    eps = dyn(2);           csi = dyn(5);
    phi = dyn(3);           n = dyn(6);
    l_r = dyn(7);           l_v = dyn(10);
    l_l = dyn(8);           l_csi = dyn(11);
    l_phi = dyn(9);         l_n = dyn(12);
    
    l = ln + eps; 

    % GRAVITY PERTURBING ACCELERATIONS (zonal + tesseral) --- derivatives taken with symbolic 
    aPg_r = -mue*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*r^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5);
 

    aPg_l =  -mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4))/(r*cos(phi));
 
 
    aPg_phi = mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/r^3)/r;


    % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt;             % time in days (Dimensional for ephemeris)
    MJD2000 = tdays;

    ep = deg2rad(23.44);
    ecl = [1 0 0; 0 cos(ep) -sin(ep); 0 sin(ep) cos(ep)];   %rotation ecliptic/equatorial
    [kep, ~] = uplanet(MJD2000, 3);
    [r_E, ~] = kp2rv(kep(1), kep(2), kep(3), kep(4), kep(5), kep(6), muS);
    r_S = - r_E ./ll;
   
    r_S = ecl * r_S;                % SUN position inertial geocentric equatorial frame
    [r_M, ~] = ephMoon(MJD2000);            % MOOn ....
    r_M = r_M ./ll; 
    
    [RAs, Ds] = RaDec(r_S);
    [RAm, Dm] = RaDec(r_M);
    
    omega_dim = omega/tt; 
    RA = l + G0 + omega_dim * (t *tt - t0);

    cosPSIS = sin(phi) * sin(Ds) + cos(phi) * cos(Ds) * cos(RA - RAs);
    cosPSIM = sin(phi) * sin(Dm) + cos(phi) * cos(Dm) * cos(RA - RAm);
    
    rM = norm(r_M);
    rS = norm(r_S);

    a3r   = muS/rS^3 * r *(3*cosPSIS^2 - 1) + ...
            muM/rM^3 * r *(3*cosPSIM^2 - 1);
    a3l   = -3*muS/rS^3 * r * cosPSIS * cos(Ds) * sin(RA - RAs) - ...
            3*muM/rM^3 * r * cosPSIM * cos(Dm) * sin(RA - RAm); 
    a3phi = 3*muS/rS^3 * r * cosPSIS * (cos(phi) * sin(Ds) - sin(phi) * cos(Ds) * cos(RA - RAs)) + ...
            3*muM/rM^3 * r * cosPSIM * (cos(phi) * sin(Dm) - sin(phi) * cos(Dm) * cos(RA - RAm)); 


    % SRP PERTURBATIONS
%     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/m;         % perturbing acceleration F/m  [m/s^2]

    Psr = Psr * 1e-3; % [km/s^2]
    Psr = Psr * tt^2/ll; %adim

    aSRPr   = - Psr * cosPSIS; 
    aSRPl   =   Psr * cos(Ds) * sin(RA - RAs); 
    aSRPphi = - Psr * (sin(Ds) * cos(phi) - cos(Ds) * sin(phi) * cos(RA - RAs));
 
    
    % OVERALL PERTURBING ACCELERATIONS

    switch pert_selector
        case 1
                aP_r   = aPg_r;
                aP_l   = aPg_l;
                aP_phi = aPg_phi;
        case 2
                aP_r   =  a3r;
                aP_l   =  a3l;
                aP_phi = a3phi;
        case 3
                aP_r   = aPg_r + a3r + aSRPr;
                aP_l   = aPg_l + a3l + aSRPl;
                aP_phi = aPg_phi + a3phi + aSRPphi;
    end


    % FINAL DYNAMICS
    dr = v; 
    deps = csi; 
    dphi = n; 
    dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
            aP_r - ...
            l_v; 

    dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
            aP_l/(r * cos(phi)) - ...
            l_csi/(r * cos(phi))^2; 

    dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
            aP_phi/r - ...
            l_n/r^2; 

    dl_r = l_n*(((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r - Psr*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r^2 - (2*l_n)/r^3 + ((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r^2 + (mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4))/r - (3*cosPSIM*muM*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 - (3*cosPSIS*muS*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r - (2*n*v)/r^2) - l_csi*((2*l_csi)/(r^3*cos(phi)^2) + (2*v*(csi + omega))/r^2 + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3)/(r^2*cos(phi)) + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r^2*cos(phi)) + (mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5))/(r*cos(phi)) - (3*cosPSIM*muM*cos(Dm)*sin(RA - RAm))/rM^3 - (3*cosPSIS*muS*cos(Ds)*sin(RA - RAs))/rS^3)/(r*cos(phi))) - l_v*(cos(phi)^2*(csi + omega)^2 + mue*((6*R^2*c20*(3*sin(phi)^2 - 1))/r^5 + (36*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^5 + (300*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^6 + (10*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^6 + (36*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^5 + (300*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^6 + (10*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^6) + (2*mue)/r^3 + n^2 + (muM*(3*cosPSIM^2 - 1))/rM^3 + (muS*(3*cosPSIS^2 - 1))/rS^3);
 
    dl_l = (l_csi*mue*((3*R^2*cos(phi)^2*(4*s22*sin(2*l) + 4*c22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(9*s33*sin(3*l) + 9*c33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(4*s32*sin(2*l) + 4*c32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4)))/(r^2*cos(phi)^2) - (l_n*mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/r^2 - l_v*mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5);
 
    dl_phi = l_n*(cos(phi)^2*(csi + omega)^2 - sin(phi)^2*(csi + omega)^2 + ((mue*((6*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (45*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^4 - (3*R^2*c20*cos(phi)^2)/r^3 - (6*R^2*sin(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 - (30*R^3*sin(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*c20*sin(phi)^2)/r^3 + (5*R^3*c30*sin(phi)^3)/r^4 - (15*R^3*cos(phi)^3*(c31*cos(l) + s31*sin(l)))/r^4 + (R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/(2*r^4) + (12*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (105*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (90*R^3*cos(phi)*sin(phi)^2*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) - (15*R^3*c30*cos(phi)^2*sin(phi))/r^4 + (45*R^3*cos(phi)*sin(phi)^2*(c31*cos(l) + s31*sin(l)))/r^4))/r - Psr*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*sin(phi) + cos(Dm)*cos(RA - RAm)*cos(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)))/rS^3)/r) + l_v*(mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4) + 2*r*cos(phi)*sin(phi)*(csi + omega)^2) - l_csi*(((mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/(r*cos(phi)) - (mue*sin(phi)*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)^2))/(r*cos(phi)) + 2*n*(csi + omega)*(tan(phi)^2 + 1) - (2*l_csi*sin(phi))/(r^2*cos(phi)^3) - (sin(phi)*((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3))/(r*cos(phi)^2));
 
    dl_v = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r;
 
    dl_csi = l_csi*((2*v)/r - 2*n*tan(phi)) - l_l - l_v*r*cos(phi)^2*(2*csi + 2*omega) + l_n*cos(phi)*sin(phi)*(2*csi + 2*omega);

    dl_n = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*tan(phi)*(csi + omega);
 

    % output
    dsph = [dr; deps; dphi; dv; dcsi; dn; dl_r; dl_l; dl_phi; dl_v; dl_csi; dl_n]; 

end


function [RA, dec] = RaDec(cart_pos)
    r = sqrt(cart_pos(1)^2 + cart_pos(2)^2 + cart_pos(3)^2);
    l = cart_pos(1)/r;  m = cart_pos(2)/r; n = cart_pos(3)/r; 
    dec = asin(n); 
    
    if m > 0 
        RA = acos(l/cos(dec)); 
    else 
        RA = 2*pi - acos(l/cos(dec)); 
    end 

end 


function f = opt_solv(l, state, t_CONTROL, dat, grav, SRP, t0, ln, pert_selector, ll, tt)

    xf = state.final; x0 = state.initial; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    initial = [x0; l]; 
    [~, xx] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, initial, options);
    f = [xx(end,1)-xf(1); xx(end,2)-xf(2); xx(end,3)-xf(3);  xx(end,4)-xf(4); xx(end,5)-xf(5); xx(end,6)-xf(6)];

end 