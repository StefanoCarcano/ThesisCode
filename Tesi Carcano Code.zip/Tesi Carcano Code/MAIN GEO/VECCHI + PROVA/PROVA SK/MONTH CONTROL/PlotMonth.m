clearvars; close all; clc;

%% DIMENSIONALIZATION
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem)

% Reference pos and vel 
a0 = ll; 
lon0 = - 0.04; 
lat0 = 0; 
pos0 = [a0; lon0; lat0]; 

v0 = 0; 
dlon0 = 0; 
dlat0 = 0;
vel0 = [v0; dlon0; dlat0]; 

%% LOAD DATA FROM DACE
FD1 = importdata('FD1_month.txt');
FD2 = importdata('FD2_month.txt');
sph_C1 = importdata('ContrState_month1.txt');
sph_C2 = importdata('ContrState_month2.txt');

%% RESHAPE ARRAYS
[n,j] = size(FD1);
N = j/12; 
FD_3D = zeros(n, 12, N);
sphC1_3D = zeros(n, 12, N);

for n = 1 : N
    FD1_3D(:,:,n) = FD1(:, n:N:j); 
    FD2_3D(:,:,n) = FD2(:, n:N:j);
    sphC1_3D(:,:,n) = sph_C1(:, n:N:j);
    sphC2_3D(:,:,n) = sph_C2(:, n:N:j);
end


%% MONTHLY CONTROL PLOT and error
posErr1 = zeros(3, N); velErr1 = zeros(3, N); posErr2 = zeros(3, N); velErr2 = zeros(3, N); 

for i = 1 : N

    pos1 = [sphC1_3D(end, 1, i)*ll; rad2deg(sphC1_3D(end, 2, i)); rad2deg(sphC1_3D(end, 3, i))];
    vel1 = [sphC1_3D(end, 4, i)*ll/tt; rad2deg(sphC1_3D(end, 5, i)/tt); rad2deg(sphC1_3D(end, 6, i)/tt)];  
    pos2 = [sphC2_3D(end, 1, i)*ll; rad2deg(sphC2_3D(end, 2, i)); rad2deg(sphC2_3D(end, 3, i))];
    vel2 = [sphC2_3D(end, 4, i)*ll/tt; rad2deg(sphC2_3D(end, 5, i)/tt); rad2deg(sphC2_3D(end, 6, i)/tt)]; 

    posErr1(:,i) = abs(pos1 - pos0); 
    velErr1(:,i) = abs(vel1 - vel0);
    posErr2(:,i) = abs(pos2 - pos0); 
    velErr2(:,i) = abs(vel2 - vel0); 

    figure(1)  % Groundtrack
    plot(rad2deg(FD2_3D(:,2,i)), rad2deg(FD2_3D(:,3,i)), '--k','LineWidth',1)
    hold on
    grid on
    title('Groundtrack');
    xlabel('Longitude [deg]');
    ylabel('Latitude [deg]');
%     plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
    plot(rad2deg(FD2_3D(end,2,i)), rad2deg(FD2_3D(end,3,i)),'sk','LineWidth',2);
    plot(rad2deg(sphC2_3D(:,2,i)), rad2deg(sphC2_3D(:,3,i)),'-r','LineWidth',1)
    plot(rad2deg(sphC2_3D(1,2,i)), rad2deg(sphC2_3D(1,3,i)),'sr','LineWidth', 2); 
    plot(rad2deg(sphC1_3D(end,2,i)), rad2deg(sphC1_3D(end,3,i)),'ob','LineWidth',2);
    plot(rad2deg(sphC2_3D(end,2,i)), rad2deg(sphC2_3D(end,3,i)),'or','LineWidth',2);
    legend('Track', 'End Free drift', 'Controlled track 2nd order', 'Start control', 'End control 1st order', 'End control 2nd order', Location='best')

end 


% Plot Error 
x = [1:1:N]; 

figure()
subplot(3,1,1)
plot(x, posErr1(1,:), '.-r') 
hold on
plot(x, posErr2(1,:), '.-k')
xlabel('Control Cycle')
ylabel('Semi-major axis error [km]')
grid minor
legend('1st order error', '2nd order error')
title('Position Error on target point')

subplot(3,1,2)
plot(x, posErr1(2,:), '.-r') 
hold on
plot(x, posErr2(2,:), '.-k')
xlabel('Control Cycle')
ylabel('Longitude error [deg]')
grid minor
legend('1st order error', '2nd order error')

subplot(3,1,3)
plot(x, posErr1(3,:), '.-r') 
hold on
plot(x, posErr2(3,:), '.-k')
xlabel('Control Cycle')
ylabel('Latitude error [deg]')
grid minor
legend('1st order error', '2nd order error')

figure()
subplot(3,1,1)
plot(x, velErr1(1,:), '.-r') 
hold on
plot(x, velErr2(1,:), '.-k')
xlabel('Control Cycle')
ylabel('Radial vel error [km/s]')
grid minor
legend('1st order error', '2nd order error')
title('Velocity error on target point')

subplot(3,1,2)
plot(x, velErr1(2,:), '.-r') 
hold on
plot(x, velErr2(2,:), '.-k')
xlabel('Control Cycle')
ylabel('Longitude drift error [deg/s]')
grid minor
legend('1st order error', '2nd order error')

subplot(3,1,3)
plot(x, velErr1(3,:), '.-r') 
hold on
plot(x, velErr2(3,:), '.-k')
xlabel('Control Cycle')
ylabel('Latitude drift error [deg/s]')
grid minor
legend('1st order error', '2nd order error')




