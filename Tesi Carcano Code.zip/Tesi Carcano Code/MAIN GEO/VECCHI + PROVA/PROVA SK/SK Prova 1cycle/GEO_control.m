clearvars; close all; clc;


% SPHERICAL MOTION WITH PERTURBATIONS in GEO. (GG up to order 3,3; MOON + SUN third body; SRP) ----
% set 'pert_selector' 
% = 1 if only GG is wanted
% = 2 if third bodies
% = 3 every perturbation

% FREE DRIFT + CONTROLLED MOTION  

%% SETUP

pert_selector = 3; 

hours = 3600;                                    %Hours to seconds
days = 24*hours;                                 %Days to seconds


ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem)
 

dat.Re = 6378.137/ll; 
dat.mue = 398600*tt^2/ll^3;
dat.muS = astroConstants(4)*tt^2/ll^3; 
dat.muM = astroConstants(20)*tt^2/ll^3;
dat.Rgeo = 42165.8/ll;                             
dat.w = sqrt(dat.mue/(dat.Rgeo)^3);

% values taken from 'vallado' 
grav.c20 = -1.083e-3;  
grav.c21 = -2.414e-10;  
grav.c22 = 1.574e-6;  
grav.c30 = 2.532e-6;  
grav.c31 = 2.191e-6; 
grav.c32 = 3.089e-7;  
grav.c33 = 1.006e-7;  
grav.s21 = 1.543e-9;  
grav.s22 = -9.038e-7;  
grav.s31 = 2.687e-7; 
grav.s32 = -2.115e-7;
grav.s33 = 1.972e-7;

% SRP parameters
SRP.mass = 3000; % kg 
SRP.Surf = 100; % m^2
SRP.Cr = 1.5; 
SRP.S = 1353; % W/m^2
SRP.c = 2.998*1e8; % speed of light

% Set initial FREE-DRIFT (lambda0 = 0) conditions and times
ln = deg2rad(60);                                                          %nominal longitude #degrees
r0 = dat.Rgeo;                                                             %initial radius (altitude = Rgeo - Re)
eps0 = deg2rad(- 0.04);                                                      %initial longitude error 
phi0 = 0;                                                                  %initial latitude 

y0_FD = [r0, eps0, phi0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
% y0_FD = [1.0000184589362, 1.04790223754487 - deg2rad(60), 0.000420971550052822, 2.62809814245108e-10, 9.16621217010764e-10, -1.55826082923389e-09, 0, 0, 0, 0, 0, 0]; 


t0 = date2mjd2000([2010, 07, 21, 12, 0, 0])*days;                          % set initial date and convert it in seconds
tfd = 2.5; tc = 0.5; 
tf1 = t0 + tfd*days;                                                         % final free drift time (in seconds) 
tf2 = tf1 + tc*days;                                                        % final control time (in seconds)
nit = 10000; 
t_FREEDRIFT = linspace(t0, tf1, nit)./tt;
t_CONTROL = linspace(tf1, tf2, nit)./tt; 

% GHA reference at initial date
T0 = t0/days/36525; 
G0 = 0; %wrapTo2Pi(deg2rad(100.4606184 + 36000.77004*T0 + 0.000387933*T0^2 -2.583e-8 * T0^3)); % Page 261 orb mech book
dat.G0 = 0;

% writematrix(t0, 't0.txt');
% writematrix(G0, 'G0.txt');

%% SPHERICAL MOTION -- FREE DRIFT 

% Use ODE113 to integrate spherical equations from t0 to tf:

options = odeset('reltol', 1.e-12,'abstol', 1.e-12);
[t_FD, sph_FD] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_FREEDRIFT, y0_FD, options);

% Save txt file for python DA initial condition 
final_FD = sph_FD(end,:)';

% writematrix(final_FD, 'fin_FREEDRIFT.txt'); 


%% COMPUTE SPHERICAL COSTATE DYNAMICS WITH SYMBOLIC FOR CONTROL
% [cost_dyn] = costate; 

%% COMPUTE STATE TRANSITION MATRIX
 [STM] = stm;

%% SPHERICAL MOTION -- CONTROL -- SETUP conditions  

% Set initial control conditions----State and Costate 

y0_C = final_FD;      %Control starts when free drift stops            
lamda0_ref = zeros(6,1); 

% Load results from DACE (Depend on expansion order!!!)
Dlamda0GG = importdata('LAMBDA0_GG.txt');  
Dlamda0_1tot = importdata('LAMBDA0_1tot.txt');
Dlamda0_1 = importdata('LAMBDA0_1.txt');
Dlamda0_4 = importdata('LAMBDA0_4.txt');

lamda0_1 = lamda0_ref + Dlamda0_1;
lamda0_4 = lamda0_ref + Dlamda0_4;
lamda0_GG = Dlamda0GG; 
lamda0_tot =  Dlamda0_1tot + Dlamda0GG ;  %(4th order GG + linear solution of complete dynamics)


dyn0_1 = [y0_C(1:6); lamda0_1];
dyn0_4 = [y0_C(1:6); lamda0_4];
dyn0_tot = [y0_C(1:6); lamda0_tot];
dyn0_GG = [y0_C(1:6); lamda0_GG];

% SPHERICAL MOTION -- CONTROL -- PROPAGATION. Spherical equations from t0 to tf:

options = odeset('reltol', 1.e-12,'abstol', 1.e-12);
[t_C, sph_C1] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, dyn0_1, options);
[~, sph_C4] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, dyn0_4, options);
[~, sph_Ctot] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, dyn0_tot, options);
[~, sph_CGG] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, dyn0_GG, options);

% writematrix(sph_C(end,:)', 'fin_CONTROL.txt');   

%% SPHERICAL MOTION -- CONTROL -- SHOOTING

state.initial = final_FD(1:6);            %end of free drift
state.final = y0_FD(1:6)';                %Back to initial free drift state for SK

% state.final = [1.00000655155540, 1.04771710100631 - deg2rad(60), 8.46686429003600e-05, -1.84382736909935e-09, -1.08640821256623e-10, 7.69016832256055e-09];

% state.final = [1.00000661399110, 1.04778962280554 - deg2rad(60), 5.97191387012606e-05, 4.03833055421970e-12, 4.82772371814381e-11, -8.70631152799971e-11];



Dlamda0_Shoot = [0; 0; 0; 0; 0; 0]; 
lamda0_shooting = lamda0_ref + Dlamda0_Shoot;

% fsolve options
options_fsolve = optimoptions(@fsolve, 'Display', 'iter','Maxiter', 1000,'FunctionTolerance', 1e-12, 'StepTolerance',1e-6);
% fsolve call-- O = output, contains final time and initial conditions for
% lambda_r, lambda_v
O = fsolve(@opt_solv, lamda0_shooting, options_fsolve, state, t_CONTROL, dat, grav, SRP, t0, ln, pert_selector, ll, tt);

dyn0_shoot = [state.initial; O]; 


% Propagation to compute state and costate evolution
[t_S, sph_S] = ode78(@(t,sph)  SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, dyn0_shoot, options);


u_rS = - sph_S(:, 10) * ll/tt^2 ;
                
for q = 1 : 10000
    u_lS(q) = - sph_S(q, 11) /tt^2 * (sph_S(q, 1)*ll * cos(sph_S(q, 3))) ;
    u_phiS(q) = - sph_S(q, 12) /tt^2 * (sph_S(q, 1)*ll);
end

% compute performance index 
u = [u_rS, u_lS', u_phiS']*1e3;    % control acceleration m/s^2 
U = vecnorm(u,2,2);
U = sort(U); 
t_int = linspace(0, tc*days, 10000);
u_integral = trapz(U, t_int);
Dv = u_integral                    % m/s

%% PLOT SPHERICAL free drift + control

% figure()
% 
% subplot(3,1,1)
% plot((t_FD - t0)*tt/24/3600, sph_FD(:, 1)*ll)
% title('Distance')
% xlabel('Days')
% grid on
% grid minor
% axis tight
% 
% subplot(3,1,2)
% plot((t_FD - t0)*tt/24/3600, ((rad2deg(sph_FD(:, 2)))))
% title('Longitude error')
% xlabel('Days')
% grid on
% grid minor
% axis tight
% 
% subplot(3,1,3)
% plot((t_FD - t0)*tt/24/3600, rad2deg(sph_FD(:, 3)))
% title('Latitude')
% xlabel('Days')
% grid on
% grid minor
% axis tight

switch pert_selector
    case 1
        figure()  % Groundtrack
        plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k','LineWidth',1)
        hold on
        grid on
        title('Groundtrack');
        xlabel('Longitude [deg]');
        ylabel('Latitude [deg]');
        plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
        plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
        
        plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-r','LineWidth',1)
        plot(rad2deg(sph_CGG(:,2)), rad2deg(sph_CGG(:,3)), '-c','LineWidth',1)
        plot(rad2deg(sph_CGG(1,2)), rad2deg(sph_CGG(1,3)),'sm','LineWidth', 2); 
        plot(rad2deg(sph_CGG(end,2)), rad2deg(sph_CGG(end,3)),'om','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift','Exact solution shooting', '4th order GG solution', 'Start control', 'End control', Location='best')

 
        figure()
        plot((sph_FD(:,1))*ll, (sph_FD(:,4))*ll/tt, '-.k','LineWidth',1)
        hold on
        grid on
        title('Radius and radial vel');
        xlabel('Semi major axis [km]');
        ylabel('Radial velocity [km/s]');
        plot((sph_FD(1,1))*ll, (sph_FD(1,4))*ll/tt,'ok','LineWidth',1.5); 
        plot((sph_FD(end,1))*ll, (sph_FD(end,4))*ll/tt,'sk','LineWidth',2);
        plot((sph_CGG(:,1))*ll, (sph_CGG(:,4))*ll/tt, '-c','LineWidth',1)
        plot((sph_CGG(1,1))*ll, (sph_CGG(1,4))*ll/tt,'sg','LineWidth', 2); 
        plot((sph_CGG(end,1))*ll, (sph_CGG(end,4))*ll/tt,'og','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift', '4th order GG solution', 'Start control', 'End control', Location='best')
        
 case 3
        figure()  % Groundtrack
        plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k','LineWidth',1)
        hold on
        grid on
        title('Groundtrack');
        xlabel('Longitude [deg]');
        ylabel('Latitude [deg]');
        plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
        plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
        
        plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-r','LineWidth',1)
        plot(rad2deg(sph_C1(:,2)), rad2deg(sph_C1(:,3)), '-b','LineWidth',1)
        plot(rad2deg(sph_C4(:,2)), rad2deg(sph_C4(:,3)), '-m','LineWidth',1)
        plot(rad2deg(sph_CGG(:,2)), rad2deg(sph_CGG(:,3)), '-c','LineWidth',1)
        plot(rad2deg(sph_Ctot(:,2)), rad2deg(sph_Ctot(:,3)), '-g','LineWidth',1)
        plot(rad2deg(sph_C4(1,2)), rad2deg(sph_C4(1,3)),'sm','LineWidth', 2); 
        plot(rad2deg(sph_C4(end,2)), rad2deg(sph_C4(end,3)),'om','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift','Exact solution shooting', 'Linear Control', '4th order', '4th order GG + linear a_{3} + a_{srp}', 'Start control', 'End control', Location='best')

        figure()  
        plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '-.k','LineWidth',1)
        hold on
        grid on
        title('Groundtrack');
        xlabel('Longitude [deg]');
        ylabel('Latitude [deg]');
        plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
        plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
        plot(rad2deg(sph_CGG(:,2)), rad2deg(sph_CGG(:,3)), '-c','LineWidth',1)
        plot(rad2deg(sph_Ctot(:,2)), rad2deg(sph_Ctot(:,3)), '-g','LineWidth',1)
        plot(rad2deg(sph_Ctot(1,2)), rad2deg(sph_Ctot(1,3)),'sg','LineWidth', 2); 
        plot(rad2deg(sph_Ctot(end,2)), rad2deg(sph_Ctot(end,3)),'og','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift', 'GG solution', '4th order GG + linear a_{3} + a_{srp}', 'Start control', 'End control', Location='best')
        
        figure()
        plot((sph_FD(:,1))*ll, (sph_FD(:,4))*ll/tt, '-.k','LineWidth',1)
        hold on
        grid on
        title('Radius and radial vel');
        xlabel('Semi major axis [km]');
        ylabel('Radial velocity [km/s]');
        plot((sph_FD(1,1))*ll, (sph_FD(1,4))*ll/tt,'ok','LineWidth',1.5); 
        plot((sph_FD(end,1))*ll, (sph_FD(end,4))*ll/tt,'sk','LineWidth',2);
        plot((sph_CGG(:,1))*ll, (sph_CGG(:,4))*ll/tt, '-c','LineWidth',1)
        plot((sph_Ctot(:,1))*ll, (sph_Ctot(:,4))*ll/tt, '-g','LineWidth',1)
        plot((sph_Ctot(1,1))*ll, (sph_Ctot(1,4))*ll/tt,'sg','LineWidth', 2); 
        plot((sph_Ctot(end,1))*ll, (sph_Ctot(end,4))*ll/tt,'og','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift', 'GG solution', '4th order GG + linear a_{3} + a_{srp}', 'Start control', 'End control', Location='best')
        
        figure()
        plot((sph_FD(:,1))*ll, (sph_FD(:,4))*ll/tt, '-.k','LineWidth',1)
        hold on
        grid on
        title('Radius and radial vel');
        xlabel('Semi major axis [km]');
        ylabel('Radial velocity [km/s]');
        plot((sph_FD(1,1))*ll, (sph_FD(1,4))*ll/tt,'ok','LineWidth',1.5); 
        plot((sph_FD(end,1))*ll, (sph_FD(end,4))*ll/tt,'sk','LineWidth',2);
        plot((sph_C1(:,1))*ll, (sph_C1(:,4))*ll/tt, '-b','LineWidth',1)
        plot((sph_C4(:,1))*ll, (sph_C4(:,4))*ll/tt, '-m','LineWidth',1)
        plot((sph_C4(1,1))*ll, (sph_C4(1,4))*ll/tt,'sm','LineWidth', 2); 
        plot((sph_C4(end,1))*ll, (sph_C4(end,4))*ll/tt,'om','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift', 'Linear control', '4th order', 'Start control', 'End control', Location='best')
        
        figure()
        plot(rad2deg(sph_FD(:,3)), rad2deg(sph_FD(:,6))/tt, '-.k','LineWidth',1)
        hold on
        grid on
        title('Lat and lat vel');
        xlabel('\phi [deg]');
        ylabel('n [deg/s]');
        plot(rad2deg(sph_FD(1,3)), rad2deg(sph_FD(1,6))/tt,'ok','LineWidth',1.5); 
        plot(rad2deg(sph_FD(end,3)), rad2deg(sph_FD(end,6))/tt,'sk','LineWidth',2);
        plot(rad2deg(sph_S(:,3)), rad2deg(sph_S(:,6))/tt, '-g','LineWidth',1)
        plot(rad2deg(sph_C1(:,3)), rad2deg(sph_C1(:,6))/tt, '-b','LineWidth',1)
        plot(rad2deg(sph_C4(:,3)), rad2deg(sph_C4(:,6))/tt, '-m','LineWidth',1)
        plot(rad2deg(sph_C4(1,3)), rad2deg(sph_C4(1,6))/tt,'sm','LineWidth', 2); 
        plot(rad2deg(sph_C4(end,3)), rad2deg(sph_C4(end,6))/tt,'om','LineWidth',2);
        legend('Track', 'Start Free drift', 'End Free drift', 'Exact solution','Linear control', '4th order', 'Start control', 'End control', Location='best')
end

%% SHOOTING PLOT

figure()  % Groundtrack
plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '-.k','LineWidth',2)
hold on
grid on
title('Groundtrack Shooting -- Exact solution');
xlabel('Longitude [deg]');
ylabel('Latitude [deg]');
plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'om','LineWidth',1.5); 
plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'ob','LineWidth',2);

plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-g','LineWidth',1.5)
plot(rad2deg(sph_S(1,2)), rad2deg(sph_S(1,3)),'og','LineWidth', 2); 
plot(rad2deg(sph_S(end,2)), rad2deg(sph_S(end,3)),'ok','LineWidth',2);
plot(rad2deg(state.final(2)), rad2deg(state.final(3)), '*r','MarkerSize',2)
legend('Track', 'Start Free drift', 'End Free drift', 'Controlled track', 'Start control', 'End control', Location='best')

% Control evolution  
%  [ll_c/tt_c^3; ll_c^2/tt_c^3; ll_c^2/tt_c^3;
%      ll_c/tt_c^2; ll_c^2/tt_c^2; ll_c^2/tt_c^2];

ur = - sph_S(:,10) * ll_c/tt_c^2 ; 

for i = 1 : length(t_S)
    ul(i) = - sph_S(i,11) * ll_c/tt_c^2 / (sph_S(i,1) * cos(sph_S(i,3))) ;
    uphi(i) = - sph_S(i,12) * ll_c/tt_c^2 / sph_S(i,1);
end



% Control error
urDA4 = - sph_C4(:,10) * ll_c/tt_c^2;
urDA1 = - sph_C1(:,10) * ll_c/tt_c^2; 
urDAtot = - sph_Ctot(:,10) * ll_c/tt_c^2; 

for i = 1 : length(t_C)
    ulDA4(i) = - sph_C4(i,11) * ll_c/tt_c^2/ (sph_C4(i,1) * cos(sph_C4(i,3)));
    uphiDA4(i) = - sph_C4(i,12) * ll_c/tt_c^2/ sph_C4(i,1);

    ulDA1(i) = - sph_C1(i,11) * ll_c/tt_c^2/ (sph_C1(i,1) * cos(sph_C1(i,3)));
    uphiDA1(i) = - sph_C1(i,12) * ll_c/tt_c^2/ sph_C1(i,1);

    ulDAtot(i) = - sph_Ctot(i,11)* ll_c/tt_c^2 / (sph_Ctot(i,1) * cos(sph_Ctot(i,3)));
    uphiDAtot(i) = - sph_Ctot(i,12)* ll_c/tt_c^2 / sph_Ctot(i,1);

    u_exact(i) = sqrt(ur(i)^2 + ul(i)^2 + uphi(i)^2); 
    u_DA4(i) = sqrt(urDA4(i)^2 + ulDA4(i)^2 + uphiDA4(i)^2); 
    u_DA1(i) = sqrt(urDA1(i)^2 + ulDA1(i)^2 + uphiDA1(i)^2); 
    u_DAtot(i) = sqrt(urDAtot(i)^2 + ulDAtot(i)^2 + uphiDAtot(i)^2);

    velC1(i) = abs(norm((sph_C1(i, 4:6).*[ll/tt; 1/tt; 1/tt])) - (norm(sph_S(i,4:6).*[ll/tt; 1/tt; 1/tt]))); 
    velC4(i) = abs(norm((sph_C4(i, 4:6).*[ll/tt; 1/tt; 1/tt])) - (norm(sph_S(i,4:6).*[ll/tt; 1/tt; 1/tt]))); 
    velCtot(i) = abs(norm((sph_Ctot(i, 4:6).*[ll/tt; 1/tt; 1/tt])) - (norm(sph_S(i,4:6).*[ll/tt; 1/tt; 1/tt]))); 
end

figure()   
plot((t_S.*tt - t0)/24/3600, ur, 'g')
hold on
plot((t_S.*tt - t0)/24/3600, ul, '--g')
plot((t_S.*tt - t0)/24/3600, uphi, '-.g')
plot((t_S.*tt - t0)/24/3600, urDA4, 'k')
plot((t_S.*tt - t0)/24/3600, ulDA4, '--k')
plot((t_S.*tt - t0)/24/3600, uphiDA4, '-.k')
legend('u_{r}', 'u_{l}', 'u_{\phi}', 'u_{rDA4}', 'u_{lDA4}', 'u_{\phiDA4}', Location='best')
xlabel('Days')
% ylabel('m/s^{2}')
grid minor
title('Exact control vs 4th order control')

figure()
plot((t_S.*tt - t0)/24/3600, abs(u_exact - u_DA1), '-b', 'LineWidth', 1)
hold on
plot((t_S.*tt - t0)/24/3600, abs(u_exact - u_DA4), '-m', 'LineWidth', 1)
plot((t_S.*tt - t0)/24/3600, abs(u_exact - u_DAtot), '-g', 'LineWidth', 1)
legend('Linear control', '4th order control', '4th order GG + linear a_{3} + a_{srp}', Location='best')
xlabel('Days')
ylabel('||u_{exact} - u_{DA}||')
title('Control error')
grid on 

figure()
plot((t_S.*tt - t0)/24/3600, velC1, '-b', 'LineWidth', 1)
hold on
plot((t_S.*tt - t0)/24/3600, velC4, '-m', 'LineWidth', 1)
plot((t_S.*tt - t0)/24/3600, velCtot, '-g', 'LineWidth', 1)
legend('Linear control', '4th order control', '4th order GG + linear a_{3} + a_{srp}', Location='best')
xlabel('Days')
ylabel('||vel_{exact} - vel_{DA}||')
title('Velocity error')
grid on 



%% FUNCTIONS 


function dsph = SPHmotion(t, dyn, dat, grav, SRP, t0, ln, pert_selector, ll, tt)  
    
    mue = dat.mue; muS = dat.muS; muM = dat.muM;  omega = dat.w;  R = dat.Re;

    m = SRP.mass; A = SRP.Surf; Cr = SRP.Cr; S = SRP.S; c = SRP.c;  G0 = dat.G0;

    c20 = grav.c20;  c21 = grav.c21;  c22 = grav.c22;  c30 = grav.c30;  c31 = grav.c31; 
    c32 = grav.c32;  c33 = grav.c33;  
    s21 = grav.s21;  s22 = grav.s22;  s31 = grav.s31;  s32 = grav.s32;  s33 = grav.s33;

    r = dyn(1);             v = dyn(4); 
    eps = dyn(2);           csi = dyn(5);
    phi = dyn(3);           n = dyn(6);
    l_r = dyn(7);           l_v = dyn(10);
    l_l = dyn(8);           l_csi = dyn(11);
    l_phi = dyn(9);         l_n = dyn(12);
    
    l = ln + eps; 

    % GRAVITY PERTURBING ACCELERATIONS (zonal + tesseral) --- derivatives taken with symbolic 
    aPg_r = -mue*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*r^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5);
 

    aPg_l =  -mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4))/(r*cos(phi));
 
 
    aPg_phi = mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/r^3)/r;


    % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600 *tt;             % time in days (Dimensional for ephemeris)
    MJD2000 = tdays;

    ep = deg2rad(23.44);
    ecl = [1 0 0; 0 cos(ep) -sin(ep); 0 sin(ep) cos(ep)];   %rotation ecliptic/equatorial
    [kep, ~] = uplanet(MJD2000, 3);
    [r_E, ~] = kp2rv(kep(1), kep(2), kep(3), kep(4), kep(5), kep(6), muS);
    r_S = - r_E ./ll;
   
    r_S = ecl * r_S;                % SUN position inertial geocentric equatorial frame
    [r_M, ~] = ephMoon(MJD2000);            % MOOn ....
    r_M = r_M ./ll; 
    
    [RAs, Ds] = RaDec(r_S);
    [RAm, Dm] = RaDec(r_M);
    
    omega_dim = omega/tt; 
    RA = l + G0 + omega_dim * (t *tt - t0);

    cosPSIS = sin(phi) * sin(Ds) + cos(phi) * cos(Ds) * cos(RA - RAs);
    cosPSIM = sin(phi) * sin(Dm) + cos(phi) * cos(Dm) * cos(RA - RAm);
    
    rM = norm(r_M);
    rS = norm(r_S);

    a3r   = muS/rS^3 * r *(3*cosPSIS^2 - 1) + ...
            muM/rM^3 * r *(3*cosPSIM^2 - 1);
    a3l   = -3*muS/rS^3 * r * cosPSIS * cos(Ds) * sin(RA - RAs) - ...
            3*muM/rM^3 * r * cosPSIM * cos(Dm) * sin(RA - RAm); 
    a3phi = 3*muS/rS^3 * r * cosPSIS * (cos(phi) * sin(Ds) - sin(phi) * cos(Ds) * cos(RA - RAs)) + ...
            3*muM/rM^3 * r * cosPSIM * (cos(phi) * sin(Dm) - sin(phi) * cos(Dm) * cos(RA - RAm)); 


    % SRP PERTURBATIONS
%     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/m;         % perturbing acceleration F/m  [m/s^2]

    Psr = Psr * 1e-3; % [km/s^2]
    Psr = Psr * tt^2/ll; %adim

    aSRPr   = - Psr * cosPSIS; 
    aSRPl   =   Psr * cos(Ds) * sin(RA - RAs); 
    aSRPphi = - Psr * (sin(Ds) * cos(phi) - cos(Ds) * sin(phi) * cos(RA - RAs));
 
    
    % OVERALL PERTURBING ACCELERATIONS

    switch pert_selector
        case 1
                aP_r   = aPg_r;
                aP_l   = aPg_l;
                aP_phi = aPg_phi;
        case 2
                aP_r   =  a3r;
                aP_l   =  a3l;
                aP_phi = a3phi;
        case 3
                aP_r   = aPg_r + a3r + aSRPr;
                aP_l   = aPg_l + a3l + aSRPl;
                aP_phi = aPg_phi + a3phi + aSRPphi;
    end


    % FINAL DYNAMICS
    dr = v; 
    deps = csi; 
    dphi = n; 
    dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
            aP_r - ...
            l_v; 

    dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
            aP_l/(r * cos(phi)) - ...
            l_csi/(r * cos(phi))^2; 

    dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
            aP_phi/r - ...
            l_n/r^2; 

    dl_r = l_n*(((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r - Psr*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r^2 - (2*l_n)/r^3 + ((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r^2 + (mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4))/r - (3*cosPSIM*muM*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 - (3*cosPSIS*muS*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r - (2*n*v)/r^2) - l_csi*((2*l_csi)/(r^3*cos(phi)^2) + (2*v*(csi + omega))/r^2 + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3)/(r^2*cos(phi)) + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r^2*cos(phi)) + (mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5))/(r*cos(phi)) - (3*cosPSIM*muM*cos(Dm)*sin(RA - RAm))/rM^3 - (3*cosPSIS*muS*cos(Ds)*sin(RA - RAs))/rS^3)/(r*cos(phi))) - l_v*(cos(phi)^2*(csi + omega)^2 + mue*((6*R^2*c20*(3*sin(phi)^2 - 1))/r^5 + (36*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^5 + (300*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^6 + (10*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^6 + (36*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^5 + (300*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^6 + (10*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^6) + (2*mue)/r^3 + n^2 + (muM*(3*cosPSIM^2 - 1))/rM^3 + (muS*(3*cosPSIS^2 - 1))/rS^3);
 
    dl_l = (l_csi*mue*((3*R^2*cos(phi)^2*(4*s22*sin(2*l) + 4*c22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(9*s33*sin(3*l) + 9*c33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(4*s32*sin(2*l) + 4*c32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4)))/(r^2*cos(phi)^2) - (l_n*mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/r^2 - l_v*mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5);
 
    dl_phi = l_n*(cos(phi)^2*(csi + omega)^2 - sin(phi)^2*(csi + omega)^2 + ((mue*((6*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (45*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^4 - (3*R^2*c20*cos(phi)^2)/r^3 - (6*R^2*sin(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 - (30*R^3*sin(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*c20*sin(phi)^2)/r^3 + (5*R^3*c30*sin(phi)^3)/r^4 - (15*R^3*cos(phi)^3*(c31*cos(l) + s31*sin(l)))/r^4 + (R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/(2*r^4) + (12*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (105*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (90*R^3*cos(phi)*sin(phi)^2*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) - (15*R^3*c30*cos(phi)^2*sin(phi))/r^4 + (45*R^3*cos(phi)*sin(phi)^2*(c31*cos(l) + s31*sin(l)))/r^4))/r - Psr*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*sin(phi) + cos(Dm)*cos(RA - RAm)*cos(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)))/rS^3)/r) + l_v*(mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4) + 2*r*cos(phi)*sin(phi)*(csi + omega)^2) - l_csi*(((mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/(r*cos(phi)) - (mue*sin(phi)*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)^2))/(r*cos(phi)) + 2*n*(csi + omega)*(tan(phi)^2 + 1) - (2*l_csi*sin(phi))/(r^2*cos(phi)^3) - (sin(phi)*((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3))/(r*cos(phi)^2));
 
    dl_v = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r;
 
    dl_csi = l_csi*((2*v)/r - 2*n*tan(phi)) - l_l - l_v*r*cos(phi)^2*(2*csi + 2*omega) + l_n*cos(phi)*sin(phi)*(2*csi + 2*omega);

    dl_n = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*tan(phi)*(csi + omega);
 

    % output
    dsph = [dr; deps; dphi; dv; dcsi; dn; dl_r; dl_l; dl_phi; dl_v; dl_csi; dl_n]; 

end



function [cost_dyn] = costate 

    % Compute costate dynamics
    syms r l phi v csi n mue R omega l_r l_l l_phi l_v l_csi l_n c20 c21 c22 s33 c30 c31 c32 c33 s21 s22 s31 s32 s33...
         rS rM cosPSIS cosPSIM Ds Dm RA RAs RAm muS muM Psr c1 LV u m
    
    aP_r = -mue*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*r^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5) +...
            muS/rS^3 * r *(3*cosPSIS^2 - 1) + ...
            muM/rM^3 * r *(3*cosPSIM^2 - 1) + ...
            - Psr * cosPSIS;
    
    
    
    
    aP_l =  -mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)) /(r * cos(phi)) +...
             -3*muS/rS^3 * r * cosPSIS * cos(Ds) * sin(RA - RAs) - ...
              3*muM/rM^3 * r * cosPSIM * cos(Dm) * sin(RA - RAm) + ...
              Psr * cos(Ds) * sin(RA - RAs);
    
    
    
    aP_phi = mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/r^3) /r + ...
              3*muS/rS^3 * r * cosPSIS * (cos(phi) * sin(Ds) - sin(phi) * cos(Ds) * cos(RA - RAs)) + ...
              3*muM/rM^3 * r * cosPSIM * (cos(phi) * sin(Dm) - sin(phi) * cos(Dm) * cos(RA - RAm)) + ...
              - Psr * (sin(Ds) * cos(phi) - cos(Ds) * sin(phi) * cos(RA - RAs));
              
    
    
    % EOP
    dr = v; 
    dl = csi; 
    dphi = n; 
    
    dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
            aP_r - ...
            l_v;
    
    dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
            aP_l/(r * cos(phi)) - ...
            l_csi/(r * cos(phi))^2;
    
    dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
            aP_phi/r -...
            l_n/r^2;
    
    
    % FOP
%     dr = v; 
%     dl = csi; 
%     dphi = n; 
%     
%     dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
%             aP_r - ...
%             c1 * u/m * l_v/LV;
%     
%     dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
%             aP_l/(r * cos(phi)) - ...
%             1/(r * cos(phi))^2 * c1 * u/m * l_csi/LV;
%     
%     dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
%             aP_phi/r -...
%             1/r^2 * c1 * u/m * l_n/LV;
% 
% 
% 
    DfDx = jacobian([dr; dl; dphi; dv; dcsi; dn], [r, l, phi, v, csi, n]); 
    
    cost_dyn = - DfDx.' * [l_r; l_l; l_phi; l_v; l_csi; l_n];
    
end


function [STM] = stm 

    % Compute costate dynamics
    syms r l phi v csi n mue R omega l_r l_l l_phi l_v l_csi l_n c20 c21 c22 s33 c30 c31 c32 c33 s21 s22 s31 s32 s33...
         rS rM cosPSIS cosPSIM Ds Dm RA RAs RAm muS muM Psr c1 LV u m
    
    aP_r = -mue*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*r^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5) +...
            muS/rS^3 * r *(3*cosPSIS^2 - 1) + ...
            muM/rM^3 * r *(3*cosPSIM^2 - 1) + ...
            - Psr * cosPSIS;
    
    
    
    
    aP_l =  -mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)) /(r * cos(phi)) +...
             -3*muS/rS^3 * r * cosPSIS * cos(Ds) * sin(RA - RAs) - ...
              3*muM/rM^3 * r * cosPSIM * cos(Dm) * sin(RA - RAm) + ...
              Psr * cos(Ds) * sin(RA - RAs);
    
    
    
    aP_phi = mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/r^3) /r + ...
              3*muS/rS^3 * r * cosPSIS * (cos(phi) * sin(Ds) - sin(phi) * cos(Ds) * cos(RA - RAs)) + ...
              3*muM/rM^3 * r * cosPSIM * (cos(phi) * sin(Dm) - sin(phi) * cos(Dm) * cos(RA - RAm)) + ...
              - Psr * (sin(Ds) * cos(phi) - cos(Ds) * sin(phi) * cos(RA - RAs));
              
    
    
    % EOP
    dr = v; 
    dl = csi; 
    dphi = n; 
    
    dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
            aP_r - ...
            l_v;
    
    dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
            aP_l/(r * cos(phi)) - ...
            l_csi/(r * cos(phi))^2;
    
    dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
            aP_phi/r -...
            l_n/r^2;

    dlr   = l_n*(((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r - Psr*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r^2 - (2*l_n)/r^3 + ((mue*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (3*R^2*c20*cos(phi)*sin(phi))/r^3))/r^2 + (mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4))/r - (3*cosPSIM*muM*(sin(Dm)*cos(phi) - cos(Dm)*cos(RA - RAm)*sin(phi)))/rM^3 - (3*cosPSIS*muS*(sin(Ds)*cos(phi) - cos(Ds)*cos(RA - RAs)*sin(phi)))/rS^3)/r - (2*n*v)/r^2) - l_csi*((2*l_csi)/(r^3*cos(phi)^2) + (2*v*(csi + omega))/r^2 + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3)/(r^2*cos(phi)) + ((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r^2*cos(phi)) + (mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5))/(r*cos(phi)) - (3*cosPSIM*muM*cos(Dm)*sin(RA - RAm))/rM^3 - (3*cosPSIS*muS*cos(Ds)*sin(RA - RAs))/rS^3)/(r*cos(phi))) - l_v*(cos(phi)^2*(csi + omega)^2 + mue*((6*R^2*c20*(3*sin(phi)^2 - 1))/r^5 + (36*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^5 + (300*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^6 + (10*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^6 + (36*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^5 + (300*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^6 + (10*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^6) + (2*mue)/r^3 + n^2 + (muM*(3*cosPSIM^2 - 1))/rM^3 + (muS*(3*cosPSIS^2 - 1))/rS^3);
    dll   = (l_csi*mue*((3*R^2*cos(phi)^2*(4*s22*sin(2*l) + 4*c22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(9*s33*sin(3*l) + 9*c33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(4*s32*sin(2*l) + 4*c32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4)))/(r^2*cos(phi)^2) - (l_n*mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/r^2 - l_v*mue*((9*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^4 + (60*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^5 + (9*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^4 + (60*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^5 + (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/r^5);
    dlphi = l_n*(cos(phi)^2*(csi + omega)^2 - sin(phi)^2*(csi + omega)^2 + ((mue*((6*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + (45*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^4 - (3*R^2*c20*cos(phi)^2)/r^3 - (6*R^2*sin(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^3 - (30*R^3*sin(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + (3*R^2*c20*sin(phi)^2)/r^3 + (5*R^3*c30*sin(phi)^3)/r^4 - (15*R^3*cos(phi)^3*(c31*cos(l) + s31*sin(l)))/r^4 + (R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/(2*r^4) + (12*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^3 + (105*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - (90*R^3*cos(phi)*sin(phi)^2*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) - (15*R^3*c30*cos(phi)^2*sin(phi))/r^4 + (45*R^3*cos(phi)*sin(phi)^2*(c31*cos(l) + s31*sin(l)))/r^4))/r - Psr*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)) + (3*cosPSIM*muM*r*(sin(Dm)*sin(phi) + cos(Dm)*cos(RA - RAm)*cos(phi)))/rM^3 + (3*cosPSIS*muS*r*(sin(Ds)*sin(phi) + cos(Ds)*cos(RA - RAs)*cos(phi)))/rS^3)/r) + l_v*(mue*((60*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + (9*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 - (9*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^4 + (2*R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/r^5 - (120*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^5 - (180*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + (20*R^3*c30*cos(phi)*sin(phi)^2)/r^5 - (2*R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5 + (60*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^5 - (18*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + (9*R^2*c20*cos(phi)*sin(phi))/r^4) + 2*r*cos(phi)*sin(phi)*(csi + omega)^2) - l_csi*(((mue*((3*R^2*sin(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (3*R^2*cos(phi)^2*(c21*sin(l) - s21*cos(l)))/r^3 - (15*R^3*cos(phi)^3*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (30*R^3*cos(phi)*sin(phi)^2*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (45*R^3*cos(phi)^2*sin(phi)*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4) - (15*R^3*cos(phi)^2*sin(phi)*(c31*sin(l) - s31*cos(l)))/r^4 + (6*R^2*cos(phi)*sin(phi)*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3))/(r*cos(phi)) - (mue*sin(phi)*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)^2))/(r*cos(phi)) + 2*n*(csi + omega)*(tan(phi)^2 + 1) - (2*l_csi*sin(phi))/(r^2*cos(phi)^3) - (sin(phi)*((mue*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4)))/(r*cos(phi)) - Psr*cos(Ds)*sin(RA - RAs) + (3*cosPSIM*muM*r*cos(Dm)*sin(RA - RAm))/rM^3 + (3*cosPSIS*muS*r*cos(Ds)*sin(RA - RAs))/rS^3))/(r*cos(phi)^2));
    dlv   = (2*l_n*n)/r - l_r + (2*l_csi*(csi + omega))/r;
    dlcsi = l_csi*((2*v)/r - 2*n*tan(phi)) - l_l - l_v*r*cos(phi)^2*(2*csi + 2*omega) + l_n*cos(phi)*sin(phi)*(2*csi + 2*omega);
    dln   = (2*l_n*v)/r - l_phi - 2*l_v*n*r - 2*l_csi*tan(phi)*(csi + omega);
 

       
    % FOP
%     dr = v; 
%     dl = csi; 
%     dphi = n; 
%     
%     dv   = -mue/r^2 + r*n^2 + r*(csi + omega)^2 *(cos(phi))^2 + ...
%             aP_r - ...
%             c1 * u/m * l_v/LV;
%     
%     dcsi =  2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
%             aP_l/(r * cos(phi)) - ...
%             1/(r * cos(phi))^2 * c1 * u/m * l_csi/LV;
%     
%     dn   = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
%             aP_phi/r -...
%             1/r^2 * c1 * u/m * l_n/LV;



    STM = jacobian([dr; dl; dphi; dv; dcsi; dn; dlr; dll; dlphi; dlv; dlcsi; dln], [r, l, phi, v, csi, n,  l_r, l_l, l_phi, l_v, l_csi, l_n]); 
        
end


function [RA, dec] = RaDec(cart_pos)
    r = sqrt(cart_pos(1)^2 + cart_pos(2)^2 + cart_pos(3)^2);
    l = cart_pos(1)/r;  m = cart_pos(2)/r; n = cart_pos(3)/r; 
    dec = asin(n); 
    
    if m > 0 
        RA = acos(l/cos(dec)); 
    else 
        RA = 2*pi - acos(l/cos(dec)); 
    end 

end 


function f = opt_solv(l, state, t_CONTROL, dat, grav, SRP, t0, ln, pert_selector, ll, tt)

    xf = state.final; x0 = state.initial; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    initial = [x0; l]; 
    [~, xx] = ode78(@(t,sph) SPHmotion(t, sph, dat, grav, SRP, t0, ln, pert_selector, ll, tt), t_CONTROL, initial, options);
    f = [xx(end,1)-xf(1); xx(end,2)-xf(2); xx(end,3)-xf(3);  xx(end,4)-xf(4); xx(end,5)-xf(5); xx(end,6)-xf(6)];

end 


function r_M = lunar_position(jd)
    %...Calculates the geocentric equatorial position vector of the moon
    % given the Julian day.
    
    %...Earth’s radius (km):
    Re = 6378;
    
    %...Time in centuries since J2000:
    T = (jd - 2451545)/36525;
    
    %...Ecliptic longitude (deg):
    e_long = 218.32 + 481267.881*T ...
    + 6.29*sind(135.0 + 477198.87*T) - 1.27*sind(259.3 - 413335.36*T)...
    + 0.66*sind(235.7 + 890534.22*T) + 0.21*sind(269.9 + 954397.74*T)...
    - 0.19*sind(357.5 + 35999.05*T) - 0.11*sind(186.5 + 966404.03*T);
    
    e_long = mod(e_long,360);
    
    %...Ecliptic latitude (deg):
    e_lat = 5.13*sind( 93.3 + 483202.02*T) + 0.28*sind(228.2 + 960400.89*T)...
    - 0.28*sind(318.3 + 6003.15*T) - 0.17*sind(217.6 - 407332.21*T);
    
    e_lat = mod(e_lat,360);
    
    %...Horizontal parallax (deg):
    h_par = 0.9508 ...
    + 0.0518*cosd(135.0 + 477198.87*T) + 0.0095*cosd(259.3 - 413335.36*T)...
    + 0.0078*cosd(235.7 + 890534.22*T) + 0.0028*cosd(269.9 + 954397.74*T);
    
    h_par = mod(h_par,360);
    
    %...Angle between earth’s orbit and its equator (deg):
    obliquity = 23.439291 - 0.0130042*T;
    
    %...Direction cosines of the moon’s geocentric equatorial position vector:
    l = cosd(e_lat) * cosd(e_long);
    m = cosd(obliquity)*cosd(e_lat)*sind(e_long) - sind(obliquity)*sind(e_lat);
    n = sind(obliquity)*cosd(e_lat)*sind(e_long) + cosd(obliquity)*sind(e_lat);
    
    %...Earth-moon distance (km):
    dist = Re/sind(h_par);
    
    %...Moon’s geocentric equatorial position vector (km):
    r_M = dist*[l m n];

end
