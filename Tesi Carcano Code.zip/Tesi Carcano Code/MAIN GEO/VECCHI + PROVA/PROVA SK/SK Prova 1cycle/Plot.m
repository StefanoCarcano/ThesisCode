clearvars; close all; clc;

%% DIMENSIONALIZATION
ll = 42165.8; tt = sqrt(ll^3/398600);          %Uncomment to adimensionalize
% ll_c = 1; tt_c = 1;                            %Uncomment for adimensional control (in case of adimensional problem) 
% ll = 1; tt = 1;                              %Uncomment for dimensional problem
ll_c = 42165.8; tt_c = sqrt(ll_c^3/398600);  %Uncomment for dimensional control (if dimensional problem)


% TIME
hours = 3600;                               
days = 24*hours;

t0 = 332985600;                              %initial time MJD2000

tf1 = t0 + 2.5*days;                                                          
tf2 = tf1 + 0.5*days;                                                           
nit = 1000; 
t_FREEDRIFT = linspace(t0, tf1, nit);
t_CONTROL = linspace(tf1, tf2, nit);

%% LOAD DATA FROM DACE
sph_FD = importdata('FreeDrift.txt');
sph_C1 = importdata('ControlState1.txt'); % ControlState1+GG  to add splitted autonomous/non autonomous solution
sph_C2 = importdata('ControlState2.txt');
sph_S = importdata('ShootingState.txt'); 

%% PLOT 1 cycle

figure()  % Groundtrack
plot(rad2deg(sph_FD(:,2)), rad2deg(sph_FD(:,3)), '--k','LineWidth',1)
hold on
grid on
title('Groundtrack');
xlabel('Longitude [deg]');
ylabel('Latitude [deg]');
plot(rad2deg(sph_FD(1,2)), rad2deg(sph_FD(1,3)),'ok','LineWidth',1.5); 
plot(rad2deg(sph_FD(end,2)), rad2deg(sph_FD(end,3)),'sk','LineWidth',2);
plot(rad2deg(sph_C1(:,2)), rad2deg(sph_C1(:,3)), '-c','LineWidth',1)
% plot(rad2deg(sph_C1(1,2)), rad2deg(sph_C1(1,3)),'sm','LineWidth', 2); 
% plot(rad2deg(sph_C1(end,2)), rad2deg(sph_C1(end,3)),'om','LineWidth',2);
plot(rad2deg(sph_C2(:,2)), rad2deg(sph_C2(:,3)), '-b','LineWidth',1)
% plot(rad2deg(sph_C2(1,2)), rad2deg(sph_C2(1,3)),'sb','LineWidth', 2); 
% plot(rad2deg(sph_C2(end,2)), rad2deg(sph_C2(end,3)),'ob','LineWidth',2);
plot(rad2deg(sph_S(:,2)), rad2deg(sph_S(:,3)), '-.r','LineWidth',1)
plot(rad2deg(sph_S(1,2)), rad2deg(sph_S(1,3)),'sr','LineWidth', 2); 
plot(rad2deg(sph_S(end,2)), rad2deg(sph_S(end,3)),'or','LineWidth',2);
legend('Track', 'Start Free drift', 'End Free drift','Linear solution', '2nd order solution', 'Shooting solution', 'Start control', 'End control', Location='best')

figure()
plot((sph_FD(:,1))*ll, (sph_FD(:,4))*ll/tt, '-.k','LineWidth',1)
hold on
grid on
title('Radius and radial vel');
xlabel('Semi major axis [km]');
ylabel('Radial velocity [km/s]');
plot((sph_FD(1,1))*ll, (sph_FD(1,4))*ll/tt,'ok','LineWidth',1.5); 
plot((sph_FD(end,1))*ll, (sph_FD(end,4))*ll/tt,'sk','LineWidth',2);
plot((sph_C1(:,1))*ll, (sph_C1(:,4))*ll/tt, '-c','LineWidth',1)
plot((sph_C2(:,1))*ll, (sph_C2(:,4))*ll/tt, '-b','LineWidth',1)
% plot((sph_C2(1,1))*ll, (sph_C2(1,4))*ll/tt,'sc','LineWidth', 2); 
% plot((sph_C2(end,1))*ll, (sph_C2(end,4))*ll/tt,'oc','LineWidth',2);
plot((sph_S(:,1))*ll, (sph_S(:,4))*ll/tt, '-.r','LineWidth',1)
plot((sph_S(1,1))*ll, (sph_S(1,4))*ll/tt,'sr','LineWidth', 2); 
plot((sph_S(end,1))*ll, (sph_S(end,4))*ll/tt,'or','LineWidth',2);
legend('Track', 'Start Free drift', 'End Free drift', 'Linear solution', '2nd order solution', 'Shooting solution', 'Start control', 'End control', Location='best')


%% Error 

for i = 1:length(sph_S)
    posErr1(i) = abs(sph_C1(i,1)*ll - sph_S(i,1)*ll);
    lonErr1(i) = abs(rad2deg(sph_C1(i,2)) - rad2deg(sph_S(i,2)));
    latErr1(i) = abs(rad2deg(sph_C1(i,3)) - rad2deg(sph_S(i,3)));
    posErr2(i) = abs(sph_C2(i,1)*ll - sph_S(i,1)*ll);
    lonErr2(i) = abs(rad2deg(sph_C2(i,2)) - rad2deg(sph_S(i,2)));
    latErr2(i) = abs(rad2deg(sph_C2(i,3)) - rad2deg(sph_S(i,3)));

    vErr1(i) = abs(sph_C1(i,4)*ll/tt - sph_S(i,4)*ll/tt);
    csiErr1(i) = abs(rad2deg(sph_C1(i,5))/tt - rad2deg(sph_S(i,5))/tt);
    nErr1(i) = abs(rad2deg(sph_C1(i,6))/tt - rad2deg(sph_S(i,6))/tt);
    vErr2(i) = abs(sph_C2(i,4)*ll/tt - sph_S(i,4)*ll/tt);
    csiErr2(i) = abs(rad2deg(sph_C2(i,5))/tt - rad2deg(sph_S(i,5))/tt);
    nErr2(i) = abs(rad2deg(sph_C2(i,6))/tt - rad2deg(sph_S(i,6))/tt);
end



figure()
subplot(3,1,1)
title('Semi-major axis Error [km]')
yyaxis left
plot((t_CONTROL - t0)/days, posErr1, 'b')
xlabel('Days')
ylabel('|a_{exact} - a_{1sr}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, posErr2, 'r')
ylabel('|a_{exact} - a_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,2)
title('Longitude Error [deg]')
yyaxis left
plot((t_CONTROL - t0)/days, lonErr1, 'b')
xlabel('Days')
ylabel('|\lambda_{exact} - \lambda_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, lonErr2, 'r')
ylabel('|\lambda_{exact} - \lambda_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,3)
title('Latitude Error [km]')
yyaxis left
plot((t_CONTROL - t0)/days, latErr1, 'b')
xlabel('Days')
ylabel('|\phi_{exact} - \phi_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, latErr2, 'r')
ylabel('|\phi_{exact} - \phi_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')


figure()
subplot(3,1,1)
title('Radial velocity axis Error [km/s]')
yyaxis left
plot((t_CONTROL - t0)/days, vErr1, 'b')
xlabel('Days')
ylabel('|v_{exact} - v_{1sr}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, vErr2, 'r')
ylabel('|v_{exact} - v_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,2)
title('Longitude drift Error [deg/s]')
yyaxis left
plot((t_CONTROL - t0)/days, csiErr1, 'b')
xlabel('Days')
ylabel('|\xi_{exact} - \xi_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, csiErr2, 'r')
ylabel('|\xi_{exact} - \xi_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')

subplot(3,1,3)
title('Latitude drift Error [deg/s]')
yyaxis left
plot((t_CONTROL - t0)/days, nErr1, 'b')
xlabel('Days')
ylabel('|n_{exact} - n_{1st}|')
hold on
yyaxis right
plot((t_CONTROL - t0)/days, nErr2, 'r')
ylabel('|n_{exact} - n_{2nd}|')
grid minor
legend('1st order error', '2nd order error', Location='best')









