clearvars; close all; clc;

%% Gauss equations J2 + Moon + Sun perturbations + Solar radiation pressure 

MJD0 = date2mjd2000([2023, 01, 01, 0, 0, 0]);    %time zero in MJD2000 
RE = 6378;       %Earth=s radius (km)
deg = pi/180; %Degrees to radians

grav.J2 = 1082.63e-6; %Earth=s J2 
grav.muE = 398600;    %Gravitational parameter (km^3/s^2)
grav.muS = astroConstants(4); 
grav.muM = astroConstants(20);

SRP.mass = 3000; % kg 
SRP.Surf = 100; % m^2
SRP.Cr = 1.5; 
SRP.S = 1367; % W/m^2
SRP.c = 2.998*1e8; % speed of light


% Initial condition

e0 = 0.01; a0 = 42164; i0 = 1*deg; RA0 = 45*deg; w0 = 30*deg; theta0 = 0*deg;
g0 = [a0, e0, i0, RA0, w0, theta0]';


% Time span for integration
T_day = 24*3600;         %1 day time, in seconds
T = 2*pi*sqrt(a0^3/grav.muE); %Orbit period
t_start = 0;
t_end = 20*T;            % Set final time 

tspan = [t_start,t_end]; %Time span for integration

% Options and orbit propagation with Gauss
options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10);
[t_gauss, g] = ode113(@(t, g) Gauss(t, g, RE, grav, SRP, MJD0), tspan, g0, options);

a = g(:,1);
e = g(:,2);
i = g(:,3);
RA = g(:,4);
w = g(:,5);
TA = g(:,6);

%...Plot the time histories of the osculating elements:
figure()

subplot(5,1,1)
plot(t_gauss/3600/24,(RA)/deg)
title('Right Ascension (degrees)')
xlabel('days')
grid on
grid minor
axis tight
subplot(5,1,2)

plot(t_gauss/3600/24,(w)/deg)
title('Argument of Perigee (degrees)')
xlabel('days')
grid on
grid minor
axis tight

subplot(5,1,3)
plot(t_gauss/3600/24, a)
title('Semi major axis (km)')
xlabel('days')
grid on
grid minor
axis tight

subplot(5,1,4)
plot(t_gauss/3600/24, e)
title('Eccentricity')
xlabel('days')
grid on
grid minor
axis tight

subplot(5,1,5)
plot(t_gauss/3600/24, (i)/deg)
title('Inclination (degrees)')
xlabel('days')
grid on
grid minor
axis tight




%% Cartesian equations 

MJD0 = date2mjd2000([2010, 07, 21, 12, 0, 0]);    %time zero in MJD2000 
RE = 6378;       %Earth=s radius (km)
J2 = 1082.63e-6; %Earth=s J2 
muE = 398600;    %Gravitational parameter (km^3/s^2)
muS = astroConstants(4); 
muM = astroConstants(20); 

% Initial condition

e = 0; a = 42164; i = 0*pi()/180; O = 0*pi()/180; w0 = 0*pi()/180; theta = 0;
[r0,v0] = kp2rv(a, e, i, O, w0, theta, muE);
x0 = [r0,v0];


% Time span for integration
T_day = 24*3600;              %1 day time, in seconds
T = 2*pi*sqrt(a^3/muE);        %Orbit period
t_start = 0;
t_end = 2000*T;
tspan = [t_start, t_end];      %Time span for integration

options = odeset('RelTol',1e-12 , 'AbsTol', 1e-12);
[t, xx] = ode113( @(t, y) Cartesian_pert(t, y, J2, RE, muE, muM, muS, MJD0), tspan, x0, options);

figure()
title('Perturbed orbit')
plot_earth(RE);
hold on
col = t';
surface([xx(:,1)'; xx(:,1)'], [xx(:,2)'; xx(:,2)'], [xx(:,3)'; xx(:,3)'], [col; col],'facecol','no','edgecol','interp')
% view(45,0)
axis equal
grid minor
% colorbar('Ticks',[0,10*T,20*T,30*T],'TickLabels',{'0','10T','20T','30T'}); 
hold on

%% FUNCTIONS

function dy = Cartesian_pert(t, y, J2, RE, muE, muM, muS, MJD0)

    r = y(1:3); v = y(4:6);

    %Compute J2 perturbation in ECEF
    a_vector_x = (y(1)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-1);
    a_vector_y = (y(2)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-1);
    a_vector_z = (y(3)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-3);

    aJ2 = [a_vector_x;a_vector_y;a_vector_z];
    aJ2 = aJ2*((3/2)*(J2*muE*RE^2)/norm(y(1:3))^4);
    
    %Compute moon and sun perturbation in ECEF
    tdays = t/24/3600;     % time in days
    MJD2000 = MJD0 + tdays;
    r_M = lunar_position(MJD2000);   r_MS = r_M' - r; 
    [r_S, ~, ~] = solar_position(MJD2000);   r_SS = r_S - r;
    
    aS = muS/norm(r_SS)^3*((1 - norm(r_SS)^3 /norm(r_S)^3)*r_S - r);
    aM = muM*(r_MS/norm(r_MS)^3 - r_M'/norm(r_M)^3);

    %Calculate orbital
    dy = [v; (-muE/norm(r)^3)*r + aJ2 + aM + aS];

end 


function dy = Gauss(t, y, RE, grav, SRP, MJD0)
      
    a = y(1);e = y(2); i = y(3); O = y(4); o = y(5); n = y(6);
    truLon = n + o + O; argLat = o + n; lonPer = O + o;
    p = a*(1-e^2);

    J2 = grav.J2; muE =grav.muE; muS = grav.muS; muM = grav.muM;  
    m = SRP.mass; S = SRP.Surf; Cr = SRP.Cr; S = SRP.S; c = SRP.c;  
        
    [r,v] = kp2rv(a, e, i, O, o, n, muE);
    h_angular = norm(cross(r,v));
    
    % Relative reference system setup
    t_vector = v/norm(v); h_vector = cross(r,v)/norm(cross(r,v)); 
    n_vector = cross(h_vector,t_vector);
    
    A = [t_vector(1),t_vector(2),t_vector(3);...
         n_vector(1),n_vector(2),n_vector(3);...
         h_vector(1),h_vector(2),h_vector(3)];      % [t;n;b] = A*[x;y;z]
    
    %Calculate J2 acceleration
    a_vector_x = (r(1)/norm(r))*(5*r(3)^2/norm(r)^2-1);
    a_vector_y = (r(2)/norm(r))*(5*r(3)^2/norm(r)^2-1);
    a_vector_z = (r(3)/norm(r))*(5*r(3)^2/norm(r)^2-3);
    aJ2 = [a_vector_x; a_vector_y; a_vector_z];
    aJ2 = aJ2*((3/2)*(J2*muE*RE^2)/norm(r)^4);      % J2 acceleration inertial [km/s2]
    aJ2 = A*aJ2;
    
    %Compute moon and sun perturbation in ECEF
    tdays = t/24/3600;        % time in days
    MJD2000 = MJD0 + tdays;

    r_M = lunar_position(MJD2000);   r_MS = r_M' - r; 
    [r_S, lamda, eps] = solar_position(MJD2000);   r_SS = r_S - r;
    
    aS = muS/norm(r_SS)^3*((1 - norm(r_SS)^3 /norm(r_S)^3)*r_S - r);
    aM = muM*(r_MS/norm(r_MS)^3 - r_M'/norm(r_M)^3);
    
    aS = A * aS;   
    aM = A * aM;
    
    % Compute SRP 
    
    nu = eclipse(r, r_S, RE);   % = 0 or = 1 if in shadow or in light respectively 
    Psr = nu *S/c*Cr * A/m;     % perturbing acceleration F/m 

    aSRP = - 1e-3 * Psr * [cos(lamda); cos(eps)*sin(lamda); sin(eps)*sin(lamda)]; 
    
    aSRP = A * aSRP; 

    % Sum up all the accelerations in tnb frame
    acc = aJ2 + aM + aS + aSRP;
   
    
    % Gauss planetary equations
    da = 2*a^2*norm(v)/muE*acc(1);
    de = (1/norm(v))*(2*(e + cos(n))*acc(1) - norm(r)/a*sin(n)*acc(2));
    di = norm(r)*cos(argLat)*acc(3)/h_angular;
    dO = norm(r)*sin(argLat)*acc(3)/(h_angular*sin(i));
    do = (1/e/norm(v))*(2*sin(n)*acc(1) + (2*e+norm(r)/a*cos(n))*acc(2)) - norm(r)*sin(argLat)*cos(i)*acc(3)/h_angular/sin(i);
    dnu = h_angular/norm(r)^2 - (1/e/norm(v))*(2*sin(n)*acc(1) + (2*e+norm(r)/a*cos(n))*acc(2));
    
    dy = [da,de,di,dO,do,dnu]';

end


function  [r_S, lamda, eps] = solar_position(jd)
    % This function calculates the geocentric equatorial position vector
    % of the sun, given the Julian date.
    
    AU = 149597870.691;
    
    %...Julian days since J2000:
    n = jd - 2451545;
    
    %...Julian centuries since J2000:
    cy = n/36525;
    
    %...Mean anomaly (deg{:
    M = 357.528 + 0.9856003*n;
    M = mod(M,360);
    
    %...Mean longitude (deg):
    L = 280.460 + 0.98564736*n;
    L = mod(L,360);
    
    %...Apparent ecliptic longitude (deg):
    lamda = L + 1.915*sind(M) + 0.020*sind(2*M);
    lamda = mod(lamda,360);
    
    %...Obliquity of the ecliptic (deg):
    eps = 23.439 - 0.0000004*n;
    
    %...Unit vector from earth to sun:
    u = [cosd(lamda); sind(lamda)*cosd(eps); sind(lamda)*sind(eps)];
    
    %...Distance from earth to sun (km):
    rS = (1.00014 - 0.01671*cosd(M) - 0.000140*cosd(2*M))*AU;
    
    %...Geocentric position vector (km):
    r_S = rS*u;

end 


function r_M = lunar_position(jd)
    %...Calculates the geocentric equatorial position vector of the moon
    % given the Julian day.
    
    %...Earth’s radius (km):
    Re = 6378;
    
    %...Time in centuries since J2000:
    T = (jd - 2451545)/36525;
    
    %...Ecliptic longitude (deg):
    e_long = 218.32 + 481267.881*T ...
    + 6.29*sind(135.0 + 477198.87*T) - 1.27*sind(259.3 - 413335.36*T)...
    + 0.66*sind(235.7 + 890534.22*T) + 0.21*sind(269.9 + 954397.74*T)...
    - 0.19*sind(357.5 + 35999.05*T) - 0.11*sind(186.5 + 966404.03*T);
    
    e_long = mod(e_long,360);
    
    %...Ecliptic latitude (deg):
    e_lat = 5.13*sind( 93.3 + 483202.02*T) + 0.28*sind(228.2 + 960400.89*T)...
    - 0.28*sind(318.3 + 6003.15*T) - 0.17*sind(217.6 - 407332.21*T);
    
    e_lat = mod(e_lat,360);
    
    %...Horizontal parallax (deg):
    h_par = 0.9508 ...
    + 0.0518*cosd(135.0 + 477198.87*T) + 0.0095*cosd(259.3 - 413335.36*T)...
    + 0.0078*cosd(235.7 + 890534.22*T) + 0.0028*cosd(269.9 + 954397.74*T);
    
    h_par = mod(h_par,360);
    
    %...Angle between earth’s orbit and its equator (deg):
    obliquity = 23.439291 - 0.0130042*T;
    
    %...Direction cosines of the moon’s geocentric equatorial position vector:
    l = cosd(e_lat) * cosd(e_long);
    m = cosd(obliquity)*cosd(e_lat)*sind(e_long) - sind(obliquity)*sind(e_lat);
    n = sind(obliquity)*cosd(e_lat)*sind(e_long) + cosd(obliquity)*sind(e_lat);
    
    %...Earth-moon distance (km):
    dist = Re/sind(h_par);
    
    %...Moon’s geocentric equatorial position vector (km):
    r_M = dist*[l m n];

end


function nu = eclipse(r, r_S, RE)

    rr = norm(r); 
    rs = norm(r_S); 
    theta = acos(dot(r_S, r)/(rr*rs)); 
    theta1 = acos(RE/rr);  theta2 = acos(RE/rs); 

    if (theta1 + theta2) <= theta 
        nu = 0; 
    else 
        nu = 1; 
    end 

end


function plot_earth(Re)

    TERRA=imread('planisphere.jpg','jpg');
    props.FaceColor='texture';
    props.EdgeColor='none';
    props.FaceLighting='phong';
    props.Cdata=TERRA;
    C=[0;0;0];
    [XX,YY,ZZ]=ellipsoid(C(1),C(2),C(3),Re,Re,Re,1000);
    surface(-XX,-YY,-ZZ,props,'HandleVisibility','off');

end