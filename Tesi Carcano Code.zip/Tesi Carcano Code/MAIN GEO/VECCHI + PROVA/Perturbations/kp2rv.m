function [r,v]=kp2rv(a,e,i,OMEGA,omega,theta,mu)
%%
%      kp2rv.m -- from keplerian elements to cartesian coordinates
%     
%     
%     DESCRIPTION:
%       This function computes the cartesian coordinates of a point on a
%       orbit, starting from the keplerian elements
%     
%     INPUT: 
%          a = semi major axis; e = eccentricity;  i = inclination;  OMEGA
%          = right asciension of the ascending node; omega = argument of
%          the perigee; theta = true anomaly; mu = 2BP costant. 
%       
%     
%     OUTPUT:
%          r = position vector in cartesian coordinates  [rx; ry; rz];
%          v = velocity vector in cartesian coordinates [vx; vy; vz].
%     
%     CALLED FUNCTIONS:
%                       -----
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       

% Matrici di rotazione

R_OMEGA=[cos(OMEGA) sin(OMEGA) 0
    -sin(OMEGA) cos(OMEGA) 0
    0 0 1];

R_i=[1 0 0
    0 cos(i) sin(i)
    0 -sin(i) cos(i)];

R_omega=[cos(omega) sin(omega) 0
    -sin(omega) cos(omega) 0
    0 0 1];

T_ge2pf=R_omega*R_i*R_OMEGA;

T_pf2ge=(T_ge2pf)';

% Calcolo p, h

p=a*(1-e^2);
h=sqrt(mu*p);

% r,v in coordinate PF

r_pf=[p/(1+e*cos(theta))*cos(theta); p/(1+e*cos(theta))*sin(theta); 0];
v_pf=[(mu/h)*(-sin(theta)); (mu/h)*(e+cos(theta)); 0];

% r,v in coordinate GE

r_ge=T_pf2ge*r_pf;
v_ge=T_pf2ge*v_pf;

% Output funzione

r=r_ge;
v=v_ge;