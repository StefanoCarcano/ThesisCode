clearvars; close all; clc;

%% Gravity potential (zonal + sectorial truncated at 2,2)

% Compute perturbing accelerations (GRAVITY) --- set symbolic coordinates 
syms mu R r l phi c20 c21 c22 c30 c31 c32 c33 s21 s22 s31 s32 s33

Ug = mu * ( ...
    R^2/(2*r^3) * c20 * (3 * (sin(phi))^2 - 1) + ...
    R^2/r^3 * 3 * cos(phi) * sin(phi) * (c21 * cos(l) + s21 * sin(l)) + ...
    R^2/r^3 * 3 * (cos(phi))^2 * (c22 * cos(2*l) + s22 * sin(2*l)) + ...
    R^3/(2*r^4) * c30 * sin(phi) * (5 * (sin(phi))^2 - 3) + ...
    R^3/(2*r^4) * cos(phi) * (15 * (sin(phi))^2 - 3) * (c31 * cos(l) + s31 * sin(l)) + ...
    R^3/r^4 * 15 * sin(phi) * (cos(phi))^2 * (c32 * cos(2*l) + s32 * sin(2*l)) + ...
    R^3/r^4 * 15 * (cos(phi))^3 * (c33 * cos(3*l) + s33 * sin(3*l))  ); 


aPg_r   = diff(Ug, r);
aPg_l   = diff(Ug, l);
aPg_phi = diff(Ug, phi);


syms muS muM xs ys zs xm ym zm x y z

Usm = muS/sqrt(xs^2 + ys^2 + zs^2) * ( 1/sqrt((xs - x)^2 + (ys - y)^2 + (zs - z)^2) - ...
      (x*xs + y*ys + z*zs) / (sqrt(xs^2 + ys^2 + zs^2))^3) - ...
      muM * (1/sqrt((xm - x)^2 + (ym - y)^2 + (zm - z)^2) - ...
      (x*xm + y*ym + z*zm) / (sqrt(xm^2 + ym^2 + zm^2))^3); 

aPsm_x = diff(Usm, x);
aPsm_y = diff(Usm, y);
aPsm_z = diff(Usm, z);
      

syms Psr xs ys zs x y z 

Usrp = Psr * sqrt((xs - x)^2 + (ys - y)^2 + (zs - z)^2); 

aPsrp_x = -diff(Usrp, x);
aPsrp_y = -diff(Usrp, y);
aPsrp_z = -diff(Usrp, z);
 

%% Cartesian gravity potential 

syms x y z g mu R c20 c21 s21 c22 s22 c30 c31 s31 c32 s32 c33 s33

Ugcart = mu * R^2 *c20/2 * (2*z^2 - x^2 - y^2)/(sqrt(x^2 + y^2 +z^2))^5 + ...
         3 * mu * R^2 * c21 * z*(x*cos(g) + y*sin(g))/(sqrt(x^2 + y^2 +z^2))^5 + ...
         3 * mu * R^2 * s21 * z*(y*cos(g) - x*sin(g))/(sqrt(x^2 + y^2 +z^2))^5 + ...
         3 * mu * R^2 * c22 * ((x^2 - y^2) * cos(2*g) + 2*x*y*sin(2*g))/(sqrt(x^2 + y^2 +z^2))^5 + ...
         3 * mu * R^2 * s22 * ((y^2 - x^2) * sin(2*g) + 2*x*y*cos(2*g))/(sqrt(x^2 + y^2 +z^2))^5 + ...
         mu * R^3 *c30/2 * z * (2*z^2 - 3*x^2 - 3*y^2)/(sqrt(x^2 + y^2 +z^2))^7 + ...
         mu * R^3 *c31/2 * (12*z^2 - 3*x^2 - 3*y^2) * (x*cos(g) + y*sin(g))/(sqrt(x^2 + y^2 +z^2))^7 + ...
         mu * R^3 *s31/2 * (12*z^2 - 3*x^2 - 3*y^2) * (y*cos(g) - x*sin(g))/(sqrt(x^2 + y^2 +z^2))^7 + ...
         15 * mu *R^3 *c32 * z * ((x^2 - y^2)*cos(2*g) + 2*x*y*sin(2*g))/(sqrt(x^2 + y^2 +z^2))^7 + ...
         15 * mu *R^3 *s32 * z * ((y^2 - x^2)*sin(2*g) + 2*x*y*cos(2*g))/(sqrt(x^2 + y^2 +z^2))^7 + ...
         15 * mu * R^3 * c33 * (x*cos(g) + y*sin(g)) * (x^2 + y^2 -4*(y*cos(g) - x*sin(g))^2)/(sqrt(x^2 + y^2 +z^2))^7 + ...
         15 * mu * R^3 * s33 * (y*cos(g) - x*sin(g)) * (x^2 + y^2 -4*(x*cos(g) + y*sin(g))^2)/(sqrt(x^2 + y^2 +z^2))^7;


aPg_x =  diff(Ugcart, x);
aPg_y =  diff(Ugcart, y);
aPg_z =  diff(Ugcart, z);













