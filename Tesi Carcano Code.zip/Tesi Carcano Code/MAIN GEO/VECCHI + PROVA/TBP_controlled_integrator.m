function d_dyn  = TBP_controlled_integrator(~, dyn, dat)
    
    d_dyn = zeros(12,1);  
    
    % state and costate  
    x =  dyn(1); y =  dyn(2); z =  dyn(3); 
    vx = dyn(4); vy = dyn(5); vz = dyn(6); 
    lambda = dyn(7:12);

    R = sqrt(x^2 + y^2 + z^2); 
    mu = dat.mu;

    % Set dynamics
    dx = vx; 
    dy = vy; 
    dz = vz; 
    ax = - mu/R^3 *x - lambda(4);
    ay = - mu/R^3 *y - lambda(5);
    az = - mu/R^3 *z - lambda(6);


    % Compute costate dynamics
    syms X Y Z Vx Vy Vz

    dX = Vx; 
    dY = Vy; 
    dZ = Vz; 
    aX = - mu/R^3 *X - lambda(4);
    aY = - mu/R^3 *Y - lambda(5);
    aZ = - mu/R^3 *Z - lambda(6);
    
    DfDx = jacobian([dX; dY; dZ; aX; aY; aZ], [X, Y, Z, Vx, Vy, Vz]); 
    
    Dlambda = - DfDx*lambda; 
    
    lambda_dot = double(subs(Dlambda, [X,Y,Z,Vx,Vy,Vz], [x, y, z, vx, vy, vz])); 
    

    d_dyn = [dx; dy; dz; ax; ay; az; lambda_dot]; 
    
end 