clearvars; close all; clc;


% SPHERICAL MOTION WITH PERTURBATIONS in GEO + CARTESIAN EVOLUTION OF ORBIT

% select perturbations: (pert_selector)
% 1 = GG
% 2 = Third bodies
% 3 = all 
% 4 = sun 
% 5 = moon 
% 6 = SRP

%% SETUP

pert_selector = 3;
hours = 3600;                                    %Hours to seconds
days = 24*hours;                                 %Days to seconds

dat.Re = 6378.137; 
dat.mue = 398600;
dat.muS = astroConstants(4); 
dat.muM = astroConstants(20);
dat.Rgeo = 42164.12;                              %nominal radius of geostationary orbit
dat.w = sqrt(dat.mue/(dat.Rgeo)^3);
                                 

SRP.mass = 3000; % kg 
SRP.Surf = 100; % m^2
SRP.Cr = 1.5; 
SRP.S = 1353; % W/m^2
SRP.c = 2.998*1e8; % speed of light

% values taken from 'vallado' 
grav.c20 = -1.083e-3;  
grav.c21 = -2.414e-10;  
grav.c22 = 1.574e-6;  
grav.c30 = 2.532e-6;  
grav.c31 = 2.191e-6; 
grav.c32 = 3.089e-7;  
grav.c33 = 1.006e-7;  
grav.s21 = 1.543e-9;  
grav.s22 = -9.038e-7;  
grav.s31 = 2.687e-7; 
grav.s32 = -2.115e-7;
grav.s33 = 1.972e-7;


%% SPHERICAL MOTION

% long = atan2(y, x);
% lat = atan2(z, sqrt(x.^2 + y.^2));
% r = sqrt(x.^2 + y.^2 + z.^2);


% Set initial conditions and times

ln = deg2rad(75.1);                           %nominal longitude #degrees
r0 = dat.Rgeo;                      %initial radius (altitude = Rgeo - Re)
eps0 = deg2rad(0);           %initial longitude error 
phi0 = 0;                           %initial latitude 

y0 = [r0, eps0, phi0, 0, 0, 0]; 

t0 = date2mjd2000([2023, 01, 01, 0, 0, 0])*days;                           % set initial date and convert it in seconds
tf = t0 + 365*2*days;                                                        % final time (in seconds) 
nit = 100000;  
tspan = linspace(t0, tf, nit);

% GHA reference at initial date
T0 = t0/days/36525; 
dat.G0 = 0; % wrapTo2Pi(deg2rad(100.4606184 + 36000.77004*T0 + 0.000387933*T0^2 -2.583e-8 * T0^3)); % Page 261 orb mech book


% Use ODE113 to integrate spherical equations from t0 to tf:

options = odeset('reltol', 1.e-12,'abstol', 1.e-12);
[time, sph] = ode78(@(t,sph) spherical_motion(t, sph, dat, grav, SRP, t0, ln, pert_selector), tspan, y0, options);


%% PLOT SPHERICAL

figure()

subplot(3,1,1)
l = plot((time - t0)/24/3600, sph(:, 1), '-k', 'LineWidth',0.5);
l.Color = [l.Color, 0.4]; 
title('Distance r [km]')
% xlabel('Days')
% ylabel('r [km]')
grid on
grid minor
axis tight

subplot(3,1,2)
plot((time - t0)/24/3600, ((rad2deg(sph(:, 2)))), '-k', 'LineWidth',0.5)
title('Longitude error \lambda - \lambda_n [deg]')
% xlabel('Days')
% ylabel('\lambda - \lambda_n [deg]')
grid on
grid minor
axis tight

subplot(3,1,3)
l = plot((time - t0)/24/3600, rad2deg(sph(:, 3)), '-k', 'LineWidth',0.5);
l.Color = [l.Color, 0.4]; 
title('Latitude \phi [deg]')
xlabel('Days')
% ylabel('\phi [deg]')
grid on
grid minor
axis tight


figure()  % Groundtrack
plot(rad2deg(sph(:,2))+60, rad2deg(sph(:,3)), '-k','LineWidth',0.5)
hold on
% grid on
% I = imread('EarthTexture.jpg'); 
% h = image([-180 180],-[-90 90], I); 
% uistack(h,'bottom')
title('Groundtrack');
xlabel('Longitude [deg]');
ylabel('Latitude [deg]');
% xlim([-180, 180]); ylim([-90, 90])
plot(rad2deg(sph(1,2))+60, rad2deg(sph(1,3)),'sk','LineWidth',4, 'MarkerSize',10); 
plot(rad2deg(sph(end,2))+60, rad2deg(sph(end,3)),'ok','LineWidth',4, 'MarkerSize',10);
% xline(60-0.05, '--k', 'LineWidth',2.5)
% xline(60+0.05, '--k', 'LineWidth',2.5)
lgd = legend('Free-drift track', 'Start', 'End'); 


figure()  % rv
plot((sph(:,1)),(sph(:,4))*1e3, ':k','LineWidth',0.5)
hold on
% grid on
% I = imread('EarthTexture.jpg'); 
% h = image([-180 180],-[-90 90], I); 
% uistack(h,'bottom')
title('Groundtrack');
xlabel('r [km]');
ylabel('v [m/s]');
% xlim([-180, 180]); ylim([-90, 90])
plot((sph(1,1)), (sph(1,4)),'sk','LineWidth',4, 'MarkerSize',10); 
plot((sph(end,1)), (sph(end,4)),'ok','LineWidth',4, 'MarkerSize',10);
% xline(60-0.05, '--k', 'LineWidth',2.5)
% xline(60+0.05, '--k', 'LineWidth',2.5)
lgd = legend('Free-drift track', 'Start', 'End'); 


%% CARTESIAN PROPAGATION --- EVOLUTION OF ENTIRE ORBIT 

% e = 0; a = dat.Rgeo; i = 0*pi()/180; O = 0*pi()/180; w0 = 0*pi()/180; theta = 0;
% [r0,v0] = kp2rv(a, e, i, O, w0, theta, dat.mue);
% x0 = [r0,v0];
% 
% 
% % Time span for integration
% T_day = 24*3600;              %1 day time, in seconds
% T = 2*pi*sqrt(a^3/dat.mue);        %Orbit period
% 
% tspan = [t0, tf];      %Time span for integration (same as spherical motion)
% 
% % Propagation with ode113
% options = odeset('RelTol',1e-12 , 'AbsTol', 1e-12);
% [t, xx] = ode113( @(t, y) Cartesian_pert(t, y, dat, grav, SRP), tspan, x0, options);

%% ORBIT PLOT (cartesian)

% figure()
% title('Perturbed orbit')
% plot_earth(dat.Re);
% hold on
% col = t' - t0;
% surface([xx(:,1)'; xx(:,1)'], [xx(:,2)'; xx(:,2)'], [xx(:,3)'; xx(:,3)'], [col; col],'facecol','no','edgecol','interp')
% % view(45,0)
% axis equal
% grid minor
% colorbar('Ticks',[0, 100*T, 200*T, 300*T],'TickLabels',{'0','100T','200T','300T'}); 
% hold on


%% FUNCTIONS

function dsph = spherical_motion(t, sph, dat, grav, SRP, t0, ln, pert_selector)

    mu = dat.mue; muS = dat.muS; muM = dat.muM;  omega = dat.w;  R = dat.Re; 
    m = SRP.mass; A = SRP.Surf; Cr = SRP.Cr; S = SRP.S; c = SRP.c;  G0 = dat.G0; 

    r = sph(1);             v = sph(4); 
    eps = sph(2);           csi = sph(5);
    phi = sph(3);           n = sph(6);
    
    c20 = grav.c20;  c21 = grav.c21;  c22 = grav.c22;  c30 = grav.c30;  c31 = grav.c31; 
    c32 = grav.c32;  c33 = grav.c33;  
    s21 = grav.s21;  s22 = grav.s22;  s31 = grav.s31;  s32 = grav.s32;  s33 = grav.s33;

    l = ln + eps;  

    % GRAVITY PERTURBING ACCELERATIONS (zonal + tesseral) --- derivatives taken with symbolic 

    aPg_r = -mu*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*r^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/r^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/r^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/r^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/r^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/r^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/r^5);
 


 
    aPg_l =  -mu*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/r^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/r^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/r^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/r^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*r^4))/(r*cos(phi));
 

 
    aPg_phi = mu*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/r^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/r^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*r^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/r^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/r^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/r^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*r^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/r^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/r^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/r^3)/r;
 

    % THIRD BODY PERTURBATIONS --- Solar and Moon accelerations (Take cartesian (Geocentric equatiorial inertial) pos from ephemeris)
    tdays = t/24/3600;             % time in days
    MJD2000 = tdays;

    ep = deg2rad(23.44);
    ecl = [1 0 0; 0 cos(ep) -sin(ep); 0 sin(ep) cos(ep)];   %rotation ecliptic/equatorial
    [kep, ~] = uplanet(MJD2000, 3);
    [r_E, ~] = kp2rv(kep(1), kep(2), kep(3), kep(4), kep(5), kep(6), muS);
    r_S = - r_E;
   
    r_S = ecl * r_S;                % SUN position inertial geocentric equatorial frame

%     [r_S, ~, ~] = solar_position(MJD2000);  % SUN position inertial geocentric equatorial frame
%     [r_M, ~] = ephMoon(MJD2000);            % MOOn ....
    r_M = lunar_position(MJD2000);

    [RAs, Ds] = RaDec(r_S);
    [RAm, Dm] = RaDec(r_M);
    
    rM = norm(r_M);
    rS = norm(r_S);

%     Ds = asin(r_S(3)/norm(r_S)); 
%     RAs = atan2( r_S(2), r_S(1) );
%     Dm = asin(r_M(3)/norm(r_M));
%     RAm = atan2( r_M(2), r_M(1) );
     
    RA = (l + G0 + omega * (t - t0));

%     cosPSIS = sin(phi) * sin(Ds) + cos(phi) * cos(Ds) * cos(RA - RAs);
%     cosPSIM = sin(phi) * sin(Dm) + cos(phi) * cos(Dm) * cos(RA - RAm);

    r_cart = [r*cos(phi)*cos(RA); r*cos(phi)*sin(RA); r*sin(phi)];

    cs = dot(r_S, r_cart)/(norm(r_S)*norm(r_cart));
    ss = sqrt(1 - cs^2); 
    psis = atan2(ss, cs);
    cosPSIS = cos(psis);

    cm = dot(r_M, r_cart)/(norm(r_M)*norm(r_cart));
    sm = sqrt(1 - cm^2); 
    psim = atan2(sm, cm);
    cosPSIM = cos(psim); 

     
%     figure(1)
%     quiver3(0,0,0, r_S(1)/1e3, r_S(2)/1e3, r_S(3)/1e3, 'r')
%     hold on
%     quiver3(0,0,0, r_cart(1), r_cart(2), r_cart(3), 'k')
%     quiver3(0,0,0, r_M(1), r_M(2), r_M(3), 'g')
    
    Dalphas = (RA-RAs);
    Dalpham = (RA-RAm);

    a3Sr   = muS/(rS)^3 * r *(3*cosPSIS^2 - 1);
    a3Mr   = muM/(rM)^3 * r *(3*cosPSIM^2 - 1);
    a3Sl   = -3*muS/(rS)^3 * r * cosPSIS * cos(Ds) * sin(Dalphas);
    a3Ml   =  -3*muM/(rM)^3 * r * cosPSIM * cos(Dm) * sin(Dalpham); 
    a3Sphi = 3*muS/(rS)^3 * r * cosPSIS * (cos(phi) * sin(Ds) - sin(phi) * cos(Ds) * cos(Dalphas));
    a3Mphi = 3*muM/(rM)^3 * r * cosPSIM * (cos(phi) * sin(Dm) - sin(phi) * cos(Dm) * cos(Dalpham)); 

%     r_Ms = r_M' - r_cart; 
%     r_Ss = r_S - r_cart;
    
%     aS = muS*(r_Ss/(norm(r_Ss))^3 - r_S /(norm(r_S))^3);
%     aM = muM*(r_Ms/(norm(r_Ms))^3 - r_M'/(norm(r_M))^3);

%     aS = muS/norm(r_Ss)^3*((1 - norm(r_Ss)^3 /norm(r_S)^3)*r_S - r);
%     aM = muM*(r_Ms/norm(r_Ms)^3 - r_M'/norm(r_M)^3);
    
%     xs = r_S(1); ys = r_S(2); zs = r_S(3);  xm = r_M(1); ym = r_M(2); zm = r_M(3); 
%     x = r_cart(1); y = r_cart(2); z = r_cart(3); 
%     
%     aPsm_x = muM*(xm/(xm^2 + ym^2 + zm^2)^(3/2) + (2*x - 2*xm)/(2*((x - xm)^2 + (y - ym)^2 + (z - zm)^2)^(3/2))) - (muS*(xs/(xs^2 + ys^2 + zs^2)^(3/2) + (2*x - 2*xs)/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(3/2))))/(xs^2 + ys^2 + zs^2)^(1/2);
%     aPsm_y = muM*(ym/(xm^2 + ym^2 + zm^2)^(3/2) + (2*y - 2*ym)/(2*((x - xm)^2 + (y - ym)^2 + (z - zm)^2)^(3/2))) - (muS*(ys/(xs^2 + ys^2 + zs^2)^(3/2) + (2*y - 2*ys)/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(3/2))))/(xs^2 + ys^2 + zs^2)^(1/2);
%     aPsm_z = muM*(zm/(xm^2 + ym^2 + zm^2)^(3/2) + (2*z - 2*zm)/(2*((x - xm)^2 + (y - ym)^2 + (z - zm)^2)^(3/2))) - (muS*(zs/(xs^2 + ys^2 + zs^2)^(3/2) + (2*z - 2*zs)/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(3/2))))/(xs^2 + ys^2 + zs^2)^(1/2);
 

%     aPsm = [aPsm_x; aPsm_y; aPsm_z];
%     aPsm = aS + aM; 


    % SRP PERTURBATIONS
%     nu = eclipse(r_cart, r_S, R);   % = 0 or = 1 if in shadow or in light respectively 

    Psr = S/c * Cr * A/m;         % perturbing acceleration F/m

    aSRPr   = -1e-3 * Psr * cosPSIS; 
    aSRPl   = 1e-3 * Psr * cos(Ds) * sin(Dalphas); 
    aSRPphi = -1e-3 * Psr * (sin(Ds) * cos(phi) - cos(Ds) * sin(phi) * cos(Dalphas)); 
    
%     aPsrp = -Psr*(r_Ss./norm(r_Ss));

%     aPsrp_x = -(Psr*(2*x - 2*xs))/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(1/2));
%     aPsrp_y = -(Psr*(2*y - 2*ys))/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(1/2));
%     aPsrp_z = -(Psr*(2*z - 2*zs))/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(1/2));
%     aPsrp = [aPsrp_x; aPsrp_y; aPsrp_z]; 

    
    % Accelerations (in spherical coordinates)
%     R = [cos(phi)*cos(l)   cos(phi)*sin(l)   sin(phi)
%          -sin(l)           cos(l)            0
%          -sin(phi)*cos(l)  -sin(phi)*sin(l)  cos(phi)];
% 
% 
%     aSM_sph = R*aPsm;
%     aSRP_sph = R*aPsrp;
% 
%     aPsm_r = aSM_sph(1); 
%     aPsm_l = aSM_sph(2); 
%     aPsm_phi = aSM_sph(3);    
%     aPsrp_r = aSRP_sph(1); 
%     aPsrp_l = aSRP_sph(2); 
%     aPsrp_phi = aSRP_sph(3);

    switch pert_selector
        case 1
                aP_r   = aPg_r;
                aP_l   = aPg_l;
                aP_phi = aPg_phi;
        case 2
                aP_r   =  a3Sr + a3Mr;
                aP_l   =  a3Sl + a3Ml;
                aP_phi = a3Sphi + a3Mphi;
        case 3
                aP_r   = aPg_r + a3Sr + a3Mr + aSRPr;
                aP_l   = aPg_l + a3Sl + a3Ml + aSRPl;
                aP_phi = aPg_phi + a3Sphi + a3Mphi + aSRPphi;
        case 4 
                aP_r   =  a3Sr;
                aP_l   =  a3Sl;
                aP_phi = a3Sphi;
        case 5 
                aP_r   =  a3Mr;
                aP_l   =  a3Ml;
                aP_phi = a3Mphi;
        case 6 
                aP_r   =  aSRPr;
                aP_l   =  aSRPl;
                aP_phi = aSRPphi;
    

    end

    % FINAL DYNAMICS
    dr = v; 
    deps = csi; 
    dphi = n; 
    dv = -mu/r^2 + r*n^2 + r*(csi + omega)^2 * (cos(phi))^2 + ...
          aP_r; 

    dcsi = 2*n*(csi + omega)*tan(phi) - 2*v/r *(csi + omega) + ...
           aP_l/(r * cos(phi)); 

    dn = -2*v/r *n - (csi + omega)^2 *sin(phi)*cos(phi) + ...
          aP_phi/r; 


    dsph = [dr; deps; dphi; dv; dcsi; dn]; 
end




function dy = Cartesian_pert(t, y, dat, grav, SRP)
    
    mu = dat.mue; muS = dat.muS; muM = dat.muM; R = dat.Re; 
    m = SRP.mass; A = SRP.Surf; Cr = SRP.Cr; S = SRP.S; c = SRP.c;
    
    c20 = grav.c20;  c21 = grav.c21;  c22 = grav.c22;  c30 = grav.c30;  c31 = grav.c31; 
    c32 = grav.c32;  c33 = grav.c33;  
    s21 = grav.s21;  s22 = grav.s22;  s31 = grav.s31;  s32 = grav.s32;  s33 = grav.s33;
    
    r = y(1:3); v = y(4:6);

    %Compute gravity perturbation in ECEF up to order 3,3 (derivatives taken in symbolic)

    g = 0;  % sidereal angle set to 0
    x = r(1); y = r(2); z = r(3);
    l = atan2(y, x);
    phi = atan2(z, sqrt(x.^2 + y.^2));
    rho = sqrt(x.^2 + y.^2 + z.^2);
    

%     aPg_x = (3*R^2*c22*mu*(2*x*cos(2*g) + 2*y*sin(2*g)))/(x^2 + y^2 + z^2)^(5/2) - (R^2*c20*mu*x)/(x^2 + y^2 + z^2)^(5/2) + (3*R^2*mu*s22*(2*y*cos(2*g) - 2*x*sin(2*g)))/(x^2 + y^2 + z^2)^(5/2) + (15*R^3*c33*mu*(2*x + 8*sin(g)*(y*cos(g) - x*sin(g)))*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*mu*s33*(2*x - 8*cos(g)*(x*cos(g) + y*sin(g)))*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*c32*mu*z*(2*x*cos(2*g) + 2*y*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) + (R^3*mu*s31*sin(g)*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) - (3*R^3*c30*mu*x*z)/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*mu*s32*z*(2*y*cos(2*g) - 2*x*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (3*R^3*c31*mu*x*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (3*R^3*mu*s31*x*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) + (3*R^2*c21*mu*z*cos(g))/(x^2 + y^2 + z^2)^(5/2) + (15*R^3*c33*mu*cos(g)*(x^2 - 4*(y*cos(g) - x*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(7/2) - (15*R^2*c22*mu*x*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (3*R^2*mu*s21*z*sin(g))/(x^2 + y^2 + z^2)^(5/2) + (15*R^2*mu*s22*x*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (15*R^3*mu*s33*sin(g)*(x^2 - 4*(x*cos(g) + y*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(7/2) + (5*R^2*c20*mu*x*(x^2 + y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) - (R^3*c31*mu*cos(g)*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) + (105*R^3*mu*s32*x*z*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(9/2) + (7*R^3*c30*mu*x*z*(3*x^2 + 3*y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) + (7*R^3*c31*mu*x*(x*cos(g) + y*sin(g))*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) + (7*R^3*mu*s31*x*(y*cos(g) - x*sin(g))*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) - (15*R^2*c21*mu*x*z*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (105*R^3*c33*mu*x*(x*cos(g) + y*sin(g))*(x^2 - 4*(y*cos(g) - x*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(9/2) - (15*R^2*mu*s21*x*z*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (105*R^3*mu*s33*x*(y*cos(g) - x*sin(g))*(x^2 - 4*(x*cos(g) + y*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(9/2) - (105*R^3*c32*mu*x*z*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(9/2);
%     aPg_y = (3*R^2*mu*s22*(2*x*cos(2*g) + 2*y*sin(2*g)))/(x^2 + y^2 + z^2)^(5/2) - (R^2*c20*mu*y)/(x^2 + y^2 + z^2)^(5/2) - (3*R^2*c22*mu*(2*y*cos(2*g) - 2*x*sin(2*g)))/(x^2 + y^2 + z^2)^(5/2) - (R^3*c31*mu*sin(g)*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) - (R^3*mu*s31*cos(g)*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) + (15*R^3*mu*s33*(2*y - 8*sin(g)*(x*cos(g) + y*sin(g)))*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (15*R^3*c32*mu*z*(2*y*cos(2*g) - 2*x*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (3*R^3*c30*mu*y*z)/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*mu*s32*z*(2*x*cos(2*g) + 2*y*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (3*R^3*c31*mu*y*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (3*R^3*mu*s31*y*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) + (3*R^2*c21*mu*z*sin(g))/(x^2 + y^2 + z^2)^(5/2) + (3*R^2*mu*s21*z*cos(g))/(x^2 + y^2 + z^2)^(5/2) - (15*R^2*c22*mu*y*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*c33*mu*sin(g)*(x^2 - 4*(y*cos(g) - x*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*mu*s33*cos(g)*(x^2 - 4*(x*cos(g) + y*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(7/2) + (15*R^2*mu*s22*y*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(7/2) + (5*R^2*c20*mu*y*(x^2 + y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) + (15*R^3*c33*mu*(2*y - 8*cos(g)*(y*cos(g) - x*sin(g)))*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) + (105*R^3*mu*s32*y*z*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(9/2) + (7*R^3*c30*mu*y*z*(3*x^2 + 3*y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) + (7*R^3*c31*mu*y*(x*cos(g) + y*sin(g))*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) + (7*R^3*mu*s31*y*(y*cos(g) - x*sin(g))*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) - (15*R^2*c21*mu*y*z*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (105*R^3*c33*mu*y*(x*cos(g) + y*sin(g))*(x^2 - 4*(y*cos(g) - x*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(9/2) - (15*R^2*mu*s21*y*z*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (105*R^3*mu*s33*y*(y*cos(g) - x*sin(g))*(x^2 - 4*(x*cos(g) + y*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(9/2) - (105*R^3*c32*mu*y*z*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(9/2);
%     aPg_z = (2*R^3*c30*mu*z^2)/(x^2 + y^2 + z^2)^(7/2) + (15*R^3*c32*mu*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (15*R^3*mu*s32*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (R^3*c30*mu*(3*x^2 + 3*y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) + (2*R^2*c20*mu*z)/(x^2 + y^2 + z^2)^(5/2) + (3*R^2*c21*mu*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(5/2) + (3*R^2*mu*s21*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(5/2) + (7*R^3*c30*mu*z^2*(3*x^2 + 3*y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) + (12*R^3*c31*mu*z*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) + (12*R^3*mu*s31*z*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (15*R^2*c22*mu*z*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(7/2) + (15*R^2*mu*s22*z*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(7/2) - (15*R^2*c21*mu*z^2*(x*cos(g) + y*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (15*R^2*mu*s21*z^2*(y*cos(g) - x*sin(g)))/(x^2 + y^2 + z^2)^(7/2) - (105*R^3*c32*mu*z^2*(cos(2*g)*(x^2 - y^2) + 2*x*y*sin(2*g)))/(x^2 + y^2 + z^2)^(9/2) + (5*R^2*c20*mu*z*(x^2 + y^2 - 2*z^2))/(2*(x^2 + y^2 + z^2)^(7/2)) + (105*R^3*mu*s32*z^2*(sin(2*g)*(x^2 - y^2) - 2*x*y*cos(2*g)))/(x^2 + y^2 + z^2)^(9/2) + (7*R^3*c31*mu*z*(x*cos(g) + y*sin(g))*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) + (7*R^3*mu*s31*z*(y*cos(g) - x*sin(g))*(3*x^2 + 3*y^2 - 12*z^2))/(2*(x^2 + y^2 + z^2)^(9/2)) - (105*R^3*c33*mu*z*(x*cos(g) + y*sin(g))*(x^2 - 4*(y*cos(g) - x*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(9/2) - (105*R^3*mu*s33*z*(y*cos(g) - x*sin(g))*(x^2 - 4*(x*cos(g) + y*sin(g))^2 + y^2))/(x^2 + y^2 + z^2)^(9/2);


    aPg_r = -mu*((3*R^2*c20*(3*sin(phi)^2 - 1))/(2*rho^4) + ...
            (9*R^2*cos(phi)^2*(s22*sin(2*l) + c22*cos(2*l)))/rho^4 + ...
            (60*R^3*cos(phi)^3*(s33*sin(3*l) + c33*cos(3*l)))/rho^5 + ...
            (2*R^3*c30*sin(phi)*(5*sin(phi)^2 - 3))/rho^5 + ...
            (9*R^2*cos(phi)*sin(phi)*(c21*cos(l) + s21*sin(l)))/rho^4 + ...
            (60*R^3*cos(phi)^2*sin(phi)*(s32*sin(2*l) + c32*cos(2*l)))/rho^5 + ...
            (2*R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/rho^5);
 


 
    aPg_l =  -mu*((3*R^2*cos(phi)^2*(2*c22*sin(2*l) - 2*s22*cos(2*l)))/rho^3 + ...
             (15*R^3*cos(phi)^3*(3*c33*sin(3*l) - 3*s33*cos(3*l)))/rho^4 + ...
             (3*R^2*cos(phi)*sin(phi)*(c21*sin(l) - s21*cos(l)))/rho^3 + ...
             (15*R^3*cos(phi)^2*sin(phi)*(2*c32*sin(2*l) - 2*s32*cos(2*l)))/rho^4 + ...
             (R^3*cos(phi)*(15*sin(phi)^2 - 3)*(c31*sin(l) - s31*cos(l)))/(2*rho^4));
 

 
    aPg_phi = mu*((15*R^3*cos(phi)^3*(s32*sin(2*l) + c32*cos(2*l)))/rho^4 + ...
              (3*R^2*cos(phi)^2*(c21*cos(l) + s21*sin(l)))/rho^3 - ...
              (3*R^2*sin(phi)^2*(c21*cos(l) + s21*sin(l)))/rho^3 + ...
              (R^3*c30*cos(phi)*(5*sin(phi)^2 - 3))/(2*rho^4) - ...
              (30*R^3*cos(phi)*sin(phi)^2*(s32*sin(2*l) + c32*cos(2*l)))/rho^4 - ...
              (45*R^3*cos(phi)^2*sin(phi)*(s33*sin(3*l) + c33*cos(3*l)))/rho^4 + ...
              (5*R^3*c30*cos(phi)*sin(phi)^2)/rho^4 - ...
              (R^3*sin(phi)*(15*sin(phi)^2 - 3)*(c31*cos(l) + s31*sin(l)))/(2*rho^4) + ...
              (15*R^3*cos(phi)^2*sin(phi)*(c31*cos(l) + s31*sin(l)))/rho^4 - ...
              (6*R^2*cos(phi)*sin(phi)*(s22*sin(2*l) + c22*cos(2*l)))/rho^3 + ...
              (3*R^2*c20*cos(phi)*sin(phi))/rho^3);


    R = [cos(phi)*cos(l)  cos(phi)*sin(l)  sin(phi)    %rotation spherical/cartesian (wiki)
         -sin(l)          cos(l)           0
         -sin(phi)*cos(l) -sin(phi)*sin(l) cos(phi)];

    aPg = R' * [aPg_r; aPg_l/(rho*cos(phi)); aPg_phi/rho];

%     aPg = [aPg_x; aPg_y; aPg_z];
    
    %Compute moon and sun perturbation in ECEF
    tdays = t/24/3600;     % time in days
    MJD2000 = tdays;

    ecl = [1 0 0; 0 cos(23.45) sin(23.45); 0 -sin(23.45) cos(23.45)];
    [kep, ~] = uplanet(MJD2000, 3);
    [r_E, ~] = kp2rv(kep(1), kep(2), kep(3), kep(4), kep(5), kep(6), muS);
    r_S = - r_E;
    r_S = ecl * r_S; 
    
%     [r_S, ~, ~] = solar_position(MJD2000);
%     [r_M, ~] = ephMoon(MJD2000);
    r_M = lunar_position(MJD2000);
    r_Ms = r_M' - r; 
    r_Ss = r_S - r;
    
%     aS = muS/norm(r_Ss)^3*((1 - norm(r_Ss)^3 /norm(r_S)^3)*r_S - r);
%     aM = muM*(r_Ms/norm(r_Ms)^3 - r_M'/norm(r_M)^3);
    
    aS = muS*(r_Ss/(norm(r_Ss))^3 - r_S /(norm(r_S))^3);
    aM = muM*(r_Ms/(norm(r_Ms))^3 - r_M'/(norm(r_M))^3);

    %Compute SRP
    xs = r_S(1); ys = r_S(2); zs = r_S(3);
    nu = eclipse(r, r_S, R);              % = 0 or = 1 if in shadow or in light respectively 
    Psr = nu *S/c*Cr * A/m;               % perturbing acceleration F/m 
      
    aSRP = -Psr*(r_Ss./norm(r_Ss)); 

%     aPsrp_x = -(Psr*(2*x - 2*xs))/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(1/2));
%     aPsrp_y = -(Psr*(2*y - 2*ys))/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(1/2));
%     aPsrp_z = -(Psr*(2*z - 2*zs))/(2*((x - xs)^2 + (y - ys)^2 + (z - zs)^2)^(1/2));
   
%     aSRP = [aPsrp_x; aPsrp_y; aPsrp_z];


    % Cartesian Dynamics
    dy = [v; (-mu/norm(r)^3)*r + aPg + aM + aS + aSRP];

end 


function  [r_S, lamda, eps] = solar_position(jd)
    % This function calculates the geocentric equatorial position vector
    % of the sun, given the Julian date.
    
    AU = 149597870.691;
    
    %...Julian days since J2000:
    n = jd - 2451545;
    
    %...Julian centuries since J2000:
    cy = n/36525;
    
    %...Mean anomaly (deg{:
    M = 357.528 + 0.9856003*n;
    M = mod(M,360);
    
    %...Mean longitude (deg):
    L = 280.460 + 0.98564736*n;
    L = mod(L,360);
    
    %...Apparent ecliptic longitude (deg):
    lamda = L + 1.915*sind(M) + 0.020*sind(2*M);
    lamda = mod(lamda,360);
    
    %...Obliquity of the ecliptic (deg):
    eps = 23.439 - 0.0000004*n;
    
    %...Unit vector from earth to sun:
    u = [cosd(lamda); sind(lamda)*cosd(eps); sind(lamda)*sind(eps)];
    
    %...Distance from earth to sun (km):
    rS = (1.00014 - 0.01671*cosd(M) - 0.000140*cosd(2*M))*AU;
    
    %...Geocentric position vector (equatorial)(km):
    r_S = rS*u;

end 


function r_M = lunar_position(jd2000)
    %...Calculates the geocentric equatorial position vector of the moon
    % given the Julian day.
    
    %...Earth’s radius (km):
    Re = 6378.137;
    
    %...Time in centuries since J2000:
    T = (jd2000)/36525;
    
    %...Ecliptic longitude (deg):
    e_long = 218.32 + 481267.881*T +...
     6.29*sind(135.0 + 477198.87*T) - 1.27*sind(259.3 - 413335.36*T) +...
     0.66*sind(235.7 + 890534.22*T) + 0.21*sind(269.9 + 954397.74*T) -...
     0.19*sind(357.5 + 35999.05*T) - 0.11*sind(186.5 + 966404.03*T);
    
    e_long = mod(e_long,360);
    
    %...Ecliptic latitude (deg):
    e_lat = 5.13*sind( 93.3 + 483202.02*T) + 0.28*sind(228.2 + 960400.89*T)-...
    0.28*sind(318.3 + 6003.15*T) - 0.17*sind(217.6 - 407332.21*T);
    
    e_lat = mod(e_lat,360);
    
    %...Horizontal parallax (deg):
    h_par = 0.9508 +...
     0.0518*cosd(135.0 + 477198.87*T) + 0.0095*cosd(259.3 - 413335.36*T)+...
     0.0078*cosd(235.7 + 890534.22*T) + 0.0028*cosd(269.9 + 954397.74*T);
    
    h_par = mod(h_par,360);
    
    %...Angle between earth’s orbit and its equator (deg):
    obliquity = 23.439291 - 0.0130042*T;
    
    %...Direction cosines of the moon’s geocentric equatorial position vector:
    l = cosd(e_lat) * cosd(e_long);
    m = cosd(obliquity)*cosd(e_lat)*sind(e_long) - sind(obliquity)*sind(e_lat);
    n = sind(obliquity)*cosd(e_lat)*sind(e_long) + cosd(obliquity)*sind(e_lat);
    
    %...Earth-moon distance (km):
    dist = Re/sind(h_par);
    
    %...Moon’s geocentric equatorial position vector (km):
    r_M = dist*[l m n];

end


function [RA, dec] = RaDec(cart_pos)
    r = sqrt(cart_pos(1)^2 + cart_pos(2)^2 + cart_pos(3)^2);
    l = cart_pos(1)/r;  m = cart_pos(2)/r; n = cart_pos(3)/r; 
    dec = asin(n); 
    
    if m > 0 
        RA = acos(l/cos(dec)); 
    else 
        RA = 2*pi - acos(l/cos(dec)); 
    end 

end 


function nu = eclipse(r, r_S, RE)

    rr = norm(r); 
    rs = norm(r_S); 
    theta = acos(dot(r_S, r)/(rr*rs)); 
    theta1 = acos(RE/rr);  theta2 = acos(RE/rs); 

    if (theta1 + theta2) <= theta 
        nu = 0; 
    else 
        nu = 1; 
    end 

end


function plot_earth(Re)

    TERRA=imread('planisphere.jpg','jpg');
    props.FaceColor='texture';
    props.EdgeColor='none';
    props.FaceLighting='phong';
    props.Cdata=TERRA;
    C=[0;0;0];
    [XX,YY,ZZ]=ellipsoid(C(1),C(2),C(3),Re,Re,Re,1000);
    surface(-XX,-YY,-ZZ,props,'HandleVisibility','off');

end
