# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 10:13:42 2022

@author: stesi
"""
 
import daceypy_import_helper  # noqa: F401

from math import ceil
from time import perf_counter
from typing import Callable

import numpy as np
from daceypy import DA, array




def TBP(x: array, t: float) -> array:   # defines x vector of states as a DA array by calling function array
    mu = 398600
    pos: array = x[:3]
    vel: array = x[3:]
    r = pos.vnorm()
    acc = -mu * pos / (r ** 3)
    dx = vel.concat(acc)
    return dx



def euler(x: array, t0: float, t1: float) -> array:  #SET another integrator   (RK 8 i.e.)
    hmax = 1
    steps = ceil((t1 - t0) / hmax)
    h = (t1 - t0) / steps
    t = t0

    x = x.copy()
    
    for _ in range(steps):
        x += h * TBP(x, t)
        t += h

    return x



def rk4(x: array, dx0: array, t0: float, t1: float):

    hmax = 0.1
    steps = ceil((t1 - t0) / hmax)
    h = (t1 - t0) / steps
    t = t0
    
    x = x.copy()
    state = [ ]; state_pert = [ ]
    state.append(x.cons()); state_pert.append(x.cons() + dx0)
    
    for _ in range(steps):
        k1 = TBP(x, t)
        k2 = TBP(x + h*k1/3.0, t + h/3.0)
        k3 = TBP(x + h*(-k1/3.0 + k2), t + 2.0*h/3.0)
        k4 = TBP(x + h*(k1 - k2 + k3), t + h)
    
        x = x + h * (k1 + 3*k2 + 3*k3 + k4)/8.0
        t += h
        state.append(x.cons())
        state_pert.append(x.eval(dx0))
        
    #     fp = open('x.txt', 'a')
    #     fp.write(str(x.cons()))
    #     fp.close()
        
    # fp.close() 
    np.savetxt('x.txt', state, fmt='%f')
    np.savetxt('x_pert.txt', state_pert, fmt='%f')
    
    return x, state, state_pert



def rk8(x: array, t0: float, t1: float):

    hmax = 1
    steps = ceil((t1 - t0) / hmax)
    h = (t1 - t0) / steps
    t = t0
    
    x = x.copy()
    
    for _ in range(steps):
        k1 =  TBP(x,                                                                                    t             )
        k2 =  TBP(x + (h*4/27)*k1,                                                                      t + h*(4/27)  )
        k3 =  TBP(x + (h/18)*(k1 + 3*k2),                                                               t + h*(2/9)   )
        k4 =  TBP(x + (h/12)*(k1 + 3*k3),                                                               t + h*(1/3)   )
        k5 =  TBP(x + (h/8)*(k1 + 3*k4),                                                                t + h*(1/2)   )
        k6 =  TBP(x + (h/54)*(13*k1 - 27*k3 + 42*k4 + 8*k5),                                            t + h*(2/3)   )
        k7 =  TBP(x + (h/4320)*(389*k1 - 54*k3 + 966*k4 - 824*k5 + 243*k6),                             t + h*(1/6)   )
        k8 =  TBP(x + (h/20)*(-234*k1 + 81*k3 - 1164*k4 + 656*k5 - 122*k6 + 800*k7),                    t + h         )
        k9 =  TBP(x + (h/288)*(-127*k1 + 18*k3 - 678*k4 + 456*k5 - 9*k6 + 576*k7 + 4*k8),               t + h*(5/6)   )
        k10 = TBP(x + (h/820)*(1481*k1 - 81*k3 + 7104*k4 - 3376*k5 + 72*k6 - 5040*k7 - 60*k8 + 720*k9), t + h         )
        
        x = x + h/840*(41*k1 + 27*k4 + 272*k5 + 27*k6 + 216*k7 + 216*k9 + 41*k10);
        t += h

    return x


# % RELATIVE MOTION OPTIMAL CONTROL PROBLEM



def TBP_rendezvous(dyn: array, t: float) -> array:   # defines x vector of states as a DA array by calling function array

    x = dyn[0]; y = dyn[1];  
    vx = dyn[2]; vy = dyn[3];
    lx = dyn[4]; ly = dyn[5]; 
    lvx = dyn[6]; lvy = dyn[7]; 
    
    r = array.sqrt((1 + x)**2 + y**2)
    
    ddyn = array.identity(8)
    
    ddyn[0] = vx
    ddyn[1] = vy
    ddyn[2] = 2*vy - (1 + x)*(1/r**3 - 1) - lvx 
    ddyn[3] = -2*vx - y*(1/r**3 -1) - lvy
    
    
    ddyn[4] = - lvx*((3*(2*x + 2)*(x + 1))/(2*((x + 1)**2 + y**2)**(5/2)) - 1/((x + 1)**2 + y**2)**(3/2) + 1) - (3*lvy*y*(2*x + 2))/(2*((x + 1)**2 + y**2)**(5/2)); 
    ddyn[5] = - lvy*((3*y**2)/((x + 1)**2 + y**2)**(5/2) - 1/((x + 1)**2 + y**2)**(3/2) + 1) - (3*lvx*y*(x + 1))/((x + 1)**2 + y**2)**(5/2);  
    ddyn[6] =   2*lvy - lx;
    ddyn[7] = - 2*lvx - ly;


    return ddyn

def rk4_rendezvous(x: array, t0: float, t1: float):

    hmax = 0.001
    steps = ceil((t1 - t0) / hmax)
    h = (t1 - t0) / steps
    t = t0
    
    x = x.copy()
    
    for _ in range(steps):
        k1 = TBP_rendezvous(x, t)
        k2 = TBP_rendezvous(x + h*k1/3.0, t + h/3.0)
        k3 = TBP_rendezvous(x + h*(-k1/3.0 + k2), t + 2.0*h/3.0)
        k4 = TBP_rendezvous(x + h*(k1 - k2 + k3), t + h)
    
        x = x + h * (k1 + 3*k2 + 3*k3 + k4)/8.0
        t += h
        
    return x

def RK78(Y0: array, X0: float, X1: float, f: Callable[[array, float], array]):

    Y0 = Y0.copy()

    N = len(Y0)

    H0 = 0.001
    HS = 0.1
    H1 = 100.0
    EPS = 1.e-12
    BS = 20 * EPS

    Z = array.zeros((N, 16))
    Y1 = array.zeros(N)

    VIHMAX = 0.0

    HSQR = 1.0 / 9.0
    A = np.zeros(13)
    B = np.zeros((13, 12))
    C = np.zeros(13)
    D = np.zeros(13)

    A = np.array([
        0.0, 1.0/18.0, 1.0/12.0, 1.0/8.0, 5.0/16.0, 3.0/8.0, 59.0/400.0,
        93.0/200.0, 5490023248.0/9719169821.0, 13.0/20.0,
        1201146811.0/1299019798.0, 1.0, 1.0,
    ])

    B[1, 0] = 1.0/18.0
    B[2, 0] = 1.0/48.0
    B[2, 1] = 1.0/16.0
    B[3, 0] = 1.0/32.0
    B[3, 2] = 3.0/32.0
    B[4, 0] = 5.0/16.0
    B[4, 2] = -75.0/64.0
    B[4, 3] = 75.0/64.0
    B[5, 0] = 3.0/80.0
    B[5, 3] = 3.0/16.0
    B[5, 4] = 3.0/20.0
    B[6, 0] = 29443841.0/614563906.0
    B[6, 3] = 77736538.0/692538347.0
    B[6, 4] = -28693883.0/1125000000.0
    B[6, 5] = 23124283.0/1800000000.0
    B[7, 0] = 16016141.0/946692911.0
    B[7, 3] = 61564180.0/158732637.0
    B[7, 4] = 22789713.0/633445777.0
    B[7, 5] = 545815736.0/2771057229.0
    B[7, 6] = -180193667.0/1043307555.0
    B[8, 0] = 39632708.0/573591083.0
    B[8, 3] = -433636366.0/683701615.0
    B[8, 4] = -421739975.0/2616292301.0
    B[8, 5] = 100302831.0/723423059.0
    B[8, 6] = 790204164.0/839813087.0
    B[8, 7] = 800635310.0/3783071287.0
    B[9, 0] = 246121993.0/1340847787.0
    B[9, 3] = -37695042795.0/15268766246.0
    B[9, 4] = -309121744.0/1061227803.0
    B[9, 5] = -12992083.0/490766935.0
    B[9, 6] = 6005943493.0/2108947869.0
    B[9, 7] = 393006217.0/1396673457.0
    B[9, 8] = 123872331.0/1001029789.0
    B[10, 0] = -1028468189.0/846180014.0
    B[10, 3] = 8478235783.0/508512852.0
    B[10, 4] = 1311729495.0/1432422823.0
    B[10, 5] = -10304129995.0/1701304382.0
    B[10, 6] = -48777925059.0/3047939560.0
    B[10, 7] = 15336726248.0/1032824649.0
    B[10, 8] = -45442868181.0/3398467696.0
    B[10, 9] = 3065993473.0/597172653.0
    B[11, 0] = 185892177.0/718116043.0
    B[11, 3] = -3185094517.0/667107341.0
    B[11, 4] = -477755414.0/1098053517.0
    B[11, 5] = -703635378.0/230739211.0
    B[11, 6] = 5731566787.0/1027545527.0
    B[11, 7] = 5232866602.0/850066563.0
    B[11, 8] = -4093664535.0/808688257.0
    B[11, 9] = 3962137247.0/1805957418.0
    B[11, 10] = 65686358.0/487910083.0
    B[12, 0] = 403863854.0/491063109.0
    B[12, 3] = - 5068492393.0/434740067.0
    B[12, 4] = -411421997.0/543043805.0
    B[12, 5] = 652783627.0/914296604.0
    B[12, 6] = 11173962825.0/925320556.0
    B[12, 7] = -13158990841.0/6184727034.0
    B[12, 8] = 3936647629.0/1978049680.0
    B[12, 9] = -160528059.0/685178525.0
    B[12, 10] = 248638103.0/1413531060.0

    C = np.array([
        14005451.0/335480064.0, 0.0, 0.0, 0.0, 0.0, -59238493.0/1068277825.0,
        181606767.0/758867731.0, 561292985.0/797845732.0,
        -1041891430.0/1371343529.0, 760417239.0/1151165299.0,
        118820643.0/751138087.0, -528747749.0/2220607170.0, 1.0/4.0,
    ])

    D = np.array([
        13451932.0/455176623.0, 0.0, 0.0, 0.0, 0.0, -808719846.0/976000145.0,
        1757004468.0/5645159321.0, 656045339.0/265891186.0,
        -3867574721.0/1518517206.0, 465885868.0/322736535.0,
        53011238.0/667516719.0, 2.0/45.0, 0.0,
    ])

    Z[:, 0] = Y0

    H = abs(HS)
    HH0 = abs(H0)
    HH1 = abs(H1)
    X = X0
    RFNORM = 0.0
    ERREST = 0.0

    while X != X1:

        # compute new stepsize
        if RFNORM != 0:
            H = H * min(4.0, np.exp(HSQR * np.log(EPS / RFNORM)))
        if abs(H) > abs(HH1):
            H = HH1
        elif abs(H) < abs(HH0) * 0.99:
            H = HH0
            print("--- WARNING, MINIMUM STEPSIZE REACHED IN RK")

        if (X + H - X1) * H > 0:
            H = X1 - X

        for j in range(13):

            for i in range(N):

                Y0[i] = 0.0
                # EVALUATE RHS AT 13 POINTS
                for k in range(j):
                    Y0[i] = Y0[i] + Z[i, k + 3] * B[j, k]

                Y0[i] = H * Y0[i] + Z[i, 0]

            Y1 = f(Y0, X + H * A[j])

            for i in range(N):
                Z[i, j + 3] = Y1[i]

        for i in range(N):

            Z[i, 1] = 0.0
            Z[i, 2] = 0.0
            # EXECUTE 7TH,8TH ORDER STEPS
            for j in range(13):
                Z[i, 1] = Z[i, 1] + Z[i, j + 3] * D[j]
                Z[i, 2] = Z[i, 2] + Z[i, j + 3] * C[j]

            Y1[i] = (Z[i, 2] - Z[i, 1]) * H
            Z[i, 2] = Z[i, 2] * H + Z[i, 0]

        Y1cons = Y1.cons()

        # ESTIMATE ERROR AND DECIDE ABOUT BACKSTEP
        RFNORM = np.linalg.norm(Y1cons, np.inf)  # type: ignore
        if RFNORM > BS and abs(H / H0) > 1.2:
            H = H / 3.0
            RFNORM = 0
        else:
            for i in range(N):
                Z[i, 0] = Z[i, 2]
            X = X + H
            VIHMAX = max(VIHMAX, H)
            ERREST = ERREST + RFNORM

    Y1 = Z[:, 0]

    return Y1


# main():

exp_order = 1
DA.init(exp_order, 8)
# Q = 100                     #coefficient for Bcs map 

# Set initial conditions
Xi = array.identity(8)       # initialize state + costate augmented vector 
Xi[0] += 0                   # tutti zero per espansione . inizializzarla con coefficienti davanti a DA
Xi[1] += 0 
Xi[2] += 0 
Xi[3] += 0 
Xi[4] += 0
Xi[5] += 0
Xi[6] += 0
Xi[7] += 0

 
Xf_ref = array.zeros(4)                                      # reference position and velocity  at final conditions
Xf_ref[0] += 0.0
Xf_ref[1] += 0.0
Xf_ref[2] += 0.0
Xf_ref[3] += 0.0
                    

time = 1                                        # adimensional time unit

# COMPUTE exact solution using simple shooting tecnique ......



# Compute final state given perturbed initial state 
T0 = perf_counter()       # time required for integration.. elapsed time 
with DA.cache_manager():  # optional, for efficiency
        Xf = RK78(Xi, 0.0, time, TBP_rendezvous)
T1 = perf_counter()

#print(str(Xf))
# print(f'{Xf. cons()}')

# print(f'{Xf.linear()}')
print(f"Info: time required for integration = {T1 - T0} s")


# BUILD MAP OF DEFECTS AND INVERT THE POL TO FIND Dlambdai

LambdaF = Xf[4:8] 

# Q = np.array([10,0,10,10])
C = (Xf[:4] - Xf_ref) #- LambdaF   # Map of DEFECTS on final state  (Wanted final state is 0)

I = array.identity(4)

M_dir = C.concat(I)

M_dir = M_dir - M_dir.cons()

M_inv = M_dir.invert()

cval = - C.cons()


F = np.array([cval[0], cval[1], cval[2], cval[3], 0.2, 0.2, 0.1, 0.1])       # set final constraint = 0 to match pos and vel, concatenated with initial perturbed pos and vel 

Initial_conditions = (M_inv + M_dir.cons()).eval(F)
print(f"Delta initial conditions:\n{(M_inv + M_dir.cons()).eval(F)}\n")

LAMBDA0 = Initial_conditions[4:]

np.savetxt('LAMBDA0_1st.txt', LAMBDA0, fmt='%.16f')







                 


























