clearvars; close all; clc;

% Compute costate dynamics   --- set symbolic coordinates 
syms x y vx vy lx ly lvx lvy 

% Set state dynamics
r = sqrt((1 + x)^2 + y^2); 
dx = vx; 
dy = vy; 
ddx =  2*vy - (1 + x) * (1/r^3 - 1) - lvx;
ddy = -2*vx -      y  * (1/r^3 - 1) - lvy;

DfDx = jacobian([dx; dy; ddx; ddy], [x, y, vx, vy]); 
DfDx_transpose = DfDx.'; 
Dlambda = - DfDx_transpose*[lx; ly; lvx; lvy]; 



% fid = fopen('cost_dynamics.txt', 'wt'); 
% fprintf(fid, '%s\n', char(Dlambda)); 
% fclose(fid); 