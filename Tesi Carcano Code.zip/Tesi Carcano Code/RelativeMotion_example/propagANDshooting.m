clearvars; close all; clc;


%% SETUP

t = 1;  % expansion time (adimensionalized)
r0 = [0.2; 0.2];    v0 = [0.1; 0.1];   
rf = [0; 0];    vf = [0; 0];

%% Relative Motion shooting  
% Initial data (units of measure must be consistent)
dat.final = [rf; vf]; dat.x0 = [r0; v0]; 

dat.T = t;
lambda0 = [0; 0; 0; 0]; 
z0 = lambda0; 

% fsolve options
options_fsolve = optimoptions(@fsolve,'Maxiter', 1000,'FunctionTolerance', 1e-12, 'StepTolerance',1e-12);

% fsolve call-- O = output, contains final time and initial conditions for
% lambda_r, lambda_v
O = fsolve(@opt_solv, z0, options_fsolve, dat);

% Propagation to compute state(r,v) and costate(lambda_r, lambda_v,
% lambda_m) evolution from initial to final time
options = odeset('reltol', 1e-12, 'abstol', 1e-12);
[~, ys] = ode78(@(t, dyn) TBP_rendezvous(t, dyn), [0  dat.T], [dat.x0; O], options);




%% Propagation DACE solution(s)

% Initial vector 
x0 = [r0; v0]; 

Dl0_1st = importdata('LAMBDA0_1st.txt');   % solution from python DACE
Dl0_4th = importdata('LAMBDA0_4th.txt');
Dl0_6th = importdata('LAMBDA0_6th.txt');
Lambda01 = lambda0 + Dl0_1st;
Lambda04 = lambda0 + Dl0_4th;
Lambda06 = lambda0 + Dl0_6th;

 
x_aug0_1 = [x0; Lambda01];
x_aug0_4 = [x0; Lambda04];
x_aug0_6 = [x0; Lambda06];

% Final time 
tf = t; 

% Dynamics 

options = odeset('reltol', 1e-12, 'abstol', 1e-12);
[~, y1] = ode78(@(t,y) TBP_rendezvous(t, y), [0;  tf], x_aug0_1, options);
[~, y4] = ode78(@(t,y) TBP_rendezvous(t, y), [0;  tf], x_aug0_4, options);
[~, y6] = ode78(@(t,y) TBP_rendezvous(t, y), [0;  tf], x_aug0_6, options);


% Plot
figure()
plot(ys(1,3),ys(1,4),'sr', 'LineWidth', 2)
hold on
plot(ys(end,3),ys(end,4),'or', 'LineWidth', 2)
plot(ys(:,3),ys(:,4),'-r', 'LineWidth', 2)
plot(y1(:,3),y1(:,4),'--k')
plot(y4(:,3),y4(:,4),'-.k')
plot(y6(:,3),y6(:,4),'-k')
xlabel('v_{x}'); ylabel('v_{y}')
legend('start', 'end', 'shooting', 'linear', '4th order', '6th order')
grid on;

figure()
plot(ys(1,1), ys(1,1),'sr', 'LineWidth', 2)
hold on
plot(ys(end,2), ys(end,2),'or', 'LineWidth', 2)
plot(ys(:,1),ys(:,2),'-r', 'LineWidth', 1.5)
plot(y1(:,1),y1(:,2),'--k')
plot(y4(:,1),y4(:,2),'-.k')
plot(y6(:,1),y6(:,2),'-k')
xlabel('x'); ylabel('y')
legend('start', 'end', 'shooting', 'linear', '4th order', '6th order')
grid on;

figure()
plot(-ys(1,7), -ys(1,8),'sr', 'LineWidth', 2)
hold on
plot(-ys(end,7), -ys(end,8),'or', 'LineWidth', 2)
plot(-ys(:,7), -ys(:,8),'-r', 'LineWidth', 1.5)
plot(-y1(:,7), -y1(:,8),'--k')
plot(-y4(:,7), -y4(:,8),'-.k')
plot(-y6(:,7), -y6(:,8),'-k')
xlabel('u_{x}'); ylabel('u_{y}')
legend('start', 'end', 'shooting', 'linear', '4th order', '6th order')
grid on;

% figure()
% plot(-ys(1,5), -ys(1,6),'sr', 'LineWidth', 2)
% hold on
% plot(-ys(end,5), -ys(end,6),'or', 'LineWidth', 2)
% plot(-ys(:,5), -ys(:,6),'-r', 'LineWidth', 1.5)
% plot(-y1(:,5), -y1(:,6),'--k') 
% plot(-y4(:,5), -y4(:,6),'-.k')
% plot(-y6(:,5), -y6(:,6),'-k')
% xlabel('$\lambda_{1}$', 'interpreter', 'latex'); ylabel('$\lambda_{2}$', 'interpreter', 'latex')
% legend('start', 'end', 'shooting', 'linear', '4th order', '6th order')
% grid on;


%% FUnctions 

function dy = TBP_rendezvous(~, dyn)
    

    dy = zeros(8,1);

    % state and costate evolution for integration 
    x = dyn(1);   y = dyn(2);   vx  = dyn(3);  vy  = dyn(4);  
    lx = dyn(5);  ly = dyn(6);  lvx = dyn(7);  lvy = dyn(8); 
    
    r = sqrt((1 + x)^2 + y^2); 
    
    dy(1) = vx;
    dy(2) = vy;
    dy(3) =  2*vy - (1 + x)*(1/r^3 - 1) - lvx;
    dy(4) = -2*vx - y*(1/r^3 - 1)       - lvy;
    dy(5) = - lvx*((3*(2*x + 2)*(x + 1))/(2*((x + 1)^2 + y^2)^(5/2)) - 1/((x + 1)^2 + y^2)^(3/2) + 1) - (3*lvy*y*(2*x + 2))/(2*((x + 1)^2 + y^2)^(5/2)); 
    dy(6) = - lvy*((3*y^2)/((x + 1)^2 + y^2)^(5/2) - 1/((x + 1)^2 + y^2)^(3/2) + 1) - (3*lvx*y*(x + 1))/((x + 1)^2 + y^2)^(5/2);  
    dy(7) = 2*lvy - lx;
    dy(8) = - 2*lvx - ly;
 



end

function f = opt_solv(z, dat)
    xf = dat.final; x0 = dat.x0; 
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    initial = [x0; z]; 
    [~, xx] = ode78(@(t,dyn) TBP_rendezvous(t, dyn), [0, dat.T], initial, options);
    f = [xx(end,1)'-xf(1); xx(end,2)'-xf(2); xx(end,3)'-xf(3); xx(end,4)'-xf(4)];
end
