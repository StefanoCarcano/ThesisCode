import daceypy_import_helper  # noqa: F401

from daceypy import DA
import numpy as np
from matplotlib import pyplot as pp


# initialize DACE for 20th-order computations in 1 variable
DA.init(20, 1)

# initialize x as DA
x0 = 0
x = x0 + DA(1)

# compute y = sin(x)
y = x.sin()

# print x and y to screen
print("x\n" + str(x) + "\n")
print("y = sin(x)\n" + str(y) + "\n")

def build_polyn_1var (y): 
    a = str(y)
    
    exp = [ ] 
    coeff = [ ]
    
    i = 0; n = 87; m = 58
    
    while i <= len(a) - 48:
        if i >= n and i <= n+1: 
            exp.append(a[n] + a[n+1])
            n += 41 
        
        if i >= m and i <= m+22:
            coeff.append(a[m] + a[m+1] + a[m+2] + a[m+3] + a[m+4] + a[m+5] + a[m+6] + a[m+7]
                         + a[m+8] + a[m+9] + a[m+10] + a[m+11] + a[m+12] + a[m+13] + a[m+14]
                         + a[m+15] + a[m+16] + a[m+17] + a[m+18] + a[m+19] + a[m+20] + a[m+21] 
                         + a[m+22])
            m += 41 
        
        i += 1
            
    
    exponents = np.array([exp], dtype=float) 
    coefficients = np.array([coeff], dtype=float)
    return exponents, coefficients 

exponents, coefficients = build_polyn_1var (y)

P = lambda x,i:  coefficients[0,i] * (x - x0)**exponents[0,i]    #scrive il polinomio

x = np.linspace(0, 2*np.pi, 100)
y = np.zeros(100, dtype = float)

for i in range(np.size(exponents)):
    y = y + P(x,i) 

#PLOT 
     
pp.plot(x, y)
       
    
    
