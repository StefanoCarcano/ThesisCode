#import daceypy_import_helper  # noqa: F401

from daceypy import DA
import numpy as np
from matplotlib import pyplot as pp
 


DA.init(20, 1)

x = DA(1)

# compute and print sin(x)^2
y1 = x.sin().sqr()
print("sin(x)^2\n" + str(y1) + "\n")

# compute and print cos(x)^2
y2 = x.cos().sqr()
print("cos(x)^2\n" + str(y2) + "\n")

# compute and print sin(x)^2+cos(x)^2
s = y1 + y2
print("sin(x)^2+cos(x)^2\n" + str(s) + "\n")

def build_polyn_1var (y): 
    a = str(y)
    
    exp = [ ] 
    coeff = [ ]
    
    i = 0; n = 87; m = 58
    
    while i <= len(a) - 48:
        if i >= n and i <= n+1: 
            exp.append(a[n] + a[n+1])
            n += 41 
        
        if i >= m and i <= m+22:
            coeff.append(a[m] + a[m+1] + a[m+2] + a[m+3] + a[m+4] + a[m+5] + a[m+6] + a[m+7]
                         + a[m+8] + a[m+9] + a[m+10] + a[m+11] + a[m+12] + a[m+13] + a[m+14]
                         + a[m+15] + a[m+16] + a[m+17] + a[m+18] + a[m+19] + a[m+20] + a[m+21] 
                         + a[m+22])
            m += 41 
        
        i += 1
            
    
    exponents = np.array([exp], dtype=float) 
    coefficients = np.array([coeff], dtype=float)
    return exponents, coefficients 

exponents, coefficients = build_polyn_1var (s)

P = lambda x,i: coefficients[0,i]*x**exponents[0,i]    #scrive il polinomio

X = np.linspace(0, 2*np.pi, 100)
Y = np.zeros(100, dtype = float)

for i in range(np.size(exponents)):
    Y = Y + P(X,i) 

#PLOT 
     
pp.plot(X, Y)



