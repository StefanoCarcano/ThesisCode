import daceypy_import_helper  # noqa: F401

from daceypy import DA
import numpy as np
from matplotlib import pyplot as pp



# Initialize DACE for 1st-order computations in 1 variable
DA.init(20, 1)

# Initialize x as DA around 3
x0 = 3
x = x0 + DA(1)

print(f"x\n{x}\n")

# Evaluate f(x) = 1/(x+1/x)
f = 1/(x+1/x)

print(f"f(x) = 1/(x+1/x)\n{f}\n")



N = 100           # number of points in grid
hw = 2.0          # length of grid in each direction from expansion point
rda = [ ]

for i in range(N):
    xx = -hw + i * 2.0 * hw / (N - 1)  # point on the grid on [-hw,hw]
    rda.append(f.evalScalar(xx)) 

    
#PLOT 
     
pp.plot(np.linspace(-hw, hw, N), rda)
