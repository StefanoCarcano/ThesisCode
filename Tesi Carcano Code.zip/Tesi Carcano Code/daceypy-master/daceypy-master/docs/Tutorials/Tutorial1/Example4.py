#import daceypy_import_helper  # noqa: F401

from daceypy import DA
import numpy as np
from matplotlib import pyplot as pp



DA.init(20, 1)

x0 = 0
x = x0 + DA(1)

# Compute [cos(x)-1]
y = x.sin() 

print(f"[cos(x)-1]\n{y}\n")

# Compute [cos(x)-1]^11
z = y ** 11

print(f"[cos(x)-1]^11\n{z}\n")

N = 100           # number of points in grid
hw = 2.0*np.pi          # length of grid in each direction from expansion point
rda = [ ]

for i in range(N):
    xx = -hw + i * 2.0 * hw / (N - 1)  # point on the grid on [-hw,hw]
    rda.append(y.evalScalar(xx)) 

    
#PLOT 
     
pp.plot(np.linspace(-hw, hw, N), rda)

