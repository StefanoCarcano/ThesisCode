import daceypy_import_helper  # noqa: F401

from daceypy import DA, array
import numpy as np
from matplotlib import pyplot as pp



def somb(x: array) -> DA:
    norm_x = x.vnorm()
    return norm_x.sin() / norm_x


# initialize DACE for 10th-order computations in 2 variables
DA.init(10, 2)

print("Initialize x as two-dim DA vector around (2,3)\n\n")
x0 = 1; y0 = 1
x = array([x0 + DA(1), y0 + DA(2)])

print(f"x\n{x}\n")

print("Evaluate sombrero function\n")

# Evaluate sombrero function
z = somb(x)

print(f"z\n{z}\n")


x0 = 2.0  # expansion point x
y0 = 3.0  # expansion point y
N = 50  # number of points in grid

x = DA(1) + x0
y = DA(2) + y0
xx = np.linspace(-3,2,N)
yy = np.linspace(-3,2,N)
rda = np.zeros([N,N])

for i in range(N):
    # x coordinate on the grid on [-1, 1]
    for j in range(N):
        # y coordinate on the grid on [-1, 1]
        point = np.array([xx[i],yy[j]])
        # note: this is not an efficient way
        # to repeatedly evaluate the same polynomial
        rda[i,j] = z.eval(point)

# Creating figure
# fig = pp.figure(figsize =(14, 9))
# ax = pp.axes(projection ='3d')
 
# # Creating plot
# X = np.array([xx], dtype=float)
# Y = np.array([yy], dtype=float)

# ax.plot_surface(X, Y, rda)
 
# # show plot
# pp.show()

# SAVE TXT FOR PLOTTING IN  MATLAB 

np.savetxt('xx.txt', xx, fmt='%f')
np.savetxt('yy.txt', yy, fmt='%f')
np.savetxt('rda.txt', rda, fmt='%f')



# def build_polyn_2var (y): 
#     a = str(y)
    
#     exp1 = [ ]; exp2 = [ ] 
#     coeff = [ ]
    
#     i = 0; n1 = 87; n2 = 90 ; m = 58
    
#     while i <= len(a) - 48:
#         if i >= n1 and i <= n1+1: 
#             exp1.append(a[n1] + a[n1+1])
#             n1 += 44
            
#         if i >= n2 and i <= n2+1: 
#             exp2.append(a[n2] + a[n2+1])
#             n2 += 44 
        
#         if i >= m and i <= m+22:
#             coeff.append(a[m] + a[m+1] + a[m+2] + a[m+3] + a[m+4] + a[m+5] + a[m+6] + a[m+7]
#                          + a[m+8] + a[m+9] + a[m+10] + a[m+11] + a[m+12] + a[m+13] + a[m+14]
#                          + a[m+15] + a[m+16] + a[m+17] + a[m+18] + a[m+19] + a[m+20] + a[m+21] 
#                          + a[m+22])
#             m += 44 
        
#         i += 1
            
    
#     exponents1 = np.array([exp1], dtype=float) 
#     exponents2 = np.array([exp2], dtype=float)
#     coefficients = np.array([coeff], dtype=float)
    
#     return exponents1, exponents2, coefficients 


# exponents1,exponents2, coefficients = build_polyn_2var (z)

# P = lambda x,y,i:  coefficients[0,i] * (x - x0)**(exponents1[0,i])*(y - y0)**(exponents2[0,i])    #scrive il polinomio

# X = np.linspace(-1, 1, 10000)
# Y = np.linspace(-1, 1, 10000)
# XX, YY = np.meshgrid(X, Y, sparse=True)

# Z = np.zeros((10000,10000), dtype = float)

# for i in range(np.size(exponents1)):
#     Z = Z + P(XX,YY,i)

# # Creating figure
# fig = pp.figure(figsize =(14, 9))
# ax = pp.axes(projection ='3d')
 
# # Creating plot
# ax.plot_surface(XX, YY, Z)
# #ax.set_zlim(-2,2)
 
# # show plot
# pp.show()


















